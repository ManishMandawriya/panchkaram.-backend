# Socket.IO WebSocket Testing Guide

## 🚀 **Quick Start**

### **1. Import the Socket.IO Collection**
1. Open Postman
2. Click "Import" → "Upload Files"
3. Select `SocketIO_Chat_Postman_Collection.json`
4. Click "Import"

### **2. Set Up Variables**
The collection uses these variables:
- `ws_url`: `ws://localhost:3000`
- `jwt_token`: Will be auto-filled after login
- `session_id`: Will be auto-filled after creating session
- `doctor_id`: `1`
- `patient_id`: `2`

## 🔐 **Step 1: Authentication**

### **Create Test Users (if needed)**
1. **Create Test Doctor** - Creates doctor@example.com
2. **Create Test Patient** - Creates patient@example.com

### **Login to Get JWT Token**
1. **Login Patient** - Gets JWT token for patient
2. **Login Doctor** - Gets JWT token for doctor

## 📋 **Step 2: Create Session**
1. **Create Session** - Creates a chat session and saves session_id

## 🔌 **Step 3: Socket.IO WebSocket Testing**

### **Important: Socket.IO vs Raw WebSocket**
Socket.IO uses a specific protocol that's different from raw WebSocket. Here's how to test it properly:

### **Method 1: Using Postman WebSocket Request**

#### **1. Create WebSocket Request**
1. Click "New" → "WebSocket Request"
2. URL: `ws://localhost:3000/socket.io/?EIO=4&transport=websocket`
3. Headers:
   ```
   Authorization: Bearer {{jwt_token}}
   ```

#### **2. Connect and Send Socket.IO Events**
After connecting, send these Socket.IO formatted messages:

#### **Join Session**
```json
42["join-session", "{{session_id}}"]
```

#### **Send Message**
```json
42["send-message", {
  "sessionId": "{{session_id}}",
  "content": "Hello from Socket.IO!",
  "messageType": "text"
}]
```

#### **Start Typing**
```json
42["typing-start", "{{session_id}}"]
```

#### **Stop Typing**
```json
42["typing-stop", "{{session_id}}"]
```

#### **Mark Messages Read**
```json
42["mark-read", [1, 2, 3]]
```

#### **End Session**
```json
42["end-session", {}]
```

### **Method 2: Using Socket.IO Client (Recommended)**

Since Postman's WebSocket support is limited for Socket.IO, here's a better approach:

#### **1. Create HTML Test Page**
Create a file called `socketio-test.html`:

```html
<!DOCTYPE html>
<html>
<head>
    <title>Socket.IO Chat Test</title>
    <script src="https://cdn.socket.io/4.7.2/socket.io.min.js"></script>
</head>
<body>
    <h1>Socket.IO Chat Test</h1>
    
    <div>
        <label>JWT Token:</label>
        <input type="text" id="jwtToken" placeholder="Enter JWT token" style="width: 400px;">
    </div>
    
    <div>
        <label>Session ID:</label>
        <input type="text" id="sessionId" placeholder="Enter session ID" style="width: 400px;">
    </div>
    
    <div>
        <button onclick="connect()">Connect</button>
        <button onclick="disconnect()">Disconnect</button>
        <button onclick="joinSession()">Join Session</button>
    </div>
    
    <div>
        <label>Message:</label>
        <input type="text" id="message" placeholder="Enter message">
        <button onclick="sendMessage()">Send Message</button>
    </div>
    
    <div>
        <button onclick="startTyping()">Start Typing</button>
        <button onclick="stopTyping()">Stop Typing</button>
        <button onclick="endSession()">End Session</button>
    </div>
    
    <div id="messages" style="border: 1px solid #ccc; height: 300px; overflow-y: scroll; padding: 10px; margin-top: 20px;"></div>

    <script>
        let socket;
        
        function log(message) {
            const messagesDiv = document.getElementById('messages');
            const time = new Date().toLocaleTimeString();
            messagesDiv.innerHTML += `<div>[${time}] ${message}</div>`;
            messagesDiv.scrollTop = messagesDiv.scrollHeight;
        }
        
        function connect() {
            const token = document.getElementById('jwtToken').value;
            if (!token) {
                alert('Please enter JWT token');
                return;
            }
            
            socket = io('http://localhost:3000', {
                auth: {
                    token: token
                }
            });
            
            socket.on('connect', () => {
                log('✅ Connected to Socket.IO server');
            });
            
            socket.on('disconnect', () => {
                log('❌ Disconnected from server');
            });
            
            socket.on('session-joined', (data) => {
                log(`🎯 Session joined: ${JSON.stringify(data)}`);
            });
            
            socket.on('new-message', (data) => {
                log(`💬 New message: ${JSON.stringify(data)}`);
            });
            
            socket.on('user-typing', (data) => {
                log(`⌨️ User typing: ${JSON.stringify(data)}`);
            });
            
            socket.on('messages-read', (data) => {
                log(`👁️ Messages read: ${JSON.stringify(data)}`);
            });
            
            socket.on('session-ended', (data) => {
                log(`🔚 Session ended: ${JSON.stringify(data)}`);
            });
            
            socket.on('error', (data) => {
                log(`❌ Error: ${JSON.stringify(data)}`);
            });
        }
        
        function disconnect() {
            if (socket) {
                socket.disconnect();
                log('🔌 Disconnected');
            }
        }
        
        function joinSession() {
            const sessionId = document.getElementById('sessionId').value;
            if (!sessionId) {
                alert('Please enter session ID');
                return;
            }
            
            socket.emit('join-session', sessionId);
            log(`🎯 Joining session: ${sessionId}`);
        }
        
        function sendMessage() {
            const sessionId = document.getElementById('sessionId').value;
            const message = document.getElementById('message').value;
            
            if (!sessionId || !message) {
                alert('Please enter session ID and message');
                return;
            }
            
            socket.emit('send-message', {
                sessionId: sessionId,
                content: message,
                messageType: 'text'
            });
            
            log(`📤 Sending message: ${message}`);
            document.getElementById('message').value = '';
        }
        
        function startTyping() {
            const sessionId = document.getElementById('sessionId').value;
            socket.emit('typing-start', sessionId);
            log('⌨️ Started typing');
        }
        
        function stopTyping() {
            const sessionId = document.getElementById('sessionId').value;
            socket.emit('typing-stop', sessionId);
            log('⌨️ Stopped typing');
        }
        
        function endSession() {
            socket.emit('end-session', {});
            log('🔚 Ending session');
        }
    </script>
</body>
</html>
```

#### **2. Test with HTML Page**
1. Save the HTML file
2. Open it in a browser
3. Enter your JWT token and session ID
4. Click "Connect" to establish Socket.IO connection
5. Test all the events

## 📡 **Socket.IO Event Format**

### **Client → Server Events**

#### **Join Session**
```javascript
socket.emit('join-session', 'session_1_2_abc123');
```

#### **Send Message**
```javascript
socket.emit('send-message', {
  sessionId: 'session_1_2_abc123',
  content: 'Hello from Socket.IO!',
  messageType: 'text'
});
```

#### **Start Typing**
```javascript
socket.emit('typing-start', 'session_1_2_abc123');
```

#### **Stop Typing**
```javascript
socket.emit('typing-stop', 'session_1_2_abc123');
```

#### **Mark Messages Read**
```javascript
socket.emit('mark-read', [1, 2, 3]);
```

#### **End Session**
```javascript
socket.emit('end-session', {});
```

### **Server → Client Events**

#### **Session Joined**
```javascript
socket.on('session-joined', (data) => {
  console.log('Session joined:', data);
});
```

#### **New Message**
```javascript
socket.on('new-message', (data) => {
  console.log('New message:', data);
});
```

#### **User Typing**
```javascript
socket.on('user-typing', (data) => {
  console.log('User typing:', data);
});
```

#### **Messages Read**
```javascript
socket.on('messages-read', (data) => {
  console.log('Messages read:', data);
});
```

#### **Session Ended**
```javascript
socket.on('session-ended', (data) => {
  console.log('Session ended:', data);
});
```

## 🧪 **Testing Scenarios**

### **Scenario 1: Basic Chat Flow**
1. Login as Patient → Get JWT token
2. Create Session → Get session ID
3. Open HTML test page
4. Connect with JWT token
5. Join session with session ID
6. Send messages
7. Test typing indicators
8. End session

### **Scenario 2: Real-time Testing**
1. Open two browser tabs with HTML test page
2. Login as Patient in one tab, Doctor in another
3. Connect both to Socket.IO
4. Join the same session
5. Send messages from both sides
6. Observe real-time delivery

### **Scenario 3: Error Testing**
1. Test with invalid JWT token
2. Test with expired session
3. Test with non-existent session ID
4. Test disconnection/reconnection

## 🔧 **Troubleshooting**

### **Common Issues**

#### **1. Connection Failed**
- Check if server is running on port 3000
- Verify JWT token is valid
- Check CORS settings in server

#### **2. Authentication Errors**
- Ensure JWT token is properly formatted
- Check token expiration
- Verify user exists in database

#### **3. Session Not Found**
- Verify session_id is correct
- Check if session is active
- Ensure user has access to session

#### **4. Messages Not Delivered**
- Check if both users are in the session
- Verify session status is "ongoing"
- Check Socket.IO connection status

### **Debug Steps**
1. Check server logs for errors
2. Verify database connections
3. Test REST APIs first
4. Check Socket.IO connection status
5. Verify event data format

## 📊 **Expected Results**

### **Successful Flow**
1. ✅ Socket.IO connects with JWT
2. ✅ Join session successful
3. ✅ Messages sent and received in real-time
4. ✅ Typing indicators work
5. ✅ Read receipts update
6. ✅ Session ends properly

### **Error Responses**
```javascript
socket.on('error', (data) => {
  console.log('Error:', data.message);
});
```

## 🎯 **Advanced Testing**

### **Load Testing**
- Open multiple Socket.IO connections
- Send messages rapidly
- Test concurrent sessions

### **Error Handling**
- Test with invalid JWT
- Test with expired sessions
- Test with unauthorized access

### **Performance Testing**
- Monitor message delivery time
- Test with large message content
- Test file uploads

## 📝 **Notes**

- **Socket.IO** uses a different protocol than raw WebSocket
- **JWT tokens** are sent in the auth object during connection
- **Session IDs** are used for room management
- **Real-time events** are instant
- **REST APIs** and **Socket.IO** work together
- **Database** stores all messages and session data

This guide covers all aspects of testing your Socket.IO chat system! 🚀
