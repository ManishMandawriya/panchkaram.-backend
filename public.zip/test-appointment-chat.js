const { Sequelize } = require('sequelize');
const jwt = require('jsonwebtoken');

// Database connection
const sequelize = new Sequelize('panchakarma', 'root', '', {
  host: 'localhost',
  dialect: 'mysql',
  logging: false
});

// Test user data
const testUser = {
  userId: 1,
  email: 'test@example.com',
  role: 'patient',
  fullName: 'Test User'
};

const JWT_SECRET = 'your-super-secret-jwt-key-change-this-in-production';

async function testAppointmentChatCreation() {
  try {
    await sequelize.authenticate();
    console.log('✅ Database connection established.');

    // Generate JWT token
    const token = jwt.sign(testUser, JWT_SECRET, { expiresIn: '7d' });
    console.log('🔑 Test JWT Token:', token);

    // Test appointment data
    const appointmentData = {
      doctorId: 1,
      appointmentDate: '2024-01-20',
      appointmentTime: '10:00 AM',
      serviceType: 'CHAT',
      patientName: 'Test Patient',
      patientAge: 25,
      patientGender: 'male',
      problemDescription: 'Test appointment for chat session creation'
    };

    console.log('\n📋 Test Appointment Data:', appointmentData);

    // Check if doctor exists
    const [doctors] = await sequelize.query('SELECT id, full_name, role FROM users WHERE role = "doctor" AND is_active = 1 LIMIT 1');
    
    if (doctors.length === 0) {
      console.log('❌ No doctors found in database. Creating a test doctor...');
      
      // Create a test doctor
      await sequelize.query(`
        INSERT INTO users (email, password, phone_number, role, full_name, is_active, is_approved, is_phone_verified, is_email_verified) 
        VALUES ('doctor@test.com', '$2b$12$test', '+1234567890', 'doctor', 'Test Doctor', 1, 1, 1, 1)
      `);
      
      const [newDoctor] = await sequelize.query('SELECT id FROM users WHERE email = "doctor@test.com"');
      appointmentData.doctorId = newDoctor[0].id;
      console.log('✅ Created test doctor with ID:', appointmentData.doctorId);
    } else {
      appointmentData.doctorId = doctors[0].id;
      console.log('✅ Using existing doctor with ID:', appointmentData.doctorId);
    }

    // Check if doctor services exist
    const [doctorServices] = await sequelize.query(`
      SELECT * FROM doctor_services WHERE doctor_id = ${appointmentData.doctorId}
    `);

    if (doctorServices.length === 0) {
      console.log('❌ No doctor services found. Creating test doctor services...');
      
      await sequelize.query(`
        INSERT INTO doctor_services (doctor_id, chat_enabled, chat_price, chat_duration, audio_enabled, audio_price, audio_duration, video_enabled, video_price, video_duration) 
        VALUES (${appointmentData.doctorId}, 1, 100.00, 30, 1, 200.00, 45, 1, 300.00, 60)
      `);
      console.log('✅ Created test doctor services');
    }

    // Check if time slots exist
    const [timeSlots] = await sequelize.query(`
      SELECT * FROM doctor_time_slots WHERE doctor_id = ${appointmentData.doctorId} AND day_of_week = 'saturday'
    `);

    if (timeSlots.length === 0) {
      console.log('❌ No time slots found. Creating test time slots...');
      
      await sequelize.query(`
        INSERT INTO doctor_time_slots (doctor_id, day_of_week, time_slot, is_available) 
        VALUES (${appointmentData.doctorId}, 'saturday', '10:00:00', 1)
      `);
      console.log('✅ Created test time slot');
    }

    console.log('\n🔧 Testing appointment creation via API...');
    
    // Simulate API call to create appointment
    const fetch = require('node-fetch');
    
    const response = await fetch('http://localhost:3000/api/appointments', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify(appointmentData)
    });

    const result = await response.json();
    console.log('📋 Appointment Creation Result:', result);

    if (result.success) {
      console.log('✅ Appointment created successfully!');
      
      // Check if chat was created
      const [chats] = await sequelize.query(`
        SELECT * FROM chats WHERE doctor_id = ${appointmentData.doctorId} AND patient_id = ${testUser.userId}
      `);
      
      if (chats.length > 0) {
        console.log('✅ Chat created successfully!');
        console.log('📋 Chat details:', chats[0]);
        
        // Check if chat session was created
        const [chatSessions] = await sequelize.query(`
          SELECT * FROM chat_sessions WHERE chat_id = ${chats[0].id}
        `);
        
        if (chatSessions.length > 0) {
          console.log('✅ Chat session created successfully!');
          console.log('📋 Chat session details:', chatSessions[0]);
          console.log('📋 Session ID for Socket.IO:', chatSessions[0].session_id);
        } else {
          console.log('❌ Chat session was not created');
        }
      } else {
        console.log('❌ Chat was not created');
      }
    } else {
      console.log('❌ Failed to create appointment:', result.message);
    }

  } catch (error) {
    console.error('❌ Error testing appointment chat creation:', error.message);
  } finally {
    await sequelize.close();
  }
}

// Run the test
testAppointmentChatCreation()
  .then(() => {
    console.log('\n🎉 Appointment chat creation test completed!');
    process.exit(0);
  })
  .catch((error) => {
    console.error('❌ Test failed:', error);
    process.exit(1);
  });
