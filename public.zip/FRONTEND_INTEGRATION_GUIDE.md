# Frontend Integration Guide - Chat System

## 📋 Quick Start

### 1. Server Setup
```bash
# Run the complete setup script on your server
node setup-chat-system-complete.js
```

### 2. Frontend Dependencies
```bash
npm install socket.io-client
```

### 3. Basic Connection
```javascript
import { io } from 'socket.io-client';

const socket = io('http://localhost:3000', {
  auth: { token: 'your-jwt-token' },
  transports: ['websocket', 'polling']
});
```

## 🔌 Socket.IO Events Reference

| Event | Direction | Payload | Response |
|-------|-----------|---------|----------|
| `join-session` | Client → Server | `{ sessionId: "1-5-1703123456789" }` | `session-joined` |
| `send-message` | Client → Server | `{ sessionId, content, messageType }` | `new-message` |
| `typing-start` | Client → Server | `{ sessionId }` | `typing-indicator` |
| `typing-stop` | Client → Server | `{ sessionId }` | `typing-indicator` |
| `mark-read` | Client → Server | `{ sessionId, messageId }` | `message-read` |
| `end-session` | Client → Server | `{ sessionId }` | `session-ended` |

## 📡 REST API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/chat/verify-session` | Check for active session |
| `POST` | `/api/chat/sessions/:id/join` | Join a session |
| `GET` | `/api/chat/history/:doctorId/:patientId` | Get chat history |
| `POST` | `/api/appointments` | Create appointment (auto-creates chat) |
| `GET` | `/api/appointments/:id/chat-session` | Get chat session for appointment |

## 🔄 Complete Integration Example

### Step 1: Authentication
```javascript
// Login and get JWT token
const loginResponse = await fetch('/api/auth/login', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    phoneNumber: '1234567890',
    password: 'password123'
  })
});

const { token } = await loginResponse.json();
```

### Step 2: Check for Active Session
```javascript
const sessionResponse = await fetch(
  `/api/chat/verify-session?userId=5&role=patient`,
  { headers: { 'Authorization': `Bearer ${token}` } }
);

const sessionData = await sessionResponse.json();
if (sessionData.success) {
  const sessionId = sessionData.data.sessionId;
  // Connect to Socket.IO
}
```

### Step 3: Socket.IO Connection
```javascript
const socket = io('http://localhost:3000', {
  auth: { token }
});

socket.on('connect', () => {
  console.log('Connected to chat server');
  socket.emit('join-session', sessionId);
});

socket.on('session-joined', (data) => {
  console.log('Joined session:', data);
});

socket.on('new-message', (message) => {
  console.log('New message:', message);
  // Update UI with new message
});
```

### Step 4: Send Messages
```javascript
function sendMessage(content) {
  socket.emit('send-message', {
    sessionId: sessionId,
    content: content,
    messageType: 'text'
  });
}
```

## 📱 React Component Example

```jsx
import React, { useEffect, useState } from 'react';
import { io } from 'socket.io-client';

const ChatComponent = ({ sessionId, token }) => {
  const [socket, setSocket] = useState(null);
  const [messages, setMessages] = useState([]);
  const [isTyping, setIsTyping] = useState(false);
  const [inputMessage, setInputMessage] = useState('');

  useEffect(() => {
    const newSocket = io('http://localhost:3000', {
      auth: { token }
    });

    newSocket.on('connect', () => {
      console.log('Connected to chat');
      newSocket.emit('join-session', sessionId);
    });

    newSocket.on('session-joined', (data) => {
      console.log('Joined session:', data);
    });

    newSocket.on('new-message', (message) => {
      setMessages(prev => [...prev, message]);
    });

    newSocket.on('typing-indicator', (data) => {
      setIsTyping(data.isTyping);
    });

    setSocket(newSocket);

    return () => newSocket.close();
  }, [sessionId, token]);

  const sendMessage = () => {
    if (inputMessage.trim() && socket) {
      socket.emit('send-message', {
        sessionId,
        content: inputMessage,
        messageType: 'text'
      });
      setInputMessage('');
    }
  };

  const startTyping = () => {
    socket?.emit('typing-start', { sessionId });
  };

  const stopTyping = () => {
    socket?.emit('typing-stop', { sessionId });
  };

  return (
    <div className="chat-container">
      <div className="messages">
        {messages.map((message, index) => (
          <div key={index} className={`message ${message.direction}`}>
            <div className="content">{message.content}</div>
            <div className="time">{new Date(message.sentAt).toLocaleTimeString()}</div>
          </div>
        ))}
        {isTyping && <div className="typing-indicator">Someone is typing...</div>}
      </div>
      
      <div className="input-area">
        <input
          type="text"
          value={inputMessage}
          onChange={(e) => setInputMessage(e.target.value)}
          onKeyPress={(e) => {
            if (e.key === 'Enter') sendMessage();
          }}
          onFocus={startTyping}
          onBlur={stopTyping}
          placeholder="Type your message..."
        />
        <button onClick={sendMessage}>Send</button>
      </div>
    </div>
  );
};

export default ChatComponent;
```

## 🎯 Complete Chat Service Class

```javascript
class ChatService {
  constructor(token) {
    this.token = token;
    this.socket = null;
    this.baseURL = 'http://localhost:3000/api';
  }

  // Initialize Socket.IO connection
  connect() {
    this.socket = io('http://localhost:3000', {
      auth: { token: this.token },
      transports: ['websocket', 'polling']
    });

    this.setupEventListeners();
    return this.socket;
  }

  setupEventListeners() {
    this.socket.on('connect', () => {
      console.log('✅ Connected to chat server');
    });

    this.socket.on('session-joined', (data) => {
      console.log('✅ Joined session:', data);
    });

    this.socket.on('new-message', (message) => {
      console.log('📨 New message:', message);
    });

    this.socket.on('typing-indicator', (data) => {
      console.log('⌨️ Typing indicator:', data);
    });

    this.socket.on('message-read', (data) => {
      console.log('👁️ Message read:', data);
    });

    this.socket.on('session-ended', (data) => {
      console.log('🔚 Session ended:', data);
    });

    this.socket.on('error', (data) => {
      console.error('❌ Socket error:', data);
    });
  }

  // Socket.IO Methods
  joinSession(sessionId) {
    this.socket?.emit('join-session', sessionId);
  }

  sendMessage(sessionId, content, messageType = 'text') {
    this.socket?.emit('send-message', {
      sessionId,
      content,
      messageType
    });
  }

  startTyping(sessionId) {
    this.socket?.emit('typing-start', { sessionId });
  }

  stopTyping(sessionId) {
    this.socket?.emit('typing-stop', { sessionId });
  }

  markMessageAsRead(sessionId, messageId) {
    this.socket?.emit('mark-read', { sessionId, messageId });
  }

  endSession(sessionId) {
    this.socket?.emit('end-session', { sessionId });
  }

  disconnect() {
    this.socket?.disconnect();
  }

  // REST API Methods
  async verifySession(userId, role) {
    const response = await fetch(
      `${this.baseURL}/chat/verify-session?userId=${userId}&role=${role}`,
      { headers: { 'Authorization': `Bearer ${this.token}` } }
    );
    return response.json();
  }

  async getChatHistory(doctorId, patientId, limit = 50) {
    const response = await fetch(
      `${this.baseURL}/chat/history/${doctorId}/${patientId}?limit=${limit}`,
      { headers: { 'Authorization': `Bearer ${this.token}` } }
    );
    return response.json();
  }

  async getAppointmentChatSession(appointmentId) {
    const response = await fetch(
      `${this.baseURL}/appointments/${appointmentId}/chat-session`,
      { headers: { 'Authorization': `Bearer ${this.token}` } }
    );
    return response.json();
  }

  async createAppointment(appointmentData) {
    const response = await fetch(`${this.baseURL}/appointments`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${this.token}`
      },
      body: JSON.stringify(appointmentData)
    });
    return response.json();
  }
}

// Usage
const chatService = new ChatService('your-jwt-token');
chatService.connect();

// Check for active session
const session = await chatService.verifySession(5, 'patient');
if (session.success) {
  chatService.joinSession(session.data.sessionId);
}

// Send a message
chatService.sendMessage('1-5-1703123456789', 'Hello doctor!');
```

## 🧪 Testing

### 1. Test Socket.IO Connection
```bash
node test-socket-auth.js
```

### 2. Test Message Sending
```bash
node test-socket-message.js
```

### 3. Test with HTML Client
Open `socketio-test.html` in your browser

## 📝 Important Notes

1. **Session ID Format:** `{doctorId}-{patientId}-{timestamp}`
2. **Message Types:** `text`, `image`, `file`, `audio`, `video`
3. **Session Types:** `chat`, `audioCall`, `videoCall`
4. **Message Direction:** `inbound` (patient→doctor), `outbound` (doctor→patient)
5. **All timestamps are in UTC (ISO 8601 format)**

## 🚨 Error Handling

Always handle these scenarios:
- Connection failures
- Authentication errors
- Session not found
- Network disconnections
- Invalid message format

## 📚 Additional Resources

- **Socket.IO Documentation:** `SOCKET_IO_API_DOCUMENTATION.md`
- **REST API Reference:** `CHAT_REST_API_REFERENCE.md`
- **Deployment Guide:** `CHAT_SYSTEM_DEPLOYMENT_GUIDE.md`

---

**Need help?** Check the server logs for detailed error messages and refer to the troubleshooting sections in the documentation.
