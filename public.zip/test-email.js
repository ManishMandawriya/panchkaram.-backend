// Simple test script for email service
require('dotenv').config();

const { EmailService } = require('./dist/services/emailService');

async function testEmail() {
  try {
    console.log('Testing email service...');
    console.log('EMAIL_HOST:', process.env.EMAIL_HOST);
    console.log('EMAIL_PORT:', process.env.EMAIL_PORT);
    console.log('EMAIL_USER:', process.env.EMAIL_USER);
    
    const emailService = new EmailService();
    
    // Test welcome email
    await emailService.sendWelcomeEmail('test@example.com', 'Test User');
    console.log('✅ Welcome email sent successfully!');
    
  } catch (error) {
    console.error('❌ Email test failed:', error.message);
  }
}

testEmail(); 