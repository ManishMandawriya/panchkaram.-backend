const axios = require('axios');

// Configuration
const API_BASE_URL = 'http://localhost:3000/api';
let authToken = null;
let doctorId = null;

// Test doctor credentials
const TEST_DOCTOR = {
  phoneNumber: '9876543210',
  password: 'test123',
  email: 'testdoctor@example.com',
  fullName: 'Test Doctor',
  role: 'doctor',
  doctorId: 'DOC123',
  departmentId: 1,
  experience: 5,
};

async function loginDoctor() {
  try {
    console.log('🔐 Logging in as doctor...');
    const loginData = {
      phoneNumber: TEST_DOCTOR.phoneNumber,
      password: TEST_DOCTOR.password
    };

    const response = await axios.post(`${API_BASE_URL}/auth/login`, loginData, {
      headers: {
        'Content-Type': 'application/json'
      }
    });

    if (response.data.success) {
      authToken = response.data.data.token;
      doctorId = response.data.data.user.id;
      console.log('✅ Doctor login successful!');
      console.log('Token:', authToken.substring(0, 20) + '...');
      console.log('Doctor ID:', doctorId);
      return true;
    } else {
      console.log('❌ Doctor login failed:', response.data.message);
      return false;
    }
  } catch (error) {
    console.log('❌ Login error:', error.response?.data?.message || error.message);
    return false;
  }
}

async function testDoctorSlots() {
  try {
    console.log('\n🧪 Testing Doctor Slot Management APIs...\n');

    if (!authToken) {
      console.log('❌ No authentication token available. Please login first.');
      return;
    }

    const headers = {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${authToken}`
    };

    // Test 1: Get weekly availability
    console.log('📅 Test 1: Getting weekly availability...');
    const weeklyResponse = await axios.get(`${API_BASE_URL}/doctor/slots/weekly-availability`, { headers });
    console.log('✅ Weekly availability response:');
    console.log('Success:', weeklyResponse.data.success);
    console.log('Message:', weeklyResponse.data.message);
    console.log('Availability:', Object.keys(weeklyResponse.data.data?.availability || {}));

    // Test 2: Update weekly availability
    console.log('\n📝 Test 2: Updating weekly availability...');
    const weeklyUpdateData = {
      availability: {
        monday: {
          startTime: '09:00',
          endTime: '17:00',
          isAvailable: true,
          slotDuration: 30,
          breakTime: 60,
        },
        tuesday: {
          startTime: '09:00',
          endTime: '17:00',
          isAvailable: true,
          slotDuration: 30,
          breakTime: 60,
        },
        wednesday: {
          startTime: '09:00',
          endTime: '17:00',
          isAvailable: true,
          slotDuration: 30,
          breakTime: 60,
        },
        thursday: {
          startTime: '09:00',
          endTime: '17:00',
          isAvailable: true,
          slotDuration: 30,
          breakTime: 60,
        },
        friday: {
          startTime: '09:00',
          endTime: '17:00',
          isAvailable: true,
          slotDuration: 30,
          breakTime: 60,
        },
        saturday: {
          startTime: '09:00',
          endTime: '13:00',
          isAvailable: true,
          slotDuration: 30,
          breakTime: 30,
        },
        sunday: {
          startTime: '10:00',
          endTime: '14:00',
          isAvailable: false,
          slotDuration: 30,
          breakTime: 60,
        },
      }
    };

    const updateWeeklyResponse = await axios.put(`${API_BASE_URL}/doctor/slots/weekly-availability`, weeklyUpdateData, { headers });
    console.log('✅ Update weekly availability response:');
    console.log('Success:', updateWeeklyResponse.data.success);
    console.log('Message:', updateWeeklyResponse.data.message);
    console.log('Updated days:', updateWeeklyResponse.data.data?.updatedDays);

    // Test 3: Generate time slots for Monday
    console.log('\n⏰ Test 3: Generating time slots for Monday...');
    const generateSlotsData = {
      dayOfWeek: 1, // Monday
      startTime: '09:00',
      endTime: '17:00',
      slotDuration: 30,
      breakTime: 60,
      breakStartTime: '12:00',
      breakEndTime: '13:00',
    };

    const generateResponse = await axios.post(`${API_BASE_URL}/doctor/slots/generate-time-slots`, generateSlotsData, { headers });
    console.log('✅ Generate time slots response:');
    console.log('Success:', generateResponse.data.success);
    console.log('Message:', generateResponse.data.message);
    console.log('Total slots generated:', generateResponse.data.data?.totalSlots);
    console.log('Sample slots:', generateResponse.data.data?.timeSlots?.slice(0, 5));

    // Test 4: Get time slots for Monday
    console.log('\n📋 Test 4: Getting time slots for Monday...');
    const timeSlotsResponse = await axios.get(`${API_BASE_URL}/doctor/slots/time-slots?dayOfWeek=1`, { headers });
    console.log('✅ Get time slots response:');
    console.log('Success:', timeSlotsResponse.data.success);
    console.log('Message:', timeSlotsResponse.data.message);
    console.log('Total slots:', timeSlotsResponse.data.data?.timeSlots?.length || 0);
    console.log('Sample slots:', timeSlotsResponse.data.data?.timeSlots?.slice(0, 3));

    // Test 5: Update a specific time slot
    if (timeSlotsResponse.data.data?.timeSlots?.length > 0) {
      console.log('\n✏️ Test 5: Updating a specific time slot...');
      const slotId = timeSlotsResponse.data.data.timeSlots[0].id;
      const updateSlotData = {
        isAvailable: false,
        duration: 45,
        notes: 'Lunch break',
      };

      const updateSlotResponse = await axios.put(`${API_BASE_URL}/doctor/slots/time-slots/${slotId}`, updateSlotData, { headers });
      console.log('✅ Update time slot response:');
      console.log('Success:', updateSlotResponse.data.success);
      console.log('Message:', updateSlotResponse.data.message);
    }

    // Test 6: Get availability calendar
    console.log('\n📅 Test 6: Getting availability calendar...');
    const startDate = new Date();
    const endDate = new Date();
    endDate.setDate(endDate.getDate() + 7);

    const calendarResponse = await axios.get(
      `${API_BASE_URL}/doctor/slots/availability-calendar?startDate=${startDate.toISOString().split('T')[0]}&endDate=${endDate.toISOString().split('T')[0]}&includeBooked=true`,
      { headers }
    );
    console.log('✅ Availability calendar response:');
    console.log('Success:', calendarResponse.data.success);
    console.log('Message:', calendarResponse.data.message);
    console.log('Calendar days:', calendarResponse.data.data?.calendar?.length || 0);
    console.log('Sample day:', calendarResponse.data.data?.calendar?.[0]);

    // Test 7: Copy schedule from Monday to Tuesday
    console.log('\n📋 Test 7: Copying schedule from Monday to Tuesday...');
    const copyScheduleData = {
      fromDay: 1, // Monday
      toDay: 2,   // Tuesday
      overwrite: true,
    };

    const copyResponse = await axios.post(`${API_BASE_URL}/doctor/slots/copy-schedule`, copyScheduleData, { headers });
    console.log('✅ Copy schedule response:');
    console.log('Success:', copyResponse.data.success);
    console.log('Message:', copyResponse.data.message);
    console.log('Copied slots:', copyResponse.data.data?.copiedSlots);

    // Test 8: Bulk update time slots
    console.log('\n🔄 Test 8: Bulk updating time slots...');
    const tuesdaySlotsResponse = await axios.get(`${API_BASE_URL}/doctor/slots/time-slots?dayOfWeek=2`, { headers });
    
    if (tuesdaySlotsResponse.data.data?.timeSlots?.length > 0) {
      const bulkUpdateData = {
        dayOfWeek: 2,
        updates: tuesdaySlotsResponse.data.data.timeSlots.slice(0, 3).map(slot => ({
          id: slot.id,
          isAvailable: false,
          duration: 60,
          notes: 'Bulk updated',
        })),
      };

      const bulkUpdateResponse = await axios.post(`${API_BASE_URL}/doctor/slots/bulk-update`, bulkUpdateData, { headers });
      console.log('✅ Bulk update response:');
      console.log('Success:', bulkUpdateResponse.data.success);
      console.log('Message:', bulkUpdateResponse.data.message);
      console.log('Updated count:', bulkUpdateResponse.data.data?.updatedCount);
    }

    // Test 9: Get slot statistics
    console.log('\n📊 Test 9: Getting slot statistics...');
    const statsResponse = await axios.get(`${API_BASE_URL}/doctor/slots/statistics`, { headers });
    console.log('✅ Slot statistics response:');
    console.log('Success:', statsResponse.data.success);
    console.log('Message:', statsResponse.data.message);
    console.log('Statistics:', statsResponse.data.data?.statistics);
    console.log('Slots by day:', statsResponse.data.data?.slotsByDay);

    // Test 10: Test unauthorized access
    console.log('\n🚫 Test 10: Testing unauthorized access...');
    try {
      await axios.get(`${API_BASE_URL}/doctor/slots/weekly-availability`);
      console.log('❌ Should have failed - unauthorized access allowed');
    } catch (error) {
      if (error.response?.status === 401 || error.response?.status === 403) {
        console.log('✅ Unauthorized access properly blocked');
      } else {
        console.log('❌ Unexpected error:', error.response?.status);
      }
    }

    console.log('\n🎉 All doctor slot management tests completed!');

  } catch (error) {
    console.log('\n❌ Error testing doctor slots:', error.response?.data?.message || error.message);
    
    if (error.response?.data) {
      console.log('Response data:', error.response.data);
    }
  }
}

async function main() {
  console.log('🚀 Starting Doctor Slot Management API Tests');
  console.log('============================================\n');

  // First, try to login
  const loginSuccess = await loginDoctor();
  
  if (loginSuccess) {
    await testDoctorSlots();
  } else {
    console.log('\n💡 To test the APIs, you need to:');
    console.log('1. Create a test doctor account');
    console.log('2. Verify their phone number in the database');
    console.log('3. Run this script again');
  }
}

// Run the tests
main().catch(console.error);

