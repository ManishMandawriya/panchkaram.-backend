const axios = require('axios');

const API_BASE_URL = 'http://localhost:3000/api';

// Test data - you'll need to replace these with actual values from your database
const TEST_DOCTOR_CREDENTIALS = {
  phoneNumber: '9876543210', // Replace with actual doctor phone number
  password: 'Test@123'
};

let authToken = '';

async function login() {
  try {
    console.log('🔐 Logging in as doctor...\n');
    
    const loginData = {
      phoneNumber: TEST_DOCTOR_CREDENTIALS.phoneNumber,
      password: TEST_DOCTOR_CREDENTIALS.password
    };

    const response = await axios.post(`${API_BASE_URL}/auth/login`, loginData, {
      headers: {
        'Content-Type': 'application/json'
      }
    });

    if (response.data.success) {
      authToken = response.data.data.token;
      console.log('✅ Doctor login successful!');
      console.log('Token received:', authToken.substring(0, 20) + '...');
      return true;
    } else {
      console.log('❌ Doctor login failed:', response.data.message);
      return false;
    }
  } catch (error) {
    console.log('❌ Doctor login error:', error.response?.data?.message || error.message);
    return false;
  }
}

async function testDoctorAppointments() {
  try {
    console.log('\n🧪 Testing Doctor Appointment Management APIs...\n');

    if (!authToken) {
      console.log('❌ No authentication token available. Please login first.');
      return;
    }

    const headers = {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${authToken}`
    };

    // Test 1: Get all doctor appointments
    console.log('📋 Test 1: Getting all doctor appointments...');
    const allResponse = await axios.get(`${API_BASE_URL}/doctor/appointments`, { headers });
    console.log('✅ All appointments response:');
    console.log('Success:', allResponse.data.success);
    console.log('Message:', allResponse.data.message);
    console.log('Total appointments:', allResponse.data.data?.appointments?.length || 0);

    // Test 2: Get pending appointments
    console.log('\n📋 Test 2: Getting pending appointments...');
    const pendingResponse = await axios.get(`${API_BASE_URL}/doctor/appointments/pending`, { headers });
    console.log('✅ Pending appointments response:');
    console.log('Success:', pendingResponse.data.success);
    console.log('Message:', pendingResponse.data.message);
    console.log('Total pending appointments:', pendingResponse.data.data?.appointments?.length || 0);

    // Test 3: Get upcoming appointments
    console.log('\n📋 Test 3: Getting upcoming appointments...');
    const upcomingResponse = await axios.get(`${API_BASE_URL}/doctor/appointments/upcoming`, { headers });
    console.log('✅ Upcoming appointments response:');
    console.log('Success:', upcomingResponse.data.success);
    console.log('Message:', upcomingResponse.data.message);
    console.log('Total upcoming appointments:', upcomingResponse.data.data?.appointments?.length || 0);

    // Test 4: Get completed appointments
    console.log('\n📋 Test 4: Getting completed appointments...');
    const completedResponse = await axios.get(`${API_BASE_URL}/doctor/appointments/completed`, { headers });
    console.log('✅ Completed appointments response:');
    console.log('Success:', completedResponse.data.success);
    console.log('Message:', completedResponse.data.message);
    console.log('Total completed appointments:', completedResponse.data.data?.appointments?.length || 0);

    // Test 5: Get appointment statistics
    console.log('\n📋 Test 5: Getting appointment statistics...');
    const statsResponse = await axios.get(`${API_BASE_URL}/doctor/appointments/stats/overview`, { headers });
    console.log('✅ Appointment statistics response:');
    console.log('Success:', statsResponse.data.success);
    console.log('Message:', statsResponse.data.message);
    if (statsResponse.data.data?.stats) {
      console.log('Statistics:', JSON.stringify(statsResponse.data.data.stats, null, 2));
    }

    // Test 6: Test appointment status updates (if appointments exist)
    const appointments = allResponse.data.data?.appointments || [];
    if (appointments.length > 0) {
      const firstAppointment = appointments[0];
      console.log(`\n📋 Test 6: Testing appointment status updates for appointment ID: ${firstAppointment.id}...`);

      // Test 6a: Get specific appointment details
      console.log('\n📋 Test 6a: Getting specific appointment details...');
      const appointmentResponse = await axios.get(`${API_BASE_URL}/doctor/appointments/${firstAppointment.id}`, { headers });
      console.log('✅ Appointment details response:');
      console.log('Success:', appointmentResponse.data.success);
      console.log('Message:', appointmentResponse.data.message);

      // Test 6b: Update appointment status (if it's pending)
      if (firstAppointment.status === 'pending') {
        console.log('\n📋 Test 6b: Accepting appointment...');
        const acceptResponse = await axios.put(`${API_BASE_URL}/doctor/appointments/${firstAppointment.id}/accept`, {
          notes: 'Appointment accepted by doctor'
        }, { headers });
        console.log('✅ Accept appointment response:');
        console.log('Success:', acceptResponse.data.success);
        console.log('Message:', acceptResponse.data.message);
      }

      // Test 6c: Complete appointment (if it's confirmed and time has passed)
      if (firstAppointment.status === 'confirmed') {
        const appointmentDate = new Date(firstAppointment.appointmentDate);
        const now = new Date();
        
        if (appointmentDate < now) {
          console.log('\n📋 Test 6c: Completing appointment...');
          const completeResponse = await axios.put(`${API_BASE_URL}/doctor/appointments/${firstAppointment.id}/complete`, {
            notes: 'Appointment completed successfully'
          }, { headers });
          console.log('✅ Complete appointment response:');
          console.log('Success:', completeResponse.data.success);
          console.log('Message:', completeResponse.data.message);
        } else {
          console.log('\n📋 Test 6c: Skipping appointment completion (appointment time not passed yet)');
        }
      }
    } else {
      console.log('\n📋 Test 6: Skipping appointment status updates (no appointments found)');
    }

    // Test 7: Test with filters
    console.log('\n📋 Test 7: Testing appointments with filters...');
    const filteredResponse = await axios.get(`${API_BASE_URL}/doctor/appointments?status=pending&page=1&limit=5`, { headers });
    console.log('✅ Filtered appointments response:');
    console.log('Success:', filteredResponse.data.success);
    console.log('Message:', filteredResponse.data.message);
    console.log('Total filtered appointments:', filteredResponse.data.data?.appointments?.length || 0);

    // Test 8: Test without authentication (should fail)
    console.log('\n🔒 Test 8: Testing without authentication (should fail)...');
    try {
      await axios.get(`${API_BASE_URL}/doctor/appointments`, {
        headers: { 'Content-Type': 'application/json' }
      });
      console.log('❌ This should have failed but succeeded!');
    } catch (error) {
      console.log('✅ Correctly rejected request without authentication!');
      console.log('Status:', error.response.status);
      console.log('Message:', error.response.data.message);
    }

    console.log('\n🎉 All doctor appointment tests completed successfully!');
    console.log('\n📊 Summary:');
    console.log('- ✅ Authentication working');
    console.log('- ✅ Get all appointments working');
    console.log('- ✅ Get pending appointments working');
    console.log('- ✅ Get upcoming appointments working');
    console.log('- ✅ Get completed appointments working');
    console.log('- ✅ Get appointment statistics working');
    console.log('- ✅ Get specific appointment details working');
    console.log('- ✅ Appointment status updates working');
    console.log('- ✅ Filtering and pagination working');
    console.log('- ✅ Security working (rejects unauthenticated requests)');

  } catch (error) {
    console.log('\n❌ Test failed!');
    if (error.response) {
      console.log('Status:', error.response.status);
      console.log('Response:', JSON.stringify(error.response.data, null, 2));
    } else {
      console.log('Error:', error.message);
    }
  }
}

async function runTests() {
  console.log('🚀 Starting Doctor Appointment Management API Tests...\n');
  
  const loginSuccess = await login();
  
  if (loginSuccess) {
    await testDoctorAppointments();
  } else {
    console.log('\n⚠️  Skipping API tests due to login failure.');
    console.log('Please ensure you have a registered doctor with these credentials:');
    console.log('Phone:', TEST_DOCTOR_CREDENTIALS.phoneNumber);
    console.log('Password:', TEST_DOCTOR_CREDENTIALS.password);
    console.log('\nNote: You may need to create a doctor account first or update the credentials above.');
  }
  
  console.log('\n🏁 Tests completed!');
}

runTests();
