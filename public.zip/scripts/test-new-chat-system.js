const mysql = require('mysql2/promise');
const config = require('../src/config/database');

async function testNewChatSystem() {
  let connection;

  try {
    console.log('🧪 Testing new chat system...');

    // Create database connection
    connection = await mysql.createConnection({
      host: config.host,
      user: config.username,
      password: config.password,
      database: config.database,
    });

    // Test 1: Create a chat
    console.log('\n📝 Test 1: Creating a chat...');
    const [chatResult] = await connection.execute(`
      INSERT INTO chats (doctor_id, patient_id) 
      VALUES (1, 2) 
      ON DUPLICATE KEY UPDATE updated_at = CURRENT_TIMESTAMP
    `);
    console.log('✅ Chat created/updated successfully');

    // Get the chat ID
    const [chatRows] = await connection.execute(`
      SELECT id FROM chats WHERE doctor_id = 1 AND patient_id = 2
    `);
    const chatId = chatRows[0]?.id;

    if (!chatId) {
      throw new Error('Failed to get chat ID');
    }

    // Test 2: Create a session
    console.log('\n📝 Test 2: Creating a session...');
    const sessionId = `session_1_2_${Date.now()}`;
    const [sessionResult] = await connection.execute(`
      INSERT INTO chat_sessions (chat_id, session_id, doctor_id, patient_id, session_type, status)
      VALUES (?, ?, 1, 2, 'chat', 'scheduled')
    `, [chatId, sessionId]);
    console.log('✅ Session created successfully');

    // Get the session ID
    const [sessionRows] = await connection.execute(`
      SELECT id FROM chat_sessions WHERE session_id = ?
    `, [sessionId]);
    const sessionDbId = sessionRows[0]?.id;

    if (!sessionDbId) {
      throw new Error('Failed to get session ID');
    }

    // Test 3: Send messages
    console.log('\n📝 Test 3: Sending messages...');
    
    // Patient message
    await connection.execute(`
      INSERT INTO chat_messages (chat_id, session_id, sender_id, content, direction, status, sent_at, delivered_at)
      VALUES (?, ?, 2, 'Hello doctor, I have a question', 'inbound', 'delivered', NOW(), NOW())
    `, [chatId, sessionDbId]);
    console.log('✅ Patient message sent');

    // Doctor message
    await connection.execute(`
      INSERT INTO chat_messages (chat_id, session_id, sender_id, content, direction, status, sent_at, delivered_at)
      VALUES (?, ?, 1, 'Hello! How can I help you today?', 'outbound', 'delivered', NOW(), NOW())
    `, [chatId, sessionDbId]);
    console.log('✅ Doctor message sent');

    // System message
    await connection.execute(`
      INSERT INTO chat_messages (chat_id, session_id, sender_id, content, direction, message_type, status, sent_at, delivered_at)
      VALUES (?, ?, 0, 'Session started', 'system', 'system', 'delivered', NOW(), NOW())
    `, [chatId, sessionDbId]);
    console.log('✅ System message sent');

    // Test 4: Update session status
    console.log('\n📝 Test 4: Updating session status...');
    await connection.execute(`
      UPDATE chat_sessions 
      SET status = 'ongoing', start_time = NOW(), patient_joined_at = NOW(), doctor_joined_at = NOW()
      WHERE id = ?
    `, [sessionDbId]);
    console.log('✅ Session status updated to ongoing');

    // Test 5: Query messages
    console.log('\n📝 Test 5: Querying messages...');
    const [messages] = await connection.execute(`
      SELECT 
        cm.id,
        cm.content,
        cm.direction,
        cm.message_type,
        cm.status,
        u.full_name as sender_name
      FROM chat_messages cm
      LEFT JOIN users u ON cm.sender_id = u.id
      WHERE cm.session_id = ?
      ORDER BY cm.created_at ASC
    `, [sessionDbId]);

    console.log('📨 Messages in session:');
    messages.forEach((msg, index) => {
      console.log(`  ${index + 1}. [${msg.direction.toUpperCase()}] ${msg.sender_name || 'System'}: ${msg.content}`);
    });

    // Test 6: Query session details
    console.log('\n📝 Test 6: Querying session details...');
    const [sessionDetails] = await connection.execute(`
      SELECT 
        cs.id,
        cs.session_id,
        cs.status,
        cs.session_type,
        cs.start_time,
        cs.patient_joined_at,
        cs.doctor_joined_at,
        c.id as chat_id,
        d.full_name as doctor_name,
        p.full_name as patient_name
      FROM chat_sessions cs
      JOIN chats c ON cs.chat_id = c.id
      JOIN users d ON cs.doctor_id = d.id
      JOIN users p ON cs.patient_id = p.id
      WHERE cs.id = ?
    `, [sessionDbId]);

    if (sessionDetails.length > 0) {
      const session = sessionDetails[0];
      console.log('📋 Session details:');
      console.log(`  Session ID: ${session.session_id}`);
      console.log(`  Status: ${session.status}`);
      console.log(`  Type: ${session.session_type}`);
      console.log(`  Doctor: ${session.doctor_name}`);
      console.log(`  Patient: ${session.patient_name}`);
      console.log(`  Chat ID: ${session.chat_id}`);
    }

    // Test 7: End session
    console.log('\n📝 Test 7: Ending session...');
    await connection.execute(`
      UPDATE chat_sessions 
      SET status = 'ended', end_time = NOW(), duration = 300
      WHERE id = ?
    `, [sessionDbId]);
    console.log('✅ Session ended');

    // Test 8: Verify chat history
    console.log('\n📝 Test 8: Verifying chat history...');
    const [chatHistory] = await connection.execute(`
      SELECT 
        c.id as chat_id,
        COUNT(cs.id) as total_sessions,
        COUNT(cm.id) as total_messages
      FROM chats c
      LEFT JOIN chat_sessions cs ON c.id = cs.chat_id
      LEFT JOIN chat_messages cm ON c.id = cm.chat_id
      WHERE c.doctor_id = 1 AND c.patient_id = 2
      GROUP BY c.id
    `);

    if (chatHistory.length > 0) {
      const history = chatHistory[0];
      console.log('📊 Chat history:');
      console.log(`  Chat ID: ${history.chat_id}`);
      console.log(`  Total sessions: ${history.total_sessions}`);
      console.log(`  Total messages: ${history.total_messages}`);
    }

    console.log('\n🎉 All tests passed successfully!');
    console.log('\n📋 Summary:');
    console.log('  ✅ Chat creation works');
    console.log('  ✅ Session creation works');
    console.log('  ✅ Message sending works');
    console.log('  ✅ Session status updates work');
    console.log('  ✅ Message querying works');
    console.log('  ✅ Session details querying works');
    console.log('  ✅ Session ending works');
    console.log('  ✅ Chat history works');

  } catch (error) {
    console.error('❌ Test failed:', error);
    throw error;
  } finally {
    if (connection) {
      await connection.end();
    }
  }
}

// Run the test
testNewChatSystem()
  .then(() => {
    console.log('\n🎉 New chat system test completed successfully!');
    process.exit(0);
  })
  .catch((error) => {
    console.error('\n💥 New chat system test failed:', error);
    process.exit(1);
  });
