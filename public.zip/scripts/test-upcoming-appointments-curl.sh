#!/bin/bash

# Test script for upcoming appointments API
API_BASE_URL="http://localhost:3000/api"

echo "🚀 Testing Upcoming Appointments API with cURL"
echo "=============================================="

# Step 1: Login to get token
echo -e "\n🔐 Step 1: Logging in to get authentication token..."
LOGIN_RESPONSE=$(curl -s -X POST "$API_BASE_URL/auth/login" \
  -H "Content-Type: application/json" \
  -d '{
    "phoneNumber": "1234567890",
    "password": "Test@123"
  }')

echo "Login response: $LOGIN_RESPONSE"

# Extract token from response
TOKEN=$(echo $LOGIN_RESPONSE | grep -o '"token":"[^"]*"' | cut -d'"' -f4)

if [ -z "$TOKEN" ]; then
    echo "❌ Failed to get authentication token"
    exit 1
fi

echo "✅ Authentication token received: ${TOKEN:0:20}..."

# Step 2: Test upcoming appointments API
echo -e "\n📋 Step 2: Testing upcoming appointments API..."

echo -e "\n📅 Getting all appointments..."
curl -s -X GET "$API_BASE_URL/appointments/my" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" | jq '.'

echo -e "\n📅 Getting future appointments (upcoming)..."
curl -s -X GET "$API_BASE_URL/appointments/my?filter=future" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" | jq '.'

echo -e "\n📅 Getting past appointments..."
curl -s -X GET "$API_BASE_URL/appointments/my?filter=past" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" | jq '.'

echo -e "\n📅 Testing pagination..."
curl -s -X GET "$API_BASE_URL/appointments/my?filter=future&page=1&limit=5" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" | jq '.'

# Step 3: Test without authentication (should fail)
echo -e "\n🔒 Step 3: Testing without authentication (should fail)..."
curl -s -X GET "$API_BASE_URL/appointments/my?filter=future" \
  -H "Content-Type: application/json" | jq '.'

echo -e "\n🏁 Tests completed!" 