const axios = require('axios');
const mysql = require('mysql2/promise');

const API_BASE_URL = 'http://localhost:3000/api';

// Database configuration
const dbConfig = {
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'panchakarma',
};

// Test doctor data
const TEST_DOCTOR = {
  role: 'doctor',
  email: 'doctor.test@example.com',
  password: 'Test@123',
  confirmPassword: 'Test@123',
  phoneNumber: '9876543210',
  fullName: 'Dr. Test Doctor',
  doctorId: 'DOC001',
  departmentId: 1, // Make sure this category exists
  experience: '5 years',
  isPhoneVerified: true,
};

async function createTestDoctor() {
  try {
    console.log('🏥 Creating test doctor account...\n');

    // Step 1: Register the doctor
    console.log('📝 Step 1: Registering doctor...');
    const registerData = {
      role: TEST_DOCTOR.role,
      email: TEST_DOCTOR.email,
      password: TEST_DOCTOR.password,
      confirmPassword: TEST_DOCTOR.confirmPassword,
      phoneNumber: TEST_DOCTOR.phoneNumber,
      fullName: TEST_DOCTOR.fullName,
      doctorId: TEST_DOCTOR.doctorId,
      departmentId: TEST_DOCTOR.departmentId,
      experience: TEST_DOCTOR.experience,
    };

    const registerResponse = await axios.post(`${API_BASE_URL}/auth/register`, registerData, {
      headers: {
        'Content-Type': 'application/json'
      }
    });

    if (registerResponse.data.success) {
      console.log('✅ Doctor registration successful!');
      console.log('Message:', registerResponse.data.message);
    } else {
      console.log('❌ Doctor registration failed:', registerResponse.data.message);
      return false;
    }

    // Step 2: Verify phone number in database (since we can't send actual SMS)
    console.log('\n📱 Step 2: Verifying phone number...');
    const connection = await mysql.createConnection(dbConfig);
    
    try {
      await connection.execute(
        'UPDATE users SET is_phone_verified = 1 WHERE phone_number = ?',
        [TEST_DOCTOR.phoneNumber]
      );
      console.log('✅ Phone number verified in database');
    } catch (error) {
      console.log('❌ Failed to verify phone number:', error.message);
    } finally {
      await connection.end();
    }

    // Step 3: Test login
    console.log('\n🔐 Step 3: Testing login...');
    const loginData = {
      phoneNumber: TEST_DOCTOR.phoneNumber,
      password: TEST_DOCTOR.password
    };

    const loginResponse = await axios.post(`${API_BASE_URL}/auth/login`, loginData, {
      headers: {
        'Content-Type': 'application/json'
      }
    });

    if (loginResponse.data.success) {
      console.log('✅ Doctor login successful!');
      console.log('Token received:', loginResponse.data.data.token.substring(0, 20) + '...');
      console.log('User ID:', loginResponse.data.data.user.id);
      console.log('Role:', loginResponse.data.data.user.role);
    } else {
      console.log('❌ Doctor login failed:', loginResponse.data.message);
      return false;
    }

    // Step 4: Initialize doctor services
    console.log('\n⚙️ Step 4: Initializing doctor services...');
    const authToken = loginResponse.data.data.token;
    const doctorId = loginResponse.data.data.user.id;

    const initResponse = await axios.post(`${API_BASE_URL}/doctor/${doctorId}/initialize`, {}, {
      headers: {
        'Authorization': `Bearer ${authToken}`,
        'Content-Type': 'application/json'
      }
    });

    if (initResponse.data.success) {
      console.log('✅ Doctor services initialized successfully!');
    } else {
      console.log('❌ Failed to initialize doctor services:', initResponse.data.message);
    }

    console.log('\n🎉 Test doctor account created successfully!');
    console.log('\n📋 Account Details:');
    console.log('Phone Number:', TEST_DOCTOR.phoneNumber);
    console.log('Password:', TEST_DOCTOR.password);
    console.log('Email:', TEST_DOCTOR.email);
    console.log('Full Name:', TEST_DOCTOR.fullName);
    console.log('Doctor ID:', TEST_DOCTOR.doctorId);
    console.log('Department ID:', TEST_DOCTOR.departmentId);
    console.log('Experience:', TEST_DOCTOR.experience);
    
    console.log('\n🔑 Login Token:', authToken);
    console.log('\n💡 You can now use these credentials to test the doctor appointment management APIs!');

    return true;

  } catch (error) {
    console.log('\n❌ Error creating test doctor:', error.response?.data?.message || error.message);
    
    if (error.response?.data?.message?.includes('already exists')) {
      console.log('\n💡 Doctor already exists. You can use the existing credentials:');
      console.log('Phone Number:', TEST_DOCTOR.phoneNumber);
      console.log('Password:', TEST_DOCTOR.password);
    }
    
    return false;
  }
}

async function checkDatabaseSetup() {
  try {
    console.log('🔍 Checking database setup...\n');
    
    const connection = await mysql.createConnection(dbConfig);
    
    try {
      // Check if categories table exists and has data
      const [categories] = await connection.execute('SELECT * FROM categories WHERE is_active = 1 LIMIT 1');
      
      if (categories.length === 0) {
        console.log('⚠️ No active categories found. Creating a test category...');
        await connection.execute(`
          INSERT INTO categories (name, description, is_active, created_at, updated_at) 
          VALUES ('General Medicine', 'General medical consultation', 1, NOW(), NOW())
        `);
        console.log('✅ Test category created');
      } else {
        console.log('✅ Categories table has data');
      }

      // Check if users table exists
      const [users] = await connection.execute('SELECT COUNT(*) as count FROM users');
      console.log('✅ Users table exists with', users[0].count, 'records');

      // Check if appointments table exists
      const [appointments] = await connection.execute('SELECT COUNT(*) as count FROM appointments');
      console.log('✅ Appointments table exists with', appointments[0].count, 'records');

    } finally {
      await connection.end();
    }

  } catch (error) {
    console.log('❌ Database check failed:', error.message);
    console.log('Make sure your database is running and the tables are created.');
  }
}

async function main() {
  console.log('🚀 Doctor Account Creation Script');
  console.log('==================================\n');

  await checkDatabaseSetup();
  console.log('');
  
  const success = await createTestDoctor();
  
  if (success) {
    console.log('\n✅ Script completed successfully!');
    console.log('You can now run the doctor appointment tests.');
  } else {
    console.log('\n❌ Script failed. Please check the errors above.');
  }
}

main();
