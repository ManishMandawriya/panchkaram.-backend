const axios = require('axios');

const API_BASE_URL = 'http://localhost:3000/api';

// Test data
const TEST_PATIENT_CREDENTIALS = {
  phoneNumber: '1234567890',
  password: 'Test@123'
};

let authToken = '';

async function login() {
  try {
    console.log('🔐 Logging in to get authentication token...\n');
    
    const loginData = {
      phoneNumber: TEST_PATIENT_CREDENTIALS.phoneNumber,
      password: TEST_PATIENT_CREDENTIALS.password
    };

    const response = await axios.post(`${API_BASE_URL}/auth/login`, loginData, {
      headers: {
        'Content-Type': 'application/json'
      }
    });

    if (response.data.success) {
      authToken = response.data.data.token;
      console.log('✅ Login successful!');
      return true;
    } else {
      console.log('❌ Login failed:', response.data.message);
      return false;
    }
  } catch (error) {
    console.log('❌ Login error:', error.response?.data?.message || error.message);
    return false;
  }
}

async function createTestAppointment() {
  try {
    console.log('\n📅 Creating test appointment...\n');

    if (!authToken) {
      console.log('❌ No authentication token available.');
      return;
    }

    const headers = {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${authToken}`
    };

    // First, let's get available doctors
    console.log('🔍 Getting available doctors...');
    const doctorsResponse = await axios.get(`${API_BASE_URL}/doctors`, { headers });
    
    if (!doctorsResponse.data.success || doctorsResponse.data.data.doctors.length === 0) {
      console.log('❌ No doctors available. Please create a doctor first.');
      return;
    }

    const doctor = doctorsResponse.data.data.doctors[0];
    console.log(`✅ Found doctor: ${doctor.fullName} (ID: ${doctor.id})`);

    // Create a future appointment (tomorrow)
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    const appointmentDate = tomorrow.toISOString().split('T')[0]; // YYYY-MM-DD format

    const appointmentData = {
      doctorId: doctor.id,
      serviceType: 'chat',
      appointmentDate: appointmentDate,
      appointmentTime: '10:00:00',
      notes: 'Test appointment for upcoming appointments API'
    };

    console.log('📤 Creating appointment with data:', JSON.stringify(appointmentData, null, 2));

    const appointmentResponse = await axios.post(`${API_BASE_URL}/appointments`, appointmentData, { headers });

    if (appointmentResponse.data.success) {
      console.log('✅ Test appointment created successfully!');
      console.log('Appointment ID:', appointmentResponse.data.data.appointment.id);
      
      // Now test the upcoming appointments API
      await testUpcomingAppointments();
    } else {
      console.log('❌ Failed to create appointment:', appointmentResponse.data.message);
    }

  } catch (error) {
    console.log('\n❌ Create appointment failed!');
    if (error.response) {
      console.log('Status:', error.response.status);
      console.log('Response:', JSON.stringify(error.response.data, null, 2));
    } else {
      console.log('Error:', error.message);
    }
  }
}

async function testUpcomingAppointments() {
  try {
    console.log('\n🧪 Testing Upcoming Appointments API with the new appointment...\n');

    const headers = {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${authToken}`
    };

    // Test future appointments (upcoming)
    console.log('📋 Getting future appointments (upcoming)...');
    const futureResponse = await axios.get(`${API_BASE_URL}/appointments/my?filter=future`, { headers });
    console.log('Future appointments response:', JSON.stringify(futureResponse.data, null, 2));

    // Test all appointments
    console.log('\n📋 Getting all appointments...');
    const allResponse = await axios.get(`${API_BASE_URL}/appointments/my`, { headers });
    console.log('All appointments response:', JSON.stringify(allResponse.data, null, 2));

  } catch (error) {
    console.log('\n❌ Test failed!');
    if (error.response) {
      console.log('Status:', error.response.status);
      console.log('Response:', JSON.stringify(error.response.data, null, 2));
    } else {
      console.log('Error:', error.message);
    }
  }
}

async function runTest() {
  console.log('🚀 Starting Test Appointment Creation and Upcoming Appointments Test...\n');
  
  const loginSuccess = await login();
  
  if (loginSuccess) {
    await createTestAppointment();
  } else {
    console.log('\n⚠️  Skipping test due to login failure.');
  }
  
  console.log('\n🏁 Test completed!');
}

runTest(); 