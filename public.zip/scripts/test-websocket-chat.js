const io = require('socket.io-client');
const axios = require('axios');

const BASE_URL = 'http://localhost:3000';
const WS_URL = 'http://localhost:3000';

// Test data
let patientToken = '';
let doctorToken = '';
let chatSessionId = '';

// Colors for console output
const colors = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  cyan: '\x1b[36m'
};

function log(message, color = 'reset') {
  console.log(`${colors[color]}${message}${colors.reset}`);
}

async function loginUser(email, password) {
  try {
    const response = await axios.post(`${BASE_URL}/api/auth/login`, {
      email,
      password
    });
    return response.data.data.token;
  } catch (error) {
    log(`Login failed for ${email}: ${error.response?.data?.message || error.message}`, 'red');
    return null;
  }
}

async function createChatSession(token, doctorId) {
  try {
    const response = await axios.post(`${BASE_URL}/api/chat/sessions`, {
      doctorId,
      sessionType: 'chat'
    }, {
      headers: { Authorization: `Bearer ${token}` }
    });
    return response.data.data.id;
  } catch (error) {
    log(`Failed to create chat session: ${error.response?.data?.message || error.message}`, 'red');
    return null;
  }
}

function createSocketClient(token, userType) {
  const socket = io(WS_URL, {
    auth: { token },
    transports: ['websocket']
  });

  socket.on('connect', () => {
    log(`✅ ${userType} connected to WebSocket`, 'green');
  });

  socket.on('disconnect', () => {
    log(`❌ ${userType} disconnected from WebSocket`, 'red');
  });

  socket.on('error', (error) => {
    log(`❌ ${userType} WebSocket error: ${error.message}`, 'red');
  });

  socket.on('session-joined', (data) => {
    log(`🎯 ${userType} joined session: ${data.sessionId}`, 'cyan');
    log(`   Status: ${data.status}`, 'cyan');
    log(`   Participants: Patient ${data.participants.patient.name}, Doctor ${data.participants.doctor.name}`, 'cyan');
  });

  socket.on('user-joined', (data) => {
    log(`👋 ${data.userName} joined the session`, 'yellow');
  });

  socket.on('user-left', (data) => {
    log(`👋 ${data.userName} left the session`, 'yellow');
  });

  socket.on('new-message', (data) => {
    log(`💬 [${data.senderName}]: ${data.content}`, 'magenta');
    log(`   Message ID: ${data.messageId}, Type: ${data.messageType}, Status: ${data.status}`, 'cyan');
  });

  socket.on('user-typing', (data) => {
    if (data.isTyping) {
      log(`⌨️  ${data.userName} is typing...`, 'yellow');
    } else {
      log(`⌨️  ${data.userName} stopped typing`, 'yellow');
    }
  });

  socket.on('messages-read', (data) => {
    log(`👁️  Messages read by user ${data.readBy}`, 'blue');
  });

  socket.on('session-status-updated', (data) => {
    log(`🔄 Session status updated to: ${data.status}`, 'blue');
  });

  return socket;
}

async function testWebSocketChat() {
  log('🚀 Starting WebSocket Chat Test', 'bright');

  // Step 1: Login users
  log('\n📝 Step 1: Logging in users...', 'bright');
  
  patientToken = await loginUser('patient@test.com', 'password123');
  if (!patientToken) {
    log('❌ Patient login failed. Please ensure patient user exists.', 'red');
    return;
  }
  log('✅ Patient logged in successfully', 'green');

  doctorToken = await loginUser('doctor@test.com', 'password123');
  if (!doctorToken) {
    log('❌ Doctor login failed. Please ensure doctor user exists.', 'red');
    return;
  }
  log('✅ Doctor logged in successfully', 'green');

  // Step 2: Create chat session
  log('\n💬 Step 2: Creating chat session...', 'bright');
  
  // Get doctor ID (assuming doctor ID is 2, adjust as needed)
  const doctorId = 2;
  chatSessionId = await createChatSession(patientToken, doctorId);
  if (!chatSessionId) {
    log('❌ Failed to create chat session', 'red');
    return;
  }
  log(`✅ Chat session created: ${chatSessionId}`, 'green');

  // Step 3: Start WebSocket connections
  log('\n🔌 Step 3: Establishing WebSocket connections...', 'bright');
  
  const patientSocket = createSocketClient(patientToken, 'Patient');
  const doctorSocket = createSocketClient(doctorToken, 'Doctor');

  // Wait for connections
  await new Promise(resolve => setTimeout(resolve, 2000));

  // Step 4: Join chat session
  log('\n🎯 Step 4: Joining chat session...', 'bright');
  
  patientSocket.emit('join-session', chatSessionId);
  doctorSocket.emit('join-session', chatSessionId);

  // Wait for session join
  await new Promise(resolve => setTimeout(resolve, 1000));

  // Step 5: Test real-time messaging
  log('\n💬 Step 5: Testing real-time messaging...', 'bright');
  
  // Patient sends first message
  log('📤 Patient sending message...', 'blue');
  patientSocket.emit('send-message', {
    sessionId: chatSessionId,
    content: 'Hello Doctor! I have some health concerns.',
    messageType: 'text'
  });

  await new Promise(resolve => setTimeout(resolve, 1000));

  // Doctor starts typing
  log('⌨️  Doctor starts typing...', 'blue');
  doctorSocket.emit('typing-start', chatSessionId);
  
  await new Promise(resolve => setTimeout(resolve, 2000));

  // Doctor stops typing and sends reply
  log('⌨️  Doctor stops typing...', 'blue');
  doctorSocket.emit('typing-stop', chatSessionId);
  
  await new Promise(resolve => setTimeout(resolve, 500));

  log('📤 Doctor sending reply...', 'blue');
  doctorSocket.emit('send-message', {
    sessionId: chatSessionId,
    content: 'Hello! I\'m here to help. What symptoms are you experiencing?',
    messageType: 'text'
  });

  await new Promise(resolve => setTimeout(resolve, 1000));

  // Patient sends another message
  log('📤 Patient sending follow-up...', 'blue');
  patientSocket.emit('send-message', {
    sessionId: chatSessionId,
    content: 'I\'ve been having headaches and fatigue for the past week.',
    messageType: 'text'
  });

  await new Promise(resolve => setTimeout(resolve, 1000));

  // Doctor sends a longer message
  log('📤 Doctor sending detailed response...', 'blue');
  doctorSocket.emit('send-message', {
    sessionId: chatSessionId,
    content: 'I understand. Headaches and fatigue can have various causes. Let\'s discuss your symptoms in detail. Have you noticed any patterns or triggers?',
    messageType: 'text'
  });

  await new Promise(resolve => setTimeout(resolve, 2000));

  // Step 6: Test read receipts
  log('\n👁️  Step 6: Testing read receipts...', 'bright');
  
  // Simulate patient reading messages
  log('👁️  Patient marking messages as read...', 'blue');
  patientSocket.emit('mark-read', ['1', '2', '3']); // Assuming message IDs

  await new Promise(resolve => setTimeout(resolve, 1000));

  // Step 7: Test session status update
  log('\n🔄 Step 7: Testing session status update...', 'bright');
  
  log('🔄 Doctor updating session status...', 'blue');
  doctorSocket.emit('update-session-status', {
    sessionId: chatSessionId,
    status: 'completed'
  });

  await new Promise(resolve => setTimeout(resolve, 2000));

  // Step 8: Test disconnection
  log('\n🔌 Step 8: Testing disconnection...', 'bright');
  
  log('🔌 Patient disconnecting...', 'blue');
  patientSocket.disconnect();
  
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  log('🔌 Doctor disconnecting...', 'blue');
  doctorSocket.disconnect();

  // Step 9: Test reconnection
  log('\n🔌 Step 9: Testing reconnection...', 'bright');
  
  const patientSocket2 = createSocketClient(patientToken, 'Patient (Reconnected)');
  
  await new Promise(resolve => setTimeout(resolve, 2000));
  
  patientSocket2.emit('join-session', chatSessionId);
  
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  patientSocket2.emit('send-message', {
    sessionId: chatSessionId,
    content: 'I\'m back! Can we continue our conversation?',
    messageType: 'text'
  });

  await new Promise(resolve => setTimeout(resolve, 2000));

  log('\n✅ WebSocket Chat Test Completed Successfully!', 'green');
  log('🎉 Real-time chat system is working perfectly!', 'bright');
  
  // Cleanup
  patientSocket2.disconnect();
  process.exit(0);
}

// Error handling
process.on('unhandledRejection', (error) => {
  log(`❌ Unhandled Promise Rejection: ${error}`, 'red');
  process.exit(1);
});

process.on('uncaughtException', (error) => {
  log(`❌ Uncaught Exception: ${error}`, 'red');
  process.exit(1);
});

// Run the test
testWebSocketChat().catch(error => {
  log(`❌ Test failed: ${error.message}`, 'red');
  process.exit(1);
});
