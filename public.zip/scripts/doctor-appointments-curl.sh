#!/bin/bash

# Doctor Appointment Management API Test Script
# Make sure to replace the TOKEN and APPOINTMENT_ID with actual values

API_BASE_URL="http://localhost:3000/api"
TOKEN="your_jwt_token_here"  # Replace with actual JWT token
APPOINTMENT_ID="1"  # Replace with actual appointment ID

echo "🚀 Testing Doctor Appointment Management APIs"
echo "=============================================="

# Test 1: Get all doctor appointments
echo -e "\n📋 Test 1: Getting all doctor appointments..."
curl -X GET "${API_BASE_URL}/doctor/appointments" \
  -H "Authorization: Bearer ${TOKEN}" \
  -H "Content-Type: application/json" \
  -w "\nStatus: %{http_code}\n" \
  | jq '.'

# Test 2: Get pending appointments
echo -e "\n📋 Test 2: Getting pending appointments..."
curl -X GET "${API_BASE_URL}/doctor/appointments/pending" \
  -H "Authorization: Bearer ${TOKEN}" \
  -H "Content-Type: application/json" \
  -w "\nStatus: %{http_code}\n" \
  | jq '.'

# Test 3: Get upcoming appointments
echo -e "\n📋 Test 3: Getting upcoming appointments..."
curl -X GET "${API_BASE_URL}/doctor/appointments/upcoming" \
  -H "Authorization: Bearer ${TOKEN}" \
  -H "Content-Type: application/json" \
  -w "\nStatus: %{http_code}\n" \
  | jq '.'

# Test 4: Get completed appointments
echo -e "\n📋 Test 4: Getting completed appointments..."
curl -X GET "${API_BASE_URL}/doctor/appointments/completed" \
  -H "Authorization: Bearer ${TOKEN}" \
  -H "Content-Type: application/json" \
  -w "\nStatus: %{http_code}\n" \
  | jq '.'

# Test 5: Get appointment statistics
echo -e "\n📋 Test 5: Getting appointment statistics..."
curl -X GET "${API_BASE_URL}/doctor/appointments/stats/overview" \
  -H "Authorization: Bearer ${TOKEN}" \
  -H "Content-Type: application/json" \
  -w "\nStatus: %{http_code}\n" \
  | jq '.'

# Test 6: Get specific appointment details
echo -e "\n📋 Test 6: Getting specific appointment details..."
curl -X GET "${API_BASE_URL}/doctor/appointments/${APPOINTMENT_ID}" \
  -H "Authorization: Bearer ${TOKEN}" \
  -H "Content-Type: application/json" \
  -w "\nStatus: %{http_code}\n" \
  | jq '.'

# Test 7: Accept appointment
echo -e "\n📋 Test 7: Accepting appointment..."
curl -X PUT "${API_BASE_URL}/doctor/appointments/${APPOINTMENT_ID}/accept" \
  -H "Authorization: Bearer ${TOKEN}" \
  -H "Content-Type: application/json" \
  -d '{
    "notes": "Appointment accepted by doctor"
  }' \
  -w "\nStatus: %{http_code}\n" \
  | jq '.'

# Test 8: Reject appointment
echo -e "\n📋 Test 8: Rejecting appointment..."
curl -X PUT "${API_BASE_URL}/doctor/appointments/${APPOINTMENT_ID}/reject" \
  -H "Authorization: Bearer ${TOKEN}" \
  -H "Content-Type: application/json" \
  -d '{
    "notes": "Appointment rejected due to unavailability"
  }' \
  -w "\nStatus: %{http_code}\n" \
  | jq '.'

# Test 9: Complete appointment
echo -e "\n📋 Test 9: Completing appointment..."
curl -X PUT "${API_BASE_URL}/doctor/appointments/${APPOINTMENT_ID}/complete" \
  -H "Authorization: Bearer ${TOKEN}" \
  -H "Content-Type: application/json" \
  -d '{
    "notes": "Appointment completed successfully"
  }' \
  -w "\nStatus: %{http_code}\n" \
  | jq '.'

# Test 10: Update appointment status (generic)
echo -e "\n📋 Test 10: Updating appointment status..."
curl -X PUT "${API_BASE_URL}/doctor/appointments/${APPOINTMENT_ID}/status" \
  -H "Authorization: Bearer ${TOKEN}" \
  -H "Content-Type: application/json" \
  -d '{
    "status": "confirmed",
    "notes": "Appointment confirmed by doctor"
  }' \
  -w "\nStatus: %{http_code}\n" \
  | jq '.'

# Test 11: Get appointments with filters
echo -e "\n📋 Test 11: Getting appointments with filters..."
curl -X GET "${API_BASE_URL}/doctor/appointments?status=pending&page=1&limit=5&sortBy=appointmentDate&sortOrder=ASC" \
  -H "Authorization: Bearer ${TOKEN}" \
  -H "Content-Type: application/json" \
  -w "\nStatus: %{http_code}\n" \
  | jq '.'

# Test 12: Test without authentication (should fail)
echo -e "\n🔒 Test 12: Testing without authentication (should fail)..."
curl -X GET "${API_BASE_URL}/doctor/appointments" \
  -H "Content-Type: application/json" \
  -w "\nStatus: %{http_code}\n" \
  | jq '.'

echo -e "\n🎉 All tests completed!"
echo -e "\n📝 Notes:"
echo "- Replace TOKEN with actual JWT token from doctor login"
echo "- Replace APPOINTMENT_ID with actual appointment ID from your database"
echo "- Some tests may fail if no appointments exist or if appointment status doesn't allow the action"
