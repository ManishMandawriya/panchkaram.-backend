const axios = require('axios');

const BASE_URL = 'http://localhost:3000/api';

// Test data
const testData = {
  patient: {
    phoneNumber: '1234567890',
    password: 'test123'
  },
  doctor: {
    phoneNumber: '9876543210',
    password: 'test123'
  }
};

let patientToken = '';
let doctorToken = '';
let sessionId = null;
let messageId = null;

async function testChatSystem() {
  try {
    console.log('🧪 Testing Chat System...\n');

    // Step 1: Login as patient
    console.log('1. Logging in as patient...');
    const patientLoginResponse = await axios.post(`${BASE_URL}/auth/login`, {
      phoneNumber: testData.patient.phoneNumber,
      password: testData.patient.password
    });

    if (!patientLoginResponse.data.success) {
      throw new Error('Patient login failed: ' + patientLoginResponse.data.message);
    }

    patientToken = patientLoginResponse.data.data.token;
    console.log('✅ Patient login successful\n');

    // Step 2: Login as doctor
    console.log('2. Logging in as doctor...');
    const doctorLoginResponse = await axios.post(`${BASE_URL}/auth/login`, {
      phoneNumber: testData.doctor.phoneNumber,
      password: testData.doctor.password
    });

    if (!doctorLoginResponse.data.success) {
      throw new Error('Doctor login failed: ' + doctorLoginResponse.data.message);
    }

    doctorToken = doctorLoginResponse.data.data.token;
    console.log('✅ Doctor login successful\n');

    // Step 3: Create a chat session (patient)
    console.log('3. Creating chat session...');
    const createSessionResponse = await axios.post(`${BASE_URL}/chat/sessions`, {
      doctorId: 1, // Assuming doctor ID 1 exists
      sessionType: 'chat',
      initialMessage: 'Hello doctor, I need some medical advice.'
    }, {
      headers: { Authorization: `Bearer ${patientToken}` }
    });

    if (!createSessionResponse.data.success) {
      throw new Error('Create session failed: ' + createSessionResponse.data.message);
    }

    sessionId = createSessionResponse.data.data.session.id;
    console.log('✅ Chat session created successfully');
    console.log('Session ID:', sessionId);
    console.log('Session Status:', createSessionResponse.data.data.session.status);
    console.log('Cost per unit:', createSessionResponse.data.data.session.costPerUnit);
    console.log('');

    // Step 4: Get session details (patient)
    console.log('4. Getting session details...');
    const sessionDetailsResponse = await axios.get(`${BASE_URL}/chat/sessions/${sessionId}`, {
      headers: { Authorization: `Bearer ${patientToken}` }
    });

    if (sessionDetailsResponse.data.success) {
      console.log('✅ Session details retrieved');
      const session = sessionDetailsResponse.data.data.session;
      console.log('Patient:', session.patient.fullName);
      console.log('Doctor:', session.doctor.fullName);
      console.log('Status:', session.status);
      console.log('');
    } else {
      console.log('❌ Failed to get session details:', sessionDetailsResponse.data.message);
    }

    // Step 5: Get session status (patient)
    console.log('5. Getting session status...');
    const sessionStatusResponse = await axios.get(`${BASE_URL}/chat/sessions/${sessionId}/status`, {
      headers: { Authorization: `Bearer ${patientToken}` }
    });

    if (sessionStatusResponse.data.success) {
      console.log('✅ Session status retrieved');
      const status = sessionStatusResponse.data.data.status;
      console.log('Is Active:', status.isActive);
      console.log('Can Send Message:', status.canSendMessage);
      console.log('Is Expired:', status.isExpired);
      console.log('');
    } else {
      console.log('❌ Failed to get session status:', sessionStatusResponse.data.message);
    }

    // Step 6: Start session (doctor)
    console.log('6. Starting chat session (doctor)...');
    const startSessionResponse = await axios.put(`${BASE_URL}/chat/sessions/${sessionId}/start`, {}, {
      headers: { Authorization: `Bearer ${doctorToken}` }
    });

    if (startSessionResponse.data.success) {
      console.log('✅ Chat session started by doctor');
      console.log('Session Status:', startSessionResponse.data.data.session.status);
      console.log('');
    } else {
      console.log('❌ Failed to start session:', startSessionResponse.data.message);
    }

    // Step 7: Send message from patient
    console.log('7. Sending message from patient...');
    const sendMessageResponse = await axios.post(`${BASE_URL}/chat/sessions/${sessionId}/messages`, {
      content: 'Hello doctor, I have been experiencing headaches for the past few days.',
      messageType: 'text'
    }, {
      headers: { Authorization: `Bearer ${patientToken}` }
    });

    if (sendMessageResponse.data.success) {
      console.log('✅ Message sent from patient');
      const message = sendMessageResponse.data.data.message;
      messageId = message.id;
      console.log('Message ID:', message.id);
      console.log('Content:', message.content);
      console.log('Status:', message.status);
      console.log('Direction:', message.direction);
      console.log('');
    } else {
      console.log('❌ Failed to send message:', sendMessageResponse.data.message);
    }

    // Step 8: Send message from doctor
    console.log('8. Sending message from doctor...');
    const doctorMessageResponse = await axios.post(`${BASE_URL}/chat/sessions/${sessionId}/messages`, {
      content: 'Hello! I understand you\'re having headaches. Can you tell me more about the symptoms?',
      messageType: 'text'
    }, {
      headers: { Authorization: `Bearer ${doctorToken}` }
    });

    if (doctorMessageResponse.data.success) {
      console.log('✅ Message sent from doctor');
      const message = doctorMessageResponse.data.data.message;
      console.log('Message ID:', message.id);
      console.log('Content:', message.content);
      console.log('Status:', message.status);
      console.log('Direction:', message.direction);
      console.log('');
    } else {
      console.log('❌ Failed to send doctor message:', doctorMessageResponse.data.message);
    }

    // Step 9: Get messages (patient)
    console.log('9. Getting messages...');
    const getMessagesResponse = await axios.get(`${BASE_URL}/chat/sessions/${sessionId}/messages`, {
      headers: { Authorization: `Bearer ${patientToken}` }
    });

    if (getMessagesResponse.data.success) {
      console.log('✅ Messages retrieved');
      const messages = getMessagesResponse.data.data.messages;
      console.log('Total messages:', messages.length);
      messages.forEach((msg, index) => {
        console.log(`Message ${index + 1}:`);
        console.log(`  - Content: ${msg.content}`);
        console.log(`  - Type: ${msg.messageType}`);
        console.log(`  - Direction: ${msg.direction}`);
        console.log(`  - Status: ${msg.status}`);
        console.log(`  - Sender: ${msg.sender.fullName}`);
        console.log('');
      });
    } else {
      console.log('❌ Failed to get messages:', getMessagesResponse.data.message);
    }

    // Step 10: Mark messages as read (patient)
    console.log('10. Marking messages as read...');
    const markReadResponse = await axios.put(`${BASE_URL}/chat/sessions/${sessionId}/messages/read`, {
      messageIds: [messageId]
    }, {
      headers: { Authorization: `Bearer ${patientToken}` }
    });

    if (markReadResponse.data.success) {
      console.log('✅ Messages marked as read');
      console.log('Updated count:', markReadResponse.data.data.updatedCount);
      console.log('');
    } else {
      console.log('❌ Failed to mark messages as read:', markReadResponse.data.message);
    }

    // Step 11: Get user sessions (patient)
    console.log('11. Getting patient sessions...');
    const patientSessionsResponse = await axios.get(`${BASE_URL}/chat/sessions`, {
      headers: { Authorization: `Bearer ${patientToken}` }
    });

    if (patientSessionsResponse.data.success) {
      console.log('✅ Patient sessions retrieved');
      const sessions = patientSessionsResponse.data.data.sessions;
      console.log('Total sessions:', sessions.length);
      sessions.forEach((session, index) => {
        console.log(`Session ${index + 1}:`);
        console.log(`  - ID: ${session.id}`);
        console.log(`  - Status: ${session.status}`);
        console.log(`  - Type: ${session.sessionType}`);
        console.log(`  - Doctor: ${session.doctor.fullName}`);
        console.log(`  - Messages: ${session.totalMessages}`);
        console.log('');
      });
    } else {
      console.log('❌ Failed to get patient sessions:', patientSessionsResponse.data.message);
    }

    // Step 12: Get user sessions (doctor)
    console.log('12. Getting doctor sessions...');
    const doctorSessionsResponse = await axios.get(`${BASE_URL}/chat/sessions`, {
      headers: { Authorization: `Bearer ${doctorToken}` }
    });

    if (doctorSessionsResponse.data.success) {
      console.log('✅ Doctor sessions retrieved');
      const sessions = doctorSessionsResponse.data.data.sessions;
      console.log('Total sessions:', sessions.length);
      sessions.forEach((session, index) => {
        console.log(`Session ${index + 1}:`);
        console.log(`  - ID: ${session.id}`);
        console.log(`  - Status: ${session.status}`);
        console.log(`  - Type: ${session.sessionType}`);
        console.log(`  - Patient: ${session.patient.fullName}`);
        console.log(`  - Messages: ${session.totalMessages}`);
        console.log('');
      });
    } else {
      console.log('❌ Failed to get doctor sessions:', doctorSessionsResponse.data.message);
    }

    // Step 13: End session (patient)
    console.log('13. Ending chat session...');
    const endSessionResponse = await axios.put(`${BASE_URL}/chat/sessions/${sessionId}/end`, {
      notes: 'Patient consultation completed successfully.'
    }, {
      headers: { Authorization: `Bearer ${patientToken}` }
    });

    if (endSessionResponse.data.success) {
      console.log('✅ Chat session ended');
      const session = endSessionResponse.data.data.session;
      console.log('Final Status:', session.status);
      console.log('Total Duration:', session.totalDuration, 'minutes');
      console.log('Total Cost:', session.totalCost);
      console.log('');
    } else {
      console.log('❌ Failed to end session:', endSessionResponse.data.message);
    }

    // Step 14: Get final session status
    console.log('14. Getting final session status...');
    const finalStatusResponse = await axios.get(`${BASE_URL}/chat/sessions/${sessionId}/status`, {
      headers: { Authorization: `Bearer ${patientToken}` }
    });

    if (finalStatusResponse.data.success) {
      console.log('✅ Final session status retrieved');
      const status = finalStatusResponse.data.data.status;
      console.log('Status:', status.status);
      console.log('Is Active:', status.isActive);
      console.log('Can Send Message:', status.canSendMessage);
      console.log('Total Messages:', status.totalMessages);
      console.log('Total Duration:', status.totalDuration);
      console.log('Total Cost:', status.totalCost);
      console.log('');
    } else {
      console.log('❌ Failed to get final status:', finalStatusResponse.data.message);
    }

    console.log('🎉 All chat system tests completed successfully!');
    console.log('');
    console.log('📊 Test Summary:');
    console.log('✅ Session creation and management');
    console.log('✅ Message sending and retrieval');
    console.log('✅ Message status tracking');
    console.log('✅ Session status management');
    console.log('✅ User session listing');
    console.log('✅ Session completion and cost calculation');

  } catch (error) {
    console.error('❌ Test failed:', error.response?.data || error.message);
  }
}

// Run the test
testChatSystem();
