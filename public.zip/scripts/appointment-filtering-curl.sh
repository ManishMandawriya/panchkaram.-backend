#!/bin/bash

# Appointment Filtering API - cURL Examples
# Replace YOUR_JWT_TOKEN with actual JWT token from login

echo "🧪 Appointment Filtering API - cURL Examples"
echo "============================================="
echo ""

# Base URL and headers
BASE_URL="http://localhost:3000/api"
HEADERS="-H 'Content-Type: application/json' -H 'Authorization: Bearer YOUR_JWT_TOKEN'"

echo "📋 1. Get All Appointments (Default)"
echo "curl -X GET '$BASE_URL/appointments/my' $HEADERS"
echo ""

echo "📋 2. Get Past Appointments Only"
echo "curl -X GET '$BASE_URL/appointments/my?filter=past' $HEADERS"
echo ""

echo "📋 3. Get Future Appointments Only"
echo "curl -X GET '$BASE_URL/appointments/my?filter=future' $HEADERS"
echo ""

echo "📋 4. Get Past Appointments with Pagination"
echo "curl -X GET '$BASE_URL/appointments/my?filter=past&page=1&limit=5' $HEADERS"
echo ""

echo "📋 5. Get Future Appointments with Pagination"
echo "curl -X GET '$BASE_URL/appointments/my?filter=future&page=2&limit=10' $HEADERS"
echo ""

echo "🔧 How to get JWT Token:"
echo "curl -X POST '$BASE_URL/auth/login' \\"
echo "  -H 'Content-Type: application/json' \\"
echo "  -d '{"
echo "    \"phoneNumber\": \"1234567890\","
echo "    \"password\": \"your_password\""
echo "  }'"
echo ""

echo "📝 Response Format:"
echo "{"
echo "  \"success\": true,"
echo "  \"message\": \"Past appointments retrieved successfully\","
echo "  \"data\": {"
echo "    \"appointments\": [...],"
echo "    \"pagination\": {"
echo "      \"currentPage\": 1,"
echo "      \"totalPages\": 2,"
echo "      \"totalItems\": 15,"
echo "      \"itemsPerPage\": 10"
echo "    },"
echo "    \"filter\": \"past\""
echo "  }"
echo "}"
echo ""

echo "✨ Filter Options:"
echo "• filter=all     - Get all appointments (default)"
echo "• filter=past    - Get only past appointments"
echo "• filter=future  - Get only future appointments"
echo "• page=X         - Page number (default: 1)"
echo "• limit=X        - Items per page (default: 10)"
echo ""

echo "🔒 Security Notes:"
echo "• Requires JWT authentication"
echo "• Users can only see their own appointments"
echo "• Only shows active appointments"
echo "• Only shows approved doctors" 