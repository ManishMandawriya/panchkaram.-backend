const axios = require('axios');

const BASE_URL = 'http://localhost:3000/api';

// Test data for the new week schedule structure
const testWeekSchedule = {
  weekSchedule: [
    {
      day: "sunday",
      isAvailable: false,
      timeRanges: []
    },
    {
      day: "monday",
      isAvailable: true,
      timeRanges: [
        {
          startTime: "09:00 AM",
          endTime: "12:00 PM",
          slotDuration: 30
        },
        {
          startTime: "02:00 PM",
          endTime: "05:00 PM",
          slotDuration: 30
        }
      ]
    },
    {
      day: "tuesday",
      isAvailable: true,
      timeRanges: [
        {
          startTime: "09:00 AM",
          endTime: "12:00 PM",
          slotDuration: 30
        },
        {
          startTime: "02:00 PM",
          endTime: "05:00 PM",
          slotDuration: 30
        }
      ]
    },
    {
      day: "wednesday",
      isAvailable: true,
      timeRanges: [
        {
          startTime: "09:00 AM",
          endTime: "12:00 PM",
          slotDuration: 30
        },
        {
          startTime: "02:00 PM",
          endTime: "05:00 PM",
          slotDuration: 30
        }
      ]
    },
    {
      day: "thursday",
      isAvailable: true,
      timeRanges: [
        {
          startTime: "09:00 AM",
          endTime: "12:00 PM",
          slotDuration: 30
        },
        {
          startTime: "02:00 PM",
          endTime: "05:00 PM",
          slotDuration: 30
        }
      ]
    },
    {
      day: "friday",
      isAvailable: true,
      timeRanges: [
        {
          startTime: "09:00 AM",
          endTime: "12:00 PM",
          slotDuration: 30
        },
        {
          startTime: "02:00 PM",
          endTime: "05:00 PM",
          slotDuration: 30
        }
      ]
    },
    {
      day: "saturday",
      isAvailable: true,
      timeRanges: [
        {
          startTime: "09:00 AM",
          endTime: "01:00 PM",
          slotDuration: 30
        }
      ]
    }
  ]
};

async function testSimplifiedSlots() {
  try {
    console.log('🧪 Testing Simplified Time Slot APIs...\n');

    // Step 1: Login as a doctor
    console.log('1. Logging in as doctor...');
    const loginResponse = await axios.post(`${BASE_URL}/auth/login`, {
      phoneNumber: '9876543210',
      password: 'test123'
    });

    if (!loginResponse.data.success) {
      throw new Error('Login failed: ' + loginResponse.data.message);
    }

    const token = loginResponse.data.data.token;
    const headers = { Authorization: `Bearer ${token}` };

    console.log('✅ Login successful\n');

    // Step 2: Get current time slots (should be empty initially)
    console.log('2. Getting current time slots...');
    const getResponse = await axios.get(`${BASE_URL}/doctor/slots`, { headers });
    
    if (getResponse.data.success) {
      console.log('✅ Get time slots successful');
      console.log('Current schedule:', JSON.stringify(getResponse.data.data.weekSchedule, null, 2));
    } else {
      console.log('❌ Get time slots failed:', getResponse.data.message);
    }
    console.log('');

    // Step 3: Create/Update time slots with new structure
    console.log('3. Creating/Updating time slots with new week schedule structure...');
    const createResponse = await axios.post(`${BASE_URL}/doctor/slots`, testWeekSchedule, { headers });
    
    if (createResponse.data.success) {
      console.log('✅ Create/Update time slots successful');
      console.log('Response:', JSON.stringify(createResponse.data.data.weekSchedule, null, 2));
    } else {
      console.log('❌ Create/Update time slots failed:', createResponse.data.message);
    }
    console.log('');

    // Step 4: Get time slots again to verify they were saved
    console.log('4. Getting time slots again to verify...');
    const getAgainResponse = await axios.get(`${BASE_URL}/doctor/slots`, { headers });
    
    if (getAgainResponse.data.success) {
      console.log('✅ Get time slots successful');
      console.log('Saved schedule:', JSON.stringify(getAgainResponse.data.data.weekSchedule, null, 2));
      
      // Verify the structure
      const schedule = getAgainResponse.data.data.weekSchedule;
      if (schedule.length === 7) {
        console.log('✅ Week schedule has 7 days');
      }
      
      const monday = schedule.find(day => day.day === 'monday');
      if (monday && monday.timeRanges.length === 2) {
        console.log('✅ Monday has 2 time ranges as expected');
      }
      
      const sunday = schedule.find(day => day.day === 'sunday');
      if (sunday && !sunday.isAvailable && sunday.timeRanges.length === 0) {
        console.log('✅ Sunday is unavailable as expected');
      }
    } else {
      console.log('❌ Get time slots failed:', getAgainResponse.data.message);
    }

    console.log('\n🎉 All tests completed successfully!');

  } catch (error) {
    console.error('❌ Test failed:', error.response?.data || error.message);
  }
}

// Run the test
testSimplifiedSlots();
