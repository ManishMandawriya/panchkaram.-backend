const http = require('http');

async function testDoctorAvailability() {
  try {
    console.log('Testing doctor availability API...');
    
    const options = {
      hostname: 'localhost',
      port: 3000,
      path: '/api/doctors/2',
      method: 'GET',
      headers: {
        'Content-Type': 'application/json'
      }
    };

    const response = await new Promise((resolve, reject) => {
      const req = http.request(options, (res) => {
        let data = '';
        res.on('data', (chunk) => {
          data += chunk;
        });
        res.on('end', () => {
          resolve(JSON.parse(data));
        });
      });
      
      req.on('error', (error) => {
        reject(error);
      });
      
      req.end();
    });

    if (response.success) {
      console.log('✅ API call successful');
      
      // Check Monday 10:00AM slot specifically
      const mondaySlots = response.data.doctor.availability.monday?.timeSlots || [];
      const tenAMSlot = mondaySlots.find(slot => slot.time === '10:00AM');
      
      if (tenAMSlot) {
        console.log('🕐 Monday 10:00AM slot status:');
        console.log(`   - Time: ${tenAMSlot.time}`);
        console.log(`   - Available: ${tenAMSlot.isAvailable}`);
        console.log(`   - Is Booked: ${tenAMSlot.isBooked}`);
        console.log(`   - Duration: ${tenAMSlot.duration} minutes`);
        
        if (tenAMSlot.isBooked) {
          console.log('✅ SUCCESS: Slot correctly shows as booked!');
        } else {
          console.log('❌ ISSUE: Slot should be booked but shows as available');
        }
      } else {
        console.log('❌ Monday 10:00AM slot not found');
      }
      
      // Show a few other Monday slots for comparison
      console.log('\n📋 Other Monday slots:');
      mondaySlots.slice(0, 5).forEach(slot => {
        console.log(`   ${slot.time}: Available=${slot.isAvailable}, Booked=${slot.isBooked}`);
      });
      
    } else {
      console.log('❌ API call failed:', response.message);
    }

  } catch (error) {
    console.error('Error testing API:', error.message);
  }
}

testDoctorAvailability();