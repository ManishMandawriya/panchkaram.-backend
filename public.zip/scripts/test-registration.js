const axios = require('axios');

const API_BASE_URL = 'http://localhost:3000/api';

async function testRegistration() {
  try {
    console.log('🧪 Testing Registration API with confirmPassword...\n');

    const registrationData = {
      role: "patient",
      email: "patient3@yopmail.com",
      password: "Test@123",
      confirmPassword: "Test@123",
      phoneNumber: "1234567890",
      fullName: "John Doe"
    };

    console.log('📤 Sending registration request...');
    console.log('Request data:', JSON.stringify(registrationData, null, 2));

    const response = await axios.post(`${API_BASE_URL}/auth/register`, registrationData, {
      headers: {
        'Content-Type': 'application/json'
      }
    });

    console.log('\n✅ Registration successful!');
    console.log('Response:', JSON.stringify(response.data, null, 2));

  } catch (error) {
    console.log('\n❌ Registration failed!');
    if (error.response) {
      console.log('Status:', error.response.status);
      console.log('Response:', JSON.stringify(error.response.data, null, 2));
    } else {
      console.log('Error:', error.message);
    }
  }
}

// Test with mismatched passwords
async function testMismatchedPasswords() {
  try {
    console.log('\n🧪 Testing Registration API with mismatched passwords...\n');

    const registrationData = {
      role: "patient",
      email: "patient4@yopmail.com",
      password: "Test@123",
      confirmPassword: "DifferentPassword",
      phoneNumber: "1234567891",
      fullName: "Jane Doe"
    };

    console.log('📤 Sending registration request with mismatched passwords...');
    console.log('Request data:', JSON.stringify(registrationData, null, 2));

    const response = await axios.post(`${API_BASE_URL}/auth/register`, registrationData, {
      headers: {
        'Content-Type': 'application/json'
      }
    });

    console.log('\n❌ This should have failed but succeeded!');
    console.log('Response:', JSON.stringify(response.data, null, 2));

  } catch (error) {
    console.log('\n✅ Correctly rejected mismatched passwords!');
    if (error.response) {
      console.log('Status:', error.response.status);
      console.log('Response:', JSON.stringify(error.response.data, null, 2));
    } else {
      console.log('Error:', error.message);
    }
  }
}

// Test without confirmPassword
async function testWithoutConfirmPassword() {
  try {
    console.log('\n🧪 Testing Registration API without confirmPassword...\n');

    const registrationData = {
      role: "patient",
      email: "patient5@yopmail.com",
      password: "Test@123",
      phoneNumber: "1234567892",
      fullName: "Bob Doe"
    };

    console.log('📤 Sending registration request without confirmPassword...');
    console.log('Request data:', JSON.stringify(registrationData, null, 2));

    const response = await axios.post(`${API_BASE_URL}/auth/register`, registrationData, {
      headers: {
        'Content-Type': 'application/json'
      }
    });

    console.log('\n❌ This should have failed but succeeded!');
    console.log('Response:', JSON.stringify(response.data, null, 2));

  } catch (error) {
    console.log('\n✅ Correctly rejected request without confirmPassword!');
    if (error.response) {
      console.log('Status:', error.response.status);
      console.log('Response:', JSON.stringify(error.response.data, null, 2));
    } else {
      console.log('Error:', error.message);
    }
  }
}

async function runTests() {
  await testRegistration();
  await testMismatchedPasswords();
  await testWithoutConfirmPassword();
}

runTests(); 