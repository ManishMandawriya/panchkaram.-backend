const axios = require('axios');

// Configuration
const API_BASE_URL = 'http://localhost:3000/api';
let authToken = null;
let doctorId = null;

// Test doctor credentials
const TEST_DOCTOR = {
  phoneNumber: '9876543210',
  password: 'test123',
  email: 'testdoctor@example.com',
  fullName: 'Test Doctor',
  role: 'doctor',
  doctorId: 'DOC123',
  departmentId: 1,
  experience: 5,
};

async function loginDoctor() {
  try {
    console.log('🔐 Logging in as doctor...');
    const loginData = {
      phoneNumber: TEST_DOCTOR.phoneNumber,
      password: TEST_DOCTOR.password
    };

    const response = await axios.post(`${API_BASE_URL}/auth/login`, loginData, {
      headers: {
        'Content-Type': 'application/json'
      }
    });

    if (response.data.success) {
      authToken = response.data.data.token;
      doctorId = response.data.data.user.id;
      console.log('✅ Doctor login successful!');
      console.log('Token:', authToken.substring(0, 20) + '...');
      console.log('Doctor ID:', doctorId);
      return true;
    } else {
      console.log('❌ Doctor login failed:', response.data.message);
      return false;
    }
  } catch (error) {
    console.log('❌ Login error:', error.response?.data?.message || error.message);
    return false;
  }
}

async function testDoctorReviews() {
  try {
    console.log('\n🧪 Testing Doctor Reviews APIs...\n');

    if (!authToken) {
      console.log('❌ No authentication token available. Please login first.');
      return;
    }

    const headers = {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${authToken}`
    };

    // Test 1: Get doctor reviews
    console.log('📝 Test 1: Getting doctor reviews...');
    const reviewsResponse = await axios.get(`${API_BASE_URL}/doctor/reviews`, { headers });
    console.log('✅ Get reviews response:');
    console.log('Success:', reviewsResponse.data.success);
    console.log('Message:', reviewsResponse.data.message);
    console.log('Total reviews:', reviewsResponse.data.data?.reviews?.length || 0);
    console.log('Pagination:', reviewsResponse.data.data?.pagination);

    // Test 2: Get reviews with filters
    console.log('\n🔍 Test 2: Getting reviews with filters...');
    const filteredResponse = await axios.get(`${API_BASE_URL}/doctor/reviews?page=1&limit=5&sortBy=rating&sortOrder=DESC`, { headers });
    console.log('✅ Filtered reviews response:');
    console.log('Success:', filteredResponse.data.success);
    console.log('Message:', filteredResponse.data.message);
    console.log('Filtered reviews count:', filteredResponse.data.data?.reviews?.length || 0);

    // Test 3: Get review statistics
    console.log('\n📊 Test 3: Getting review statistics...');
    const statsResponse = await axios.get(`${API_BASE_URL}/doctor/reviews/statistics`, { headers });
    console.log('✅ Review statistics response:');
    console.log('Success:', statsResponse.data.success);
    console.log('Message:', statsResponse.data.message);
    console.log('Statistics:', statsResponse.data.data?.statistics);
    console.log('Recent reviews:', statsResponse.data.data?.recentReviews?.length || 0);

    // Test 4: Get specific review (if reviews exist)
    if (reviewsResponse.data.data?.reviews?.length > 0) {
      console.log('\n🔍 Test 4: Getting specific review...');
      const reviewId = reviewsResponse.data.data.reviews[0].id;
      const specificReviewResponse = await axios.get(`${API_BASE_URL}/doctor/reviews/${reviewId}`, { headers });
      console.log('✅ Specific review response:');
      console.log('Success:', specificReviewResponse.data.success);
      console.log('Message:', specificReviewResponse.data.message);
      console.log('Review ID:', specificReviewResponse.data.data?.review?.id);
      console.log('Rating:', specificReviewResponse.data.data?.review?.rating);
      console.log('Comment:', specificReviewResponse.data.data?.review?.comment);

      // Test 5: Delete review
      console.log('\n🗑️ Test 5: Deleting review...');
      const deleteResponse = await axios.delete(`${API_BASE_URL}/doctor/reviews/${reviewId}`, { headers });
      console.log('✅ Delete review response:');
      console.log('Success:', deleteResponse.data.success);
      console.log('Message:', deleteResponse.data.message);

      // Test 6: Verify review is deleted
      console.log('\n✅ Test 6: Verifying review deletion...');
      try {
        await axios.get(`${API_BASE_URL}/doctor/reviews/${reviewId}`, { headers });
        console.log('❌ Review still exists - deletion failed');
      } catch (error) {
        if (error.response?.status === 400 && error.response?.data?.message === 'Review not found') {
          console.log('✅ Review successfully deleted');
        } else {
          console.log('❌ Unexpected error:', error.response?.data?.message);
        }
      }
    } else {
      console.log('\n⚠️ No reviews found to test specific review operations');
    }

    // Test 7: Test unauthorized access
    console.log('\n🚫 Test 7: Testing unauthorized access...');
    try {
      await axios.get(`${API_BASE_URL}/doctor/reviews`);
      console.log('❌ Should have failed - unauthorized access allowed');
    } catch (error) {
      if (error.response?.status === 401 || error.response?.status === 403) {
        console.log('✅ Unauthorized access properly blocked');
      } else {
        console.log('❌ Unexpected error:', error.response?.status);
      }
    }

    console.log('\n🎉 All doctor reviews tests completed!');

  } catch (error) {
    console.log('\n❌ Error testing doctor reviews:', error.response?.data?.message || error.message);
    
    if (error.response?.data) {
      console.log('Response data:', error.response.data);
    }
  }
}

async function main() {
  console.log('🚀 Starting Doctor Reviews API Tests');
  console.log('====================================\n');

  // First, try to login
  const loginSuccess = await loginDoctor();
  
  if (loginSuccess) {
    await testDoctorReviews();
  } else {
    console.log('\n💡 To test the APIs, you need to:');
    console.log('1. Create a test doctor account');
    console.log('2. Verify their phone number in the database');
    console.log('3. Create some test reviews for the doctor');
    console.log('4. Run this script again');
  }
}

// Run the tests
main().catch(console.error);
