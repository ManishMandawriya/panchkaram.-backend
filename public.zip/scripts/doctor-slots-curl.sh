#!/bin/bash

# Doctor Slot Management API Test Script
# Make sure to replace the TOKEN with actual JWT token

API_BASE_URL="http://localhost:3000/api"
TOKEN="your_jwt_token_here"  # Replace with actual JWT token

echo "🚀 Testing Doctor Slot Management APIs"
echo "======================================"

# Test 1: Get weekly availability
echo -e "\n📅 Test 1: Getting weekly availability..."
curl -X GET "${API_BASE_URL}/doctor/slots/weekly-availability" \
  -H "Authorization: Bearer ${TOKEN}" \
  -H "Content-Type: application/json" \
  -w "\nStatus: %{http_code}\n" \
  | jq '.'

# Test 2: Update weekly availability
echo -e "\n📝 Test 2: Updating weekly availability..."
curl -X PUT "${API_BASE_URL}/doctor/slots/weekly-availability" \
  -H "Authorization: Bearer ${TOKEN}" \
  -H "Content-Type: application/json" \
  -d '{
    "availability": {
      "monday": {
        "startTime": "09:00",
        "endTime": "17:00",
        "isAvailable": true,
        "slotDuration": 30,
        "breakTime": 60
      },
      "tuesday": {
        "startTime": "09:00",
        "endTime": "17:00",
        "isAvailable": true,
        "slotDuration": 30,
        "breakTime": 60
      },
      "wednesday": {
        "startTime": "09:00",
        "endTime": "17:00",
        "isAvailable": true,
        "slotDuration": 30,
        "breakTime": 60
      },
      "thursday": {
        "startTime": "09:00",
        "endTime": "17:00",
        "isAvailable": true,
        "slotDuration": 30,
        "breakTime": 60
      },
      "friday": {
        "startTime": "09:00",
        "endTime": "17:00",
        "isAvailable": true,
        "slotDuration": 30,
        "breakTime": 60
      },
      "saturday": {
        "startTime": "09:00",
        "endTime": "13:00",
        "isAvailable": true,
        "slotDuration": 30,
        "breakTime": 30
      },
      "sunday": {
        "startTime": "10:00",
        "endTime": "14:00",
        "isAvailable": false,
        "slotDuration": 30,
        "breakTime": 60
      }
    }
  }' \
  -w "\nStatus: %{http_code}\n" \
  | jq '.'

# Test 3: Generate time slots for Monday
echo -e "\n⏰ Test 3: Generating time slots for Monday..."
curl -X POST "${API_BASE_URL}/doctor/slots/generate-time-slots" \
  -H "Authorization: Bearer ${TOKEN}" \
  -H "Content-Type: application/json" \
  -d '{
    "dayOfWeek": 1,
    "startTime": "09:00",
    "endTime": "17:00",
    "slotDuration": 30,
    "breakTime": 60,
    "breakStartTime": "12:00",
    "breakEndTime": "13:00"
  }' \
  -w "\nStatus: %{http_code}\n" \
  | jq '.'

# Test 4: Get time slots for Monday
echo -e "\n📋 Test 4: Getting time slots for Monday..."
curl -X GET "${API_BASE_URL}/doctor/slots/time-slots?dayOfWeek=1" \
  -H "Authorization: Bearer ${TOKEN}" \
  -H "Content-Type: application/json" \
  -w "\nStatus: %{http_code}\n" \
  | jq '.'

# Test 5: Get time slots with pagination
echo -e "\n📋 Test 5: Getting time slots with pagination..."
curl -X GET "${API_BASE_URL}/doctor/slots/time-slots?dayOfWeek=1&page=1&limit=5" \
  -H "Authorization: Bearer ${TOKEN}" \
  -H "Content-Type: application/json" \
  -w "\nStatus: %{http_code}\n" \
  | jq '.'

# Test 6: Get availability calendar
echo -e "\n📅 Test 6: Getting availability calendar..."
START_DATE=$(date +%Y-%m-%d)
END_DATE=$(date -d "+7 days" +%Y-%m-%d)

curl -X GET "${API_BASE_URL}/doctor/slots/availability-calendar?startDate=${START_DATE}&endDate=${END_DATE}&includeBooked=true" \
  -H "Authorization: Bearer ${TOKEN}" \
  -H "Content-Type: application/json" \
  -w "\nStatus: %{http_code}\n" \
  | jq '.'

# Test 7: Copy schedule from Monday to Tuesday
echo -e "\n📋 Test 7: Copying schedule from Monday to Tuesday..."
curl -X POST "${API_BASE_URL}/doctor/slots/copy-schedule" \
  -H "Authorization: Bearer ${TOKEN}" \
  -H "Content-Type: application/json" \
  -d '{
    "fromDay": 1,
    "toDay": 2,
    "overwrite": true
  }' \
  -w "\nStatus: %{http_code}\n" \
  | jq '.'

# Test 8: Get slot statistics
echo -e "\n📊 Test 8: Getting slot statistics..."
curl -X GET "${API_BASE_URL}/doctor/slots/statistics" \
  -H "Authorization: Bearer ${TOKEN}" \
  -H "Content-Type: application/json" \
  -w "\nStatus: %{http_code}\n" \
  | jq '.'

# Test 9: Test unauthorized access (should fail)
echo -e "\n🚫 Test 9: Testing unauthorized access (should fail)..."
curl -X GET "${API_BASE_URL}/doctor/slots/weekly-availability" \
  -H "Content-Type: application/json" \
  -w "\nStatus: %{http_code}\n" \
  | jq '.'

# Test 10: Update specific time slot (replace SLOT_ID with actual ID)
echo -e "\n✏️ Test 10: Updating specific time slot..."
SLOT_ID="1"  # Replace with actual slot ID

curl -X PUT "${API_BASE_URL}/doctor/slots/time-slots/${SLOT_ID}" \
  -H "Authorization: Bearer ${TOKEN}" \
  -H "Content-Type: application/json" \
  -d '{
    "isAvailable": false,
    "duration": 45,
    "notes": "Lunch break"
  }' \
  -w "\nStatus: %{http_code}\n" \
  | jq '.'

# Test 11: Bulk update time slots
echo -e "\n🔄 Test 11: Bulk updating time slots..."
curl -X POST "${API_BASE_URL}/doctor/slots/bulk-update" \
  -H "Authorization: Bearer ${TOKEN}" \
  -H "Content-Type: application/json" \
  -d '{
    "dayOfWeek": 1,
    "updates": [
      {
        "id": 1,
        "isAvailable": false,
        "duration": 60,
        "notes": "Bulk updated slot 1"
      },
      {
        "id": 2,
        "isAvailable": false,
        "duration": 60,
        "notes": "Bulk updated slot 2"
      }
    ]
  }' \
  -w "\nStatus: %{http_code}\n" \
  | jq '.'

# Test 12: Delete specific time slot (replace SLOT_ID with actual ID)
echo -e "\n🗑️ Test 12: Deleting specific time slot..."
SLOT_ID="1"  # Replace with actual slot ID

curl -X DELETE "${API_BASE_URL}/doctor/slots/time-slots/${SLOT_ID}" \
  -H "Authorization: Bearer ${TOKEN}" \
  -H "Content-Type: application/json" \
  -w "\nStatus: %{http_code}\n" \
  | jq '.'

echo -e "\n🎉 All doctor slot management API tests completed!"
echo -e "\n💡 Note: Some tests may fail if the required data doesn't exist."
echo -e "Make sure to replace TOKEN and SLOT_ID with actual values."

