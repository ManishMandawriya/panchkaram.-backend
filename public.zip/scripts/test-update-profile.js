const http = require('http');

// First, let's try to login to get a token (you'll need to replace with actual credentials)
async function testUpdateProfile() {
  try {
    console.log('Testing Update Profile API...');
    
    // Note: In a real test, you would first login to get a JWT token
    // For demonstration, I'll show the API structure
    
    const updateProfileData = {
      fullName: 'John Smith',
      email: 'john.smith@example.com',
      phoneNumber: '9876543210',
      location: 'Los Angeles, CA',
      gender: 'male',
      dateOfBirth: '1990-01-15'
    };

    console.log('Sample Update Profile Request Body:');
    console.log(JSON.stringify(updateProfileData, null, 2));
    
    console.log('\n📋 API Details:');
    console.log('Endpoint: PUT /api/auth/profile');
    console.log('Headers: Authorization: Bearer <JWT_TOKEN>');
    console.log('Content-Type: application/json');
    
    console.log('\n✨ Features:');
    console.log('- Updates user profile with 6 required fields');
    console.log('- Full Name (required)');
    console.log('- Email Id (required, validated for uniqueness)');
    console.log('- Phone Number (required, 10 digits, validated for uniqueness)');
    console.log('- Location (required)');
    console.log('- Gender (required: male/female/other)');
    console.log('- Date of Birth (required, DD/MM/YYYY format)');
    
    console.log('\n🔒 Security:');
    console.log('- Requires JWT authentication');
    console.log('- Validates all input fields');
    console.log('- Prevents duplicate email/phone');
    console.log('- Role-based access control');

    // Test the docs endpoint to show it's included
    const options = {
      hostname: 'localhost',
      port: 3000,
      path: '/api/docs',
      method: 'GET',
      headers: {
        'Content-Type': 'application/json'
      }
    };

    const response = await new Promise((resolve, reject) => {
      const req = http.request(options, (res) => {
        let data = '';
        res.on('data', (chunk) => {
          data += chunk;
        });
        res.on('end', () => {
          resolve(JSON.parse(data));
        });
      });
      
      req.on('error', (error) => {
        reject(error);
      });
      
      req.end();
    });

    if (response.success && response.endpoints.auth['PUT /auth/profile']) {
      console.log('\n✅ Update Profile API successfully added to documentation');
      console.log('Documented as:', response.endpoints.auth['PUT /auth/profile']);
    }

  } catch (error) {
    console.error('Error:', error.message);
  }
}

testUpdateProfile();