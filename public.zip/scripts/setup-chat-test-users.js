const axios = require('axios');
const bcrypt = require('bcryptjs');

const BASE_URL = 'http://localhost:3000/api';

const log = (message, color = 'white') => {
  const colors = {
    red: '\x1b[31m',
    green: '\x1b[32m',
    yellow: '\x1b[33m',
    blue: '\x1b[34m',
    magenta: '\x1b[35m',
    cyan: '\x1b[36m',
    white: '\x1b[37m',
    bright: '\x1b[1m'
  };
  console.log(`${colors[color] || colors.white}${message}\x1b[0m`);
};

async function setupTestUsers() {
  log('🚀 Setting up test users for WebSocket chat', 'bright');
  
  try {
    // Test patient user
    log('\n👤 Creating test patient...', 'cyan');
    const patientData = {
      role: 'patient',
      fullName: 'Test Patient',
      email: 'patient@test.com',
      phoneNumber: '1234567890',
      password: 'password123',
      confirmPassword: 'password123'
    };

    try {
      const patientResponse = await axios.post(`${BASE_URL}/auth/register`, patientData);
      if (patientResponse.data.success) {
        log('✅ Test patient created successfully', 'green');
        log(`   Email: ${patientData.email}`, 'cyan');
        log(`   Password: ${patientData.password}`, 'cyan');
      }
    } catch (error) {
      if (error.response?.data?.message?.includes('already exists')) {
        log('ℹ️  Test patient already exists', 'yellow');
      } else {
        log(`❌ Failed to create test patient: ${error.response?.data?.message || error.message}`, 'red');
      }
    }

    // Test doctor user
    log('\n👨‍⚕️ Creating test doctor...', 'cyan');
    const doctorData = {
      role: 'doctor',
      fullName: 'Test Doctor',
      email: 'doctor@test.com',
      phoneNumber: '1234567891',
      password: 'password123',
      confirmPassword: 'password123',
      doctorId: 'DOC001',
      departmentId: 1,
      experience: '10 years'
    };

    try {
      const doctorResponse = await axios.post(`${BASE_URL}/auth/register`, doctorData);
      if (doctorResponse.data.success) {
        log('✅ Test doctor created successfully', 'green');
        log(`   Email: ${doctorData.email}`, 'cyan');
        log(`   Password: ${doctorData.password}`, 'cyan');
      }
    } catch (error) {
      if (error.response?.data?.message?.includes('already exists')) {
        log('ℹ️  Test doctor already exists', 'yellow');
      } else {
        log(`❌ Failed to create test doctor: ${error.response?.data?.message || error.message}`, 'red');
      }
    }

    // Create doctor service
    log('\n💰 Creating doctor service...', 'cyan');
    try {
      // First login as doctor to get token
      const loginResponse = await axios.post(`${BASE_URL}/auth/login`, {
        phoneNumber: '+1234567891',
        password: 'password123'
      });

      if (loginResponse.data.success) {
        const token = loginResponse.data.data.token;
        
        const serviceData = {
          chatPrice: 50,
          chatEnabled: true,
          audioCallPrice: 100,
          audioCallEnabled: true,
          videoCallPrice: 150,
          videoCallEnabled: true
        };

        const serviceResponse = await axios.post(`${BASE_URL}/doctor/services`, serviceData, {
          headers: { Authorization: `Bearer ${token}` }
        });

        if (serviceResponse.data.success) {
          log('✅ Doctor service created successfully', 'green');
        }
      }
    } catch (error) {
      log(`ℹ️  Doctor service setup: ${error.response?.data?.message || error.message}`, 'yellow');
    }

    log('\n🎉 Test users setup completed!', 'green');
    log('\n📋 Test Credentials:', 'bright');
    log('   Patient: patient@test.com / password123', 'cyan');
    log('   Doctor: doctor@test.com / password123', 'cyan');
    log('\n🔗 Next steps:', 'bright');
    log('   1. Run: node scripts/test-websocket-chat.js', 'cyan');
    log('   2. Or visit: http://localhost:3000/chat-test.html', 'cyan');

  } catch (error) {
    log(`❌ Setup failed: ${error.message}`, 'red');
  }
}

setupTestUsers().catch(error => {
  log(`❌ Unexpected error: ${error.message}`, 'red');
  process.exit(1);
});
