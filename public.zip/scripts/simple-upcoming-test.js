const axios = require('axios');

const API_BASE_URL = 'http://localhost:3000/api';

async function testUpcomingAppointments() {
  try {
    console.log('🚀 Testing Upcoming Appointments API...\n');

    // Step 1: Login
    console.log('🔐 Step 1: Logging in...');
    const loginResponse = await axios.post(`${API_BASE_URL}/auth/login`, {
      phoneNumber: '1234567890',
      password: 'Test@123'
    });

    if (!loginResponse.data.success) {
      console.log('❌ Login failed:', loginResponse.data.message);
      return;
    }

    const token = loginResponse.data.data.token;
    console.log('✅ Login successful!');

    const headers = {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    };

    // Step 2: Test upcoming appointments API
    console.log('\n📋 Step 2: Testing upcoming appointments API...');

    // Test all appointments
    console.log('\n📅 Getting all appointments...');
    const allResponse = await axios.get(`${API_BASE_URL}/appointments/my`, { headers });
    console.log('✅ All appointments response:');
    console.log('Success:', allResponse.data.success);
    console.log('Message:', allResponse.data.message);
    console.log('Total appointments:', allResponse.data.data.appointments.length);
    console.log('Filter:', allResponse.data.data.filter);

    // Test future appointments (upcoming)
    console.log('\n📅 Getting future appointments (upcoming)...');
    const futureResponse = await axios.get(`${API_BASE_URL}/appointments/my?filter=future`, { headers });
    console.log('✅ Future appointments response:');
    console.log('Success:', futureResponse.data.success);
    console.log('Message:', futureResponse.data.message);
    console.log('Total future appointments:', futureResponse.data.data.appointments.length);
    console.log('Filter:', futureResponse.data.data.filter);

    // Test past appointments
    console.log('\n📅 Getting past appointments...');
    const pastResponse = await axios.get(`${API_BASE_URL}/appointments/my?filter=past`, { headers });
    console.log('✅ Past appointments response:');
    console.log('Success:', pastResponse.data.success);
    console.log('Message:', pastResponse.data.message);
    console.log('Total past appointments:', pastResponse.data.data.appointments.length);
    console.log('Filter:', pastResponse.data.data.filter);

    // Test pagination
    console.log('\n📅 Testing pagination...');
    const paginatedResponse = await axios.get(`${API_BASE_URL}/appointments/my?filter=future&page=1&limit=5`, { headers });
    console.log('✅ Paginated response:');
    console.log('Success:', paginatedResponse.data.success);
    console.log('Current page:', paginatedResponse.data.data.pagination.currentPage);
    console.log('Total pages:', paginatedResponse.data.data.pagination.totalPages);
    console.log('Items per page:', paginatedResponse.data.data.pagination.itemsPerPage);

    // Step 3: Test without authentication
    console.log('\n🔒 Step 3: Testing without authentication (should fail)...');
    try {
      await axios.get(`${API_BASE_URL}/appointments/my?filter=future`, {
        headers: { 'Content-Type': 'application/json' }
      });
      console.log('❌ This should have failed but succeeded!');
    } catch (error) {
      console.log('✅ Correctly rejected request without authentication!');
      console.log('Status:', error.response.status);
      console.log('Message:', error.response.data.message);
    }

    console.log('\n🎉 All tests completed successfully!');
    console.log('\n📊 Summary:');
    console.log('- ✅ Authentication working');
    console.log('- ✅ Upcoming appointments API working');
    console.log('- ✅ Filter functionality working (all/past/future)');
    console.log('- ✅ Pagination working');
    console.log('- ✅ Security working (rejects unauthenticated requests)');

  } catch (error) {
    console.log('\n❌ Test failed!');
    if (error.response) {
      console.log('Status:', error.response.status);
      console.log('Response:', JSON.stringify(error.response.data, null, 2));
    } else {
      console.log('Error:', error.message);
    }
  }
}

testUpcomingAppointments(); 