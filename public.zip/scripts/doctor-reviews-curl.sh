#!/bin/bash

# Doctor Reviews API Test Script
# Replace TOKEN with actual JWT token from doctor login

TOKEN="your_jwt_token_here"
BASE_URL="http://localhost:3000/api"

echo "🧪 Testing Doctor Reviews API"
echo "=============================="

# Test 1: Get doctor reviews
echo -e "\n📝 Test 1: Getting doctor reviews..."
curl -X GET "${BASE_URL}/doctor/reviews" \
  -H "Authorization: Bearer ${TOKEN}" \
  -H "Content-Type: application/json"

# Test 2: Get reviews with filters
echo -e "\n\n🔍 Test 2: Getting reviews with filters..."
curl -X GET "${BASE_URL}/doctor/reviews?page=1&limit=5&sortBy=rating&sortOrder=DESC" \
  -H "Authorization: Bearer ${TOKEN}" \
  -H "Content-Type: application/json"

# Test 3: Get review statistics
echo -e "\n\n📊 Test 3: Getting review statistics..."
curl -X GET "${BASE_URL}/doctor/reviews/statistics" \
  -H "Authorization: Bearer ${TOKEN}" \
  -H "Content-Type: application/json"

# Test 4: Get specific review (replace REVIEW_ID with actual ID)
echo -e "\n\n🔍 Test 4: Getting specific review..."
REVIEW_ID="1"
curl -X GET "${BASE_URL}/doctor/reviews/${REVIEW_ID}" \
  -H "Authorization: Bearer ${TOKEN}" \
  -H "Content-Type: application/json"

# Test 5: Delete review (replace REVIEW_ID with actual ID)
echo -e "\n\n🗑️ Test 5: Deleting review..."
REVIEW_ID="1"
curl -X DELETE "${BASE_URL}/doctor/reviews/${REVIEW_ID}" \
  -H "Authorization: Bearer ${TOKEN}" \
  -H "Content-Type: application/json"

# Test 6: Test unauthorized access
echo -e "\n\n🚫 Test 6: Testing unauthorized access..."
curl -X GET "${BASE_URL}/doctor/reviews" \
  -H "Content-Type: application/json"

echo -e "\n\n💡 Note: Replace TOKEN and REVIEW_ID with actual values."
echo -e "Make sure the server is running and the doctor account exists."
