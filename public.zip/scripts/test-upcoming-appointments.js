const axios = require('axios');

const API_BASE_URL = 'http://localhost:3000/api';

// Test data - you'll need to replace these with actual values from your database
const TEST_PATIENT_CREDENTIALS = {
  phoneNumber: '1234567890',
  password: 'Test@123'
};

let authToken = '';

async function login() {
  try {
    console.log('🔐 Logging in to get authentication token...\n');
    
    const loginData = {
      phoneNumber: TEST_PATIENT_CREDENTIALS.phoneNumber,
      password: TEST_PATIENT_CREDENTIALS.password
    };

    const response = await axios.post(`${API_BASE_URL}/auth/login`, loginData, {
      headers: {
        'Content-Type': 'application/json'
      }
    });

    if (response.data.success) {
      authToken = response.data.data.token;
      console.log('✅ Login successful!');
      console.log('Token received:', authToken.substring(0, 20) + '...');
      return true;
    } else {
      console.log('❌ Login failed:', response.data.message);
      return false;
    }
  } catch (error) {
    console.log('❌ Login error:', error.response?.data?.message || error.message);
    return false;
  }
}

async function testUpcomingAppointments() {
  try {
    console.log('\n🧪 Testing Upcoming Appointments API...\n');

    if (!authToken) {
      console.log('❌ No authentication token available. Please login first.');
      return;
    }

    const headers = {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${authToken}`
    };

    // Test 1: Get all appointments
    console.log('📋 Test 1: Getting all appointments...');
    const allResponse = await axios.get(`${API_BASE_URL}/appointments/my`, { headers });
    console.log('All appointments response:', JSON.stringify(allResponse.data, null, 2));

    // Test 2: Get future appointments (upcoming)
    console.log('\n📋 Test 2: Getting future appointments (upcoming)...');
    const futureResponse = await axios.get(`${API_BASE_URL}/appointments/my?filter=future`, { headers });
    console.log('Future appointments response:', JSON.stringify(futureResponse.data, null, 2));

    // Test 3: Get past appointments
    console.log('\n📋 Test 3: Getting past appointments...');
    const pastResponse = await axios.get(`${API_BASE_URL}/appointments/my?filter=past`, { headers });
    console.log('Past appointments response:', JSON.stringify(pastResponse.data, null, 2));

    // Test 4: Test pagination
    console.log('\n📋 Test 4: Testing pagination...');
    const paginatedResponse = await axios.get(`${API_BASE_URL}/appointments/my?filter=future&page=1&limit=5`, { headers });
    console.log('Paginated future appointments response:', JSON.stringify(paginatedResponse.data, null, 2));

  } catch (error) {
    console.log('\n❌ API test failed!');
    if (error.response) {
      console.log('Status:', error.response.status);
      console.log('Response:', JSON.stringify(error.response.data, null, 2));
    } else {
      console.log('Error:', error.message);
    }
  }
}

async function testWithoutAuth() {
  try {
    console.log('\n🧪 Test 5: Testing without authentication (should fail)...\n');
    
    const response = await axios.get(`${API_BASE_URL}/appointments/my?filter=future`, {
      headers: {
        'Content-Type': 'application/json'
      }
    });

    console.log('❌ This should have failed but succeeded!');
    console.log('Response:', JSON.stringify(response.data, null, 2));

  } catch (error) {
    console.log('✅ Correctly rejected request without authentication!');
    if (error.response) {
      console.log('Status:', error.response.status);
      console.log('Response:', JSON.stringify(error.response.data, null, 2));
    } else {
      console.log('Error:', error.message);
    }
  }
}

async function runTests() {
  console.log('🚀 Starting Upcoming Appointments API Tests...\n');
  
  // First login to get token
  const loginSuccess = await login();
  
  if (loginSuccess) {
    // Test the upcoming appointments API
    await testUpcomingAppointments();
  } else {
    console.log('\n⚠️  Skipping API tests due to login failure.');
    console.log('Please ensure you have a registered patient with these credentials:');
    console.log('Phone:', TEST_PATIENT_CREDENTIALS.phoneNumber);
    console.log('Password:', TEST_PATIENT_CREDENTIALS.password);
  }
  
  // Test without authentication
  await testWithoutAuth();
  
  console.log('\n🏁 Tests completed!');
}

runTests(); 