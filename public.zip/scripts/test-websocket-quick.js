const io = require('socket.io-client');
const axios = require('axios');

const BASE_URL = 'http://localhost:3000';

// Colors for console output
const colors = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  cyan: '\x1b[36m'
};

function log(message, color = 'reset') {
  console.log(`${colors[color]}${message}${colors.reset}`);
}

async function quickTest() {
  log('🚀 Quick WebSocket Chat Test', 'bright');
  log('Testing basic connectivity and functionality...', 'cyan');

  try {
    // Test 1: Health check
    log('\n📊 Test 1: Health Check', 'yellow');
    const healthResponse = await axios.get(`${BASE_URL}/health`);
    if (healthResponse.status === 200) {
      log('✅ Server is running and healthy', 'green');
    }

    // Test 2: Try to connect to WebSocket (without auth for basic connectivity)
    log('\n🔌 Test 2: WebSocket Connection Test', 'yellow');
    try {
      const socket = io(BASE_URL, {
        transports: ['websocket'],
        timeout: 5000
      });

      socket.on('connect', () => {
        log('✅ WebSocket server is accessible', 'green');
        socket.disconnect();
      });

      socket.on('connect_error', (error) => {
        log(`❌ WebSocket connection failed: ${error.message}`, 'red');
      });

      // Wait for connection or timeout
      await new Promise((resolve) => {
        setTimeout(() => {
          if (socket.connected) {
            socket.disconnect();
          }
          resolve();
        }, 3000);
      });

    } catch (error) {
      log(`❌ WebSocket test failed: ${error.message}`, 'red');
    }

    // Test 3: Check if chat test page is accessible
    log('\n🌐 Test 3: Chat Test Page', 'yellow');
    try {
      const pageResponse = await axios.get(`${BASE_URL}/chat-test.html`);
      if (pageResponse.status === 200) {
        log('✅ Chat test page is accessible', 'green');
        log(`   Visit: ${BASE_URL}/chat-test.html`, 'cyan');
      }
    } catch (error) {
      log(`❌ Chat test page not accessible: ${error.message}`, 'red');
    }

    log('\n🎉 Quick test completed!', 'green');
    log('📋 Next steps:', 'bright');
    log('   1. Start your MySQL database', 'cyan');
    log('   2. Run: npm run dev', 'cyan');
    log('   3. Test with: node scripts/test-websocket-chat.js', 'cyan');
    log('   4. Or visit: http://localhost:3000/chat-test.html', 'cyan');

  } catch (error) {
    log(`❌ Test failed: ${error.message}`, 'red');
  }
}

quickTest().catch(error => {
  log(`❌ Unexpected error: ${error.message}`, 'red');
  process.exit(1);
});
