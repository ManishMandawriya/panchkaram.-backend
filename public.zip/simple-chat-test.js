const { Sequelize } = require('sequelize');

// Database connection
const sequelize = new Sequelize('panchakarma', 'root', '', {
  host: 'localhost',
  dialect: 'mysql',
  logging: false
});

async function testChatCreation() {
  try {
    await sequelize.authenticate();
    console.log('✅ Database connection established.');

    // Test data
    const doctorId = 1;
    const patientId = 1;

    console.log(`\n🔧 Testing chat creation for doctor ${doctorId} and patient ${patientId}...`);

    // Check if chat exists
    const [existingChats] = await sequelize.query(`
      SELECT * FROM chats WHERE doctor_id = ${doctorId} AND patient_id = ${patientId}
    `);

    if (existingChats.length > 0) {
      console.log('✅ Chat already exists:', existingChats[0]);
    } else {
      console.log('📝 No existing chat found, creating new one...');
      
      // Create a new chat
      await sequelize.query(`
        INSERT INTO chats (doctor_id, patient_id, is_active, created_at, updated_at) 
        VALUES (${doctorId}, ${patientId}, 1, NOW(), NOW())
      `);
      
      const [newChat] = await sequelize.query(`
        SELECT * FROM chats WHERE doctor_id = ${doctorId} AND patient_id = ${patientId}
      `);
      
      console.log('✅ New chat created:', newChat[0]);
    }

    // Get the chat
    const [chats] = await sequelize.query(`
      SELECT * FROM chats WHERE doctor_id = ${doctorId} AND patient_id = ${patientId}
    `);

    if (chats.length > 0) {
      const chat = chats[0];
      console.log('\n📋 Chat details:', chat);

      // Create a chat session
      const sessionId = `${doctorId}-${patientId}-${Date.now()}`;
      console.log(`\n🔧 Creating chat session with ID: ${sessionId}`);

      await sequelize.query(`
        INSERT INTO chat_sessions (
          chat_id, session_id, doctor_id, patient_id, 
          session_type, session_token, status, start_time, is_active, created_at, updated_at
        ) VALUES (
          ${chat.id}, '${sessionId}', ${doctorId}, ${patientId}, 
          'chat', 'test-token-123', 'scheduled', NOW(), 1, NOW(), NOW()
        )
      `);

      // Verify chat session was created
      const [chatSessions] = await sequelize.query(`
        SELECT * FROM chat_sessions WHERE chat_id = ${chat.id}
      `);

      if (chatSessions.length > 0) {
        console.log('✅ Chat session created successfully!');
        console.log('📋 Chat session details:', chatSessions[0]);
        console.log('📋 Session ID for Socket.IO:', chatSessions[0].session_id);
      } else {
        console.log('❌ Chat session was not created');
      }
    } else {
      console.log('❌ No chat found');
    }

  } catch (error) {
    console.error('❌ Error testing chat creation:', error.message);
  } finally {
    await sequelize.close();
  }
}

// Run the test
testChatCreation()
  .then(() => {
    console.log('\n🎉 Chat creation test completed!');
    process.exit(0);
  })
  .catch((error) => {
    console.error('❌ Test failed:', error);
    process.exit(1);
  });
