const { Sequelize } = require('sequelize');

// Database connection
const sequelize = new Sequelize('panchakarma', 'root', '', {
  host: 'localhost',
  dialect: 'mysql',
  logging: false
});

async function fixChatMessagesTable() {
  try {
    await sequelize.authenticate();
    console.log('✅ Database connection established.');

    // Check current chat_messages table structure
    const [columns] = await sequelize.query('DESCRIBE chat_messages');
    console.log('\n📋 Current chat_messages table structure:');
    columns.forEach(row => {
      console.log(`  ${row.Field} - ${row.Type}`);
    });

    // Check if is_edited column exists
    const hasIsEdited = columns.some(col => col.Field === 'is_edited');
    const hasIsDeleted = columns.some(col => col.Field === 'is_deleted');
    const hasIsActive = columns.some(col => col.Field === 'is_active');
    
    if (!hasIsEdited) {
      console.log('\n🔧 Adding missing is_edited column to chat_messages table...');
      await sequelize.query('ALTER TABLE chat_messages ADD COLUMN is_edited BOOLEAN DEFAULT FALSE');
      console.log('✅ Added is_edited column');
    } else {
      console.log('✅ is_edited column already exists');
    }

    if (!hasIsDeleted) {
      console.log('\n🔧 Adding missing is_deleted column to chat_messages table...');
      await sequelize.query('ALTER TABLE chat_messages ADD COLUMN is_deleted BOOLEAN DEFAULT FALSE');
      console.log('✅ Added is_deleted column');
    } else {
      console.log('✅ is_deleted column already exists');
    }

    if (!hasIsActive) {
      console.log('\n🔧 Adding missing is_active column to chat_messages table...');
      await sequelize.query('ALTER TABLE chat_messages ADD COLUMN is_active BOOLEAN DEFAULT TRUE');
      console.log('✅ Added is_active column');
    } else {
      console.log('✅ is_active column already exists');
    }

    // Show updated structure
    const [updatedColumns] = await sequelize.query('DESCRIBE chat_messages');
    console.log('\n📋 Updated chat_messages table structure:');
    updatedColumns.forEach(row => {
      console.log(`  ${row.Field} - ${row.Type}`);
    });

    console.log('\n🎉 Chat messages table fixed successfully!');

  } catch (error) {
    console.error('❌ Error fixing chat_messages table:', error.message);
    throw error;
  } finally {
    await sequelize.close();
  }
}

// Run the script
fixChatMessagesTable()
  .then(() => {
    console.log('\n🎉 Chat messages table fixed successfully!');
    process.exit(0);
  })
  .catch((error) => {
    console.error('❌ Failed to fix chat_messages table:', error);
    process.exit(1);
  });
