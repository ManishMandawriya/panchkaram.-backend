const { Sequelize } = require('sequelize');

// Database connection
const sequelize = new Sequelize('panchakarma', 'root', '', {
  host: 'localhost',
  dialect: 'mysql',
  logging: false
});

async function fixUserTable() {
  try {
    await sequelize.authenticate();
    console.log('✅ Database connection established.');

    // Add missing columns to users table
    const alterQueries = [
      // Add about_yourself column
      "ALTER TABLE users ADD COLUMN IF NOT EXISTS about_yourself TEXT",
      
      // Add degrees column
      "ALTER TABLE users ADD COLUMN IF NOT EXISTS degrees JSON",
      
      // Add specializations column
      "ALTER TABLE users ADD COLUMN IF NOT EXISTS specializations JSON",
      
      // Add documents column
      "ALTER TABLE users ADD COLUMN IF NOT EXISTS documents JSON",
      
      // Add is_approved column
      "ALTER TABLE users ADD COLUMN IF NOT EXISTS is_approved BOOLEAN DEFAULT TRUE",
      
      // Add approved_at column
      "ALTER TABLE users ADD COLUMN IF NOT EXISTS approved_at DATETIME",
      
      // Add approved_by column
      "ALTER TABLE users ADD COLUMN IF NOT EXISTS approved_by INT",
      
      // Add clinic_name column
      "ALTER TABLE users ADD COLUMN IF NOT EXISTS clinic_name VARCHAR(255)",
      
      // Add permissions column
      "ALTER TABLE users ADD COLUMN IF NOT EXISTS permissions JSON",
      
      // Add rating column
      "ALTER TABLE users ADD COLUMN IF NOT EXISTS rating DECIMAL(3,2) DEFAULT 0.00",
      
      // Add profile_image column if not exists
      "ALTER TABLE users ADD COLUMN IF NOT EXISTS profile_image VARCHAR(500)",
      
      // Add date_of_birth column if not exists
      "ALTER TABLE users ADD COLUMN IF NOT EXISTS date_of_birth DATE",
      
      // Add gender column if not exists
      "ALTER TABLE users ADD COLUMN IF NOT EXISTS gender ENUM('male', 'female', 'other')",
      
      // Add address column if not exists
      "ALTER TABLE users ADD COLUMN IF NOT EXISTS address TEXT",
      
      // Add emergency_contact column if not exists
      "ALTER TABLE users ADD COLUMN IF NOT EXISTS emergency_contact VARCHAR(20)",
      
      // Add medical_history column if not exists
      "ALTER TABLE users ADD COLUMN IF NOT EXISTS medical_history TEXT",
      
      // Add allergies column if not exists
      "ALTER TABLE users ADD COLUMN IF NOT EXISTS allergies TEXT",
      
      // Add current_medications column if not exists
      "ALTER TABLE users ADD COLUMN IF NOT EXISTS current_medications TEXT",
      
      // Add doctor_id column if not exists
      "ALTER TABLE users ADD COLUMN IF NOT EXISTS doctor_id VARCHAR(100)",
      
      // Add department_id column if not exists
      "ALTER TABLE users ADD COLUMN IF NOT EXISTS department_id INT",
      
      // Add experience column if not exists
      "ALTER TABLE users ADD COLUMN IF NOT EXISTS experience TEXT",
      
      // Add qualifications column if not exists
      "ALTER TABLE users ADD COLUMN IF NOT EXISTS qualifications TEXT",
      
      // Add specialization column if not exists
      "ALTER TABLE users ADD COLUMN IF NOT EXISTS specialization VARCHAR(255)",
      
      // Add license_number column if not exists
      "ALTER TABLE users ADD COLUMN IF NOT EXISTS license_number VARCHAR(100)"
    ];

    console.log('🔧 Adding missing columns to users table...');
    
    for (const query of alterQueries) {
      try {
        await sequelize.query(query);
        console.log(`✅ Executed: ${query.substring(0, 50)}...`);
      } catch (error) {
        if (error.message.includes('Duplicate column name')) {
          console.log(`⚠️  Column already exists: ${query.substring(0, 50)}...`);
        } else {
          console.log(`❌ Error: ${error.message}`);
        }
      }
    }

    console.log('✅ Users table schema updated successfully!');
    
    // Show current table structure
    const [results] = await sequelize.query('DESCRIBE users');
    console.log('\n📋 Current users table structure:');
    results.forEach(row => {
      console.log(`${row.Field} - ${row.Type}`);
    });

  } catch (error) {
    console.error('❌ Error fixing user table:', error.message);
    throw error;
  } finally {
    await sequelize.close();
  }
}

// Run the script
fixUserTable()
  .then(() => {
    console.log('\n🎉 Users table fixed successfully!');
    process.exit(0);
  })
  .catch((error) => {
    console.error('❌ Failed to fix users table:', error);
    process.exit(1);
  });
