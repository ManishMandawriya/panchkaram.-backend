# WebSocket Testing Guide for Postman

## 🚀 **Quick Start**

### **1. Import the Collection**
1. Open Postman
2. Click "Import" → "Upload Files"
3. Select `WebSocket_Chat_Postman_Collection.json`
4. Click "Import"

### **2. Set Up Environment Variables**
The collection uses these variables:
- `base_url`: `http://localhost:3000`
- `jwt_token`: Will be auto-filled after login
- `session_id`: Will be auto-filled after creating/joining session
- `doctor_id`: `1`
- `patient_id`: `2`

## 🔐 **Step 1: Authentication**

### **Create Test Users (Optional)**
If you don't have test users, run these first:

1. **Create Test Doctor**
   - Request: `Create Test Users`
   - This creates a doctor with email: `doctor@example.com`

2. **Create Test Patient**
   - Request: `Create Test Patient`
   - This creates a patient with email: `patient@example.com`

### **Login to Get JWT Token**
1. **Login Patient**
   - Request: `Login Patient`
   - Email: `patient@example.com`
   - Password: `password123`
   - ✅ **Auto-saves JWT token to collection variables**

2. **Login Doctor** (for testing both sides)
   - Request: `Login Doctor`
   - Email: `doctor@example.com`
   - Password: `password123`

## 📋 **Step 2: Session Management**

### **Check for Active Session**
1. **Verify Active Session**
   - Request: `Verify Active Session`
   - ✅ **Auto-saves session_id if found**

### **Create New Session**
1. **Create New Session**
   - Request: `Create New Session`
   - ✅ **Auto-saves session_id**

### **Join Session**
1. **Join Session**
   - Request: `Join Session`
   - This marks the user as joined

## 💬 **Step 3: Message Management**

### **Send Messages**
1. **Send Message**
   - Request: `Send Message`
   - Modify the content in the request body

### **Get Messages**
1. **Get Messages**
   - Request: `Get Messages`
   - View all messages in the session

### **Mark Messages as Read**
1. **Mark Messages as Read**
   - Request: `Mark Messages as Read`
   - Update message IDs in the request body

## 🔌 **Step 4: WebSocket Testing**

### **WebSocket Connection in Postman**

1. **Create WebSocket Request**
   - Click "New" → "WebSocket Request"
   - URL: `ws://localhost:3000`
   - Headers:
     ```
     Authorization: Bearer {{jwt_token}}
     ```

2. **Connect to WebSocket**
   - Click "Connect"
   - You should see connection established

### **WebSocket Events to Test**

#### **Join Session**
```json
{
  "event": "join-session",
  "data": "{{session_id}}"
}
```

#### **Send Message**
```json
{
  "event": "send-message",
  "data": {
    "sessionId": "{{session_id}}",
    "content": "Hello from WebSocket!",
    "messageType": "text"
  }
}
```

#### **Start Typing**
```json
{
  "event": "typing-start",
  "data": "{{session_id}}"
}
```

#### **Stop Typing**
```json
{
  "event": "typing-stop",
  "data": "{{session_id}}"
}
```

#### **Mark Messages as Read**
```json
{
  "event": "mark-read",
  "data": [1, 2, 3]
}
```

#### **End Session**
```json
{
  "event": "end-session",
  "data": {}
}
```

## 📡 **WebSocket Event Responses**

### **Server to Client Events**

#### **Session Joined**
```json
{
  "event": "session-joined",
  "data": {
    "sessionId": "session_1_2_abc123",
    "status": "ongoing",
    "sessionType": "chat",
    "participants": {
      "patient": { "id": 2, "name": "Test Patient" },
      "doctor": { "id": 1, "name": "Test Doctor" }
    }
  }
}
```

#### **New Message**
```json
{
  "event": "new-message",
  "data": {
    "id": 1,
    "messageId": "uuid-123",
    "sessionId": "session_1_2_abc123",
    "senderId": 2,
    "senderName": "Test Patient",
    "content": "Hello from WebSocket!",
    "messageType": "text",
    "status": "delivered",
    "sentAt": "2024-01-01T12:00:00Z"
  }
}
```

#### **User Typing**
```json
{
  "event": "user-typing",
  "data": {
    "userId": 2,
    "userName": "Test Patient",
    "userRole": "patient",
    "isTyping": true,
    "timestamp": "2024-01-01T12:00:00Z"
  }
}
```

#### **Messages Read**
```json
{
  "event": "messages-read",
  "data": {
    "messageIds": [1, 2, 3],
    "readBy": 1,
    "readByRole": "doctor",
    "readAt": "2024-01-01T12:00:00Z"
  }
}
```

#### **Session Ended**
```json
{
  "event": "session-ended",
  "data": {
    "sessionId": "session_1_2_abc123",
    "endedBy": 1,
    "endedByRole": "doctor",
    "endTime": "2024-01-01T12:00:00Z",
    "duration": 300
  }
}
```

## 🧪 **Testing Scenarios**

### **Scenario 1: Basic Chat Flow**
1. Login as Patient
2. Create New Session
3. Login as Doctor (in another Postman tab)
4. Join Session (both users)
5. Send messages via WebSocket
6. Test typing indicators
7. Mark messages as read
8. End session

### **Scenario 2: Real-time Testing**
1. Open two WebSocket connections (Patient & Doctor)
2. Join the same session
3. Send messages from both sides
4. Observe real-time message delivery
5. Test typing indicators
6. Test read receipts

### **Scenario 3: Session Management**
1. Create multiple sessions
2. Test session verification
3. Test session joining/leaving
4. Test session ending
5. Verify session status updates

## 🔧 **Troubleshooting**

### **Common Issues**

#### **1. WebSocket Connection Failed**
- Check if server is running on port 3000
- Verify JWT token is valid
- Check CORS settings

#### **2. Authentication Errors**
- Ensure JWT token is properly set
- Check token expiration
- Verify user exists in database

#### **3. Session Not Found**
- Verify session_id is correct
- Check if session is active
- Ensure user has access to session

#### **4. Messages Not Delivered**
- Check if both users are in the session
- Verify session status is "ongoing"
- Check WebSocket connection status

### **Debug Steps**
1. Check server logs for errors
2. Verify database connections
3. Test REST APIs first
4. Check WebSocket connection status
5. Verify event data format

## 📊 **Expected Results**

### **Successful Flow**
1. ✅ WebSocket connects with JWT
2. ✅ Join session successful
3. ✅ Messages sent and received
4. ✅ Typing indicators work
5. ✅ Read receipts update
6. ✅ Session ends properly

### **Error Responses**
```json
{
  "event": "error",
  "data": {
    "message": "Error description"
  }
}
```

## 🎯 **Advanced Testing**

### **Load Testing**
- Open multiple WebSocket connections
- Send messages rapidly
- Test concurrent sessions

### **Error Handling**
- Test with invalid JWT
- Test with expired sessions
- Test with unauthorized access

### **Performance Testing**
- Monitor message delivery time
- Test with large message content
- Test file uploads

## 📝 **Notes**

- **JWT tokens** are automatically saved after login
- **Session IDs** are automatically saved after creation
- **WebSocket events** are real-time
- **REST APIs** and **WebSocket** work together
- **Database** stores all messages and session data

This guide covers all aspects of testing your WebSocket chat system in Postman! 🚀
