const { Sequelize } = require('sequelize');
const bcrypt = require('bcryptjs');

// Database connection
const sequelize = new Sequelize('panchakarma', 'root', '', {
  host: 'localhost',
  dialect: 'mysql',
  logging: false
});

// User model (simplified)
const User = sequelize.define('User', {
  id: {
    type: Sequelize.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  email: {
    type: Sequelize.STRING,
    allowNull: false,
    unique: true
  },
  password: {
    type: Sequelize.STRING,
    allowNull: false
  },
  phoneNumber: {
    type: Sequelize.STRING,
    allowNull: false
  },
  role: {
    type: Sequelize.ENUM('patient', 'doctor', 'admin'),
    defaultValue: 'patient'
  },
  fullName: {
    type: Sequelize.STRING,
    allowNull: true
  },
  isActive: {
    type: Sequelize.BOOLEAN,
    defaultValue: true
  },
  isPhoneVerified: {
    type: Sequelize.BOOLEAN,
    defaultValue: false
  },
  isEmailVerified: {
    type: Sequelize.BOOLEAN,
    defaultValue: false
  }
}, {
  tableName: 'users',
  timestamps: true
});

async function createTestUser() {
  try {
    await sequelize.authenticate();
    console.log('✅ Database connection established.');

    // Check if test user already exists
    const existingUser = await User.findOne({
      where: { email: 'test@example.com' }
    });

    if (existingUser) {
      console.log('✅ Test user already exists:');
      console.log('ID:', existingUser.id);
      console.log('Email:', existingUser.email);
      console.log('Role:', existingUser.role);
      return existingUser;
    }

    // Create test user
    const hashedPassword = await bcrypt.hash('password123', 12);
    const testUser = await User.create({
      fullName: 'Test User',
      email: 'test@example.com',
      password: hashedPassword,
      phoneNumber: '+1234567890',
      role: 'patient',
      isActive: true,
      isPhoneVerified: true,
      isEmailVerified: true
    });

    console.log('✅ Test user created successfully:');
    console.log('ID:', testUser.id);
    console.log('Email:', testUser.email);
    console.log('Role:', testUser.role);

    return testUser;
  } catch (error) {
    console.error('❌ Error creating test user:', error.message);
    throw error;
  } finally {
    await sequelize.close();
  }
}

// Run the script
createTestUser()
  .then(() => {
    console.log('\n🎉 Test user ready for Socket.IO testing!');
    process.exit(0);
  })
  .catch((error) => {
    console.error('❌ Failed to create test user:', error);
    process.exit(1);
  });
