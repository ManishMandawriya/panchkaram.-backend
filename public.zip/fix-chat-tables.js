const { Sequelize } = require('sequelize');

// Database connection
const sequelize = new Sequelize('panchakarma', 'root', '', {
  host: 'localhost',
  dialect: 'mysql',
  logging: false
});

async function fixChatTables() {
  try {
    await sequelize.authenticate();
    console.log('✅ Database connection established.');

    // Check if chat_sessions table exists
    const [tables] = await sequelize.query("SHOW TABLES LIKE 'chat_sessions'");
    
    if (tables.length === 0) {
      console.log('❌ chat_sessions table does not exist. Creating it...');
      
      // Create chat_sessions table
      await sequelize.query(`
        CREATE TABLE chat_sessions (
          id INT AUTO_INCREMENT PRIMARY KEY,
          chat_id INT NOT NULL,
          session_id VARCHAR(255) NOT NULL UNIQUE,
          doctor_id INT NOT NULL,
          patient_id INT NOT NULL,
          session_type ENUM('chat', 'audioCall', 'videoCall') NOT NULL DEFAULT 'chat',
          session_token VARCHAR(500),
          status ENUM('scheduled', 'ongoing', 'ended', 'canceled') NOT NULL DEFAULT 'scheduled',
          start_time DATETIME,
          end_time DATETIME,
          patient_joined_at DATETIME,
          doctor_joined_at DATETIME,
          duration INT,
          is_active BOOLEAN DEFAULT TRUE,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          FOREIGN KEY (chat_id) REFERENCES chats(id) ON DELETE CASCADE,
          FOREIGN KEY (doctor_id) REFERENCES users(id) ON DELETE CASCADE,
          FOREIGN KEY (patient_id) REFERENCES users(id) ON DELETE CASCADE,
          INDEX idx_session_id (session_id),
          INDEX idx_chat_id (chat_id),
          INDEX idx_doctor_id (doctor_id),
          INDEX idx_patient_id (patient_id),
          INDEX idx_status (status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
      `);
      
      console.log('✅ chat_sessions table created successfully!');
    } else {
      console.log('✅ chat_sessions table exists. Checking structure...');
      
      // Check current structure
      const [columns] = await sequelize.query('DESCRIBE chat_sessions');
      console.log('\n📋 Current chat_sessions table structure:');
      columns.forEach(row => {
        console.log(`${row.Field} - ${row.Type}`);
      });
      
      // Check if chat_id column exists
      const hasChatId = columns.some(col => col.Field === 'chat_id');
      
      if (!hasChatId) {
        console.log('\n🔧 Adding missing chat_id column...');
        await sequelize.query('ALTER TABLE chat_sessions ADD COLUMN chat_id INT NOT NULL AFTER id');
        await sequelize.query('ALTER TABLE chat_sessions ADD FOREIGN KEY (chat_id) REFERENCES chats(id) ON DELETE CASCADE');
        await sequelize.query('ALTER TABLE chat_sessions ADD INDEX idx_chat_id (chat_id)');
        console.log('✅ chat_id column added successfully!');
      } else {
        console.log('✅ chat_id column already exists');
      }
    }

    // Check if chats table exists
    const [chatTables] = await sequelize.query("SHOW TABLES LIKE 'chats'");
    
    if (chatTables.length === 0) {
      console.log('\n❌ chats table does not exist. Creating it...');
      
      // Create chats table
      await sequelize.query(`
        CREATE TABLE chats (
          id INT AUTO_INCREMENT PRIMARY KEY,
          doctor_id INT NOT NULL,
          patient_id INT NOT NULL,
          is_active BOOLEAN DEFAULT TRUE,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          UNIQUE KEY unique_doctor_patient (doctor_id, patient_id),
          FOREIGN KEY (doctor_id) REFERENCES users(id) ON DELETE CASCADE,
          FOREIGN KEY (patient_id) REFERENCES users(id) ON DELETE CASCADE,
          INDEX idx_doctor_id (doctor_id),
          INDEX idx_patient_id (patient_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
      `);
      
      console.log('✅ chats table created successfully!');
    } else {
      console.log('\n✅ chats table exists');
    }

    // Check if chat_messages table exists
    const [messageTables] = await sequelize.query("SHOW TABLES LIKE 'chat_messages'");
    
    if (messageTables.length === 0) {
      console.log('\n❌ chat_messages table does not exist. Creating it...');
      
      // Create chat_messages table
      await sequelize.query(`
        CREATE TABLE chat_messages (
          id INT AUTO_INCREMENT PRIMARY KEY,
          chat_id INT NOT NULL,
          session_id INT NOT NULL,
          sender_id INT NOT NULL,
          message_id VARCHAR(255) UNIQUE,
          message_type ENUM('text', 'image', 'file', 'audio', 'video', 'system') NOT NULL DEFAULT 'text',
          direction ENUM('inbound', 'outbound', 'system') NOT NULL DEFAULT 'inbound',
          content TEXT,
          file_url VARCHAR(500),
          file_name VARCHAR(255),
          file_type VARCHAR(100),
          file_size INT,
          reply_to_message_id VARCHAR(255),
          status ENUM('sent', 'delivered', 'read', 'failed') NOT NULL DEFAULT 'sent',
          sent_at DATETIME,
          delivered_at DATETIME,
          read_at DATETIME,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          FOREIGN KEY (chat_id) REFERENCES chats(id) ON DELETE CASCADE,
          FOREIGN KEY (session_id) REFERENCES chat_sessions(id) ON DELETE CASCADE,
          FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
          INDEX idx_chat_id (chat_id),
          INDEX idx_session_id (session_id),
          INDEX idx_sender_id (sender_id),
          INDEX idx_message_id (message_id),
          INDEX idx_sent_at (sent_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
      `);
      
      console.log('✅ chat_messages table created successfully!');
    } else {
      console.log('\n✅ chat_messages table exists');
    }

    console.log('\n🎉 All chat tables are ready!');

  } catch (error) {
    console.error('❌ Error fixing chat tables:', error.message);
    throw error;
  } finally {
    await sequelize.close();
  }
}

// Run the script
fixChatTables()
  .then(() => {
    console.log('\n🎉 Chat tables fixed successfully!');
    process.exit(0);
  })
  .catch((error) => {
    console.error('❌ Failed to fix chat tables:', error);
    process.exit(1);
  });
