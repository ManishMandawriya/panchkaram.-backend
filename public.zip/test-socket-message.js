const { Sequelize } = require('sequelize');
const jwt = require('jsonwebtoken');
const { io } = require('socket.io-client');

// Database connection
const sequelize = new Sequelize('panchakarma', 'root', '', {
  host: 'localhost',
  dialect: 'mysql',
  logging: false
});

// Test user data
const testUser = {
  userId: 1,
  email: 'test@example.com',
  role: 'patient',
  fullName: 'Test User'
};

const JWT_SECRET = 'your-super-secret-jwt-key-change-this-in-production';

async function testSocketMessage() {
  try {
    await sequelize.authenticate();
    console.log('✅ Database connection established.');

    // Generate JWT token
    const token = jwt.sign(testUser, JWT_SECRET, { expiresIn: '7d' });
    console.log('🔑 Test JWT Token:', token);

    // Create a test chat and session
    console.log('\n🔧 Creating test chat and session...');
    
    // Create or get chat
    const [chats] = await sequelize.query(`
      SELECT * FROM chats WHERE doctor_id = 1 AND patient_id = 1
    `);
    
    let chatId;
    if (chats.length === 0) {
      // Create new chat
      const [newChat] = await sequelize.query(`
        INSERT INTO chats (doctor_id, patient_id, is_active, created_at, updated_at) 
        VALUES (1, 1, 1, NOW(), NOW())
      `);
      chatId = newChat.insertId;
      console.log('✅ Created new chat with ID:', chatId);
    } else {
      chatId = chats[0].id;
      console.log('✅ Using existing chat with ID:', chatId);
    }

    // Create a test session
    const sessionId = `1-1-${Date.now()}`;
    await sequelize.query(`
      INSERT INTO chat_sessions (
        chat_id, session_id, doctor_id, patient_id, 
        session_type, session_token, status, start_time, is_active, created_at, updated_at
      ) VALUES (
        ${chatId}, '${sessionId}', 1, 1, 
        'chat', 'test-token-123', 'scheduled', NOW(), 1, NOW(), NOW()
      )
    `);
    console.log('✅ Created test session with ID:', sessionId);

    // Test Socket.IO connection and message sending
    console.log('\n🔌 Testing Socket.IO connection and message sending...');
    
    const socket = io('http://localhost:3000', {
      auth: {
        token: token
      },
      transports: ['websocket', 'polling']
    });

    socket.on('connect', () => {
      console.log('✅ Connected to Socket.IO!');
      console.log('Socket ID:', socket.id);
      
      // Join the session
      console.log('🔧 Joining session:', sessionId);
      socket.emit('join-session', sessionId);
    });

    socket.on('session-joined', (data) => {
      console.log('✅ Successfully joined session:', data);
      
      // Send a test message
      console.log('🔧 Sending test message...');
      socket.emit('send-message', {
        sessionId: sessionId,
        content: 'Hello from test! This is a test message.',
        messageType: 'text'
      });
    });

    socket.on('new-message', (data) => {
      console.log('✅ Received new message:', data);
    });

    socket.on('error', (data) => {
      console.log('❌ Socket error:', data);
    });

    socket.on('connect_error', (error) => {
      console.log('❌ Connection error:', error.message);
    });

    // Wait for 5 seconds to see the results
    setTimeout(() => {
      console.log('\n🔧 Disconnecting...');
      socket.disconnect();
      
      // Check if message was saved in database
      sequelize.query(`
        SELECT * FROM chat_messages WHERE chat_id = ${chatId} ORDER BY created_at DESC LIMIT 1
      `).then(([messages]) => {
        if (messages.length > 0) {
          console.log('✅ Message saved in database:', messages[0]);
        } else {
          console.log('❌ No message found in database');
        }
        process.exit(0);
      });
    }, 5000);

  } catch (error) {
    console.error('❌ Error testing socket message:', error.message);
    process.exit(1);
  }
}

// Run the test
testSocketMessage()
  .catch((error) => {
    console.error('❌ Test failed:', error);
    process.exit(1);
  });
