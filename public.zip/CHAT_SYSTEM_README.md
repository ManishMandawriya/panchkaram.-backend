# 🏥 Chat System - Panchakarma Healthcare

A robust, secure, and comprehensive chat system for patient-doctor communication with full message tracking, session management, and payment integration.

## 🚀 Features

### ✅ **Core Chat Functionality**
- **Real-time messaging** between patients and doctors
- **Multiple message types**: Text, Image, File, Audio, Video, System messages
- **Message status tracking**: Sent → Delivered → Read
- **Reply functionality** with message threading
- **File sharing** with size and type validation
- **System messages** for session events

### ✅ **Session Management**
- **Session lifecycle**: Pending → Active → Completed/Cancelled/Expired
- **Session types**: Chat, Audio Call, Video Call
- **Automatic expiry** (24 hours from creation)
- **Session validation** and authorization
- **Cost tracking** per session

### ✅ **Security & Data Integrity**
- **JWT authentication** for all endpoints
- **Role-based access control** (Patient/Doctor)
- **Message encryption** and secure storage
- **No message loss** - comprehensive tracking
- **Audit trail** for all actions
- **Input validation** and sanitization

### ✅ **Payment Integration Ready**
- **Cost per unit** tracking
- **Session duration** calculation
- **Total cost** computation
- **Payment status** tracking
- **Transaction ID** support

## 📊 Database Schema

### `chat_sessions` Table
```sql
- id (Primary Key)
- patient_id (Foreign Key → users)
- doctor_id (Foreign Key → users)
- session_type (ENUM: chat, audio_call, video_call)
- status (ENUM: pending, active, paused, completed, cancelled, expired)
- total_cost (DECIMAL)
- cost_per_unit (DECIMAL)
- total_duration (INT - minutes)
- total_messages (INT)
- started_at (DATETIME)
- ended_at (DATETIME)
- expires_at (DATETIME)
- notes (TEXT)
- is_paid (BOOLEAN)
- payment_transaction_id (VARCHAR)
- paid_at (DATETIME)
- is_rated (BOOLEAN)
- rating (INT 1-5)
- review (TEXT)
- is_active (BOOLEAN)
- created_at, updated_at (TIMESTAMPS)
```

### `chat_messages` Table
```sql
- id (Primary Key)
- session_id (Foreign Key → chat_sessions)
- sender_id (Foreign Key → users)
- message_type (ENUM: text, image, file, audio, video, system)
- direction (ENUM: inbound, outbound, system)
- content (TEXT)
- file_url (VARCHAR)
- file_name (VARCHAR)
- file_type (VARCHAR)
- file_size (INT)
- status (ENUM: sent, delivered, read, failed, pending)
- sent_at, delivered_at, read_at (DATETIME)
- message_id (UUID)
- reply_to_message_id (UUID)
- is_edited, edited_at (BOOLEAN, DATETIME)
- is_deleted, deleted_at (BOOLEAN, DATETIME)
- metadata (JSON)
- is_active (BOOLEAN)
- created_at, updated_at (TIMESTAMPS)
```

## 🔌 API Endpoints

### Session Management
```
POST   /api/chat/sessions              - Create new session (Patient only)
GET    /api/chat/sessions              - Get user sessions
GET    /api/chat/sessions/:id          - Get session details
GET    /api/chat/sessions/:id/status   - Get session status
PUT    /api/chat/sessions/:id/start    - Start session (Doctor only)
PUT    /api/chat/sessions/:id/end      - End session
```

### Message Management
```
POST   /api/chat/sessions/:id/messages     - Send message
GET    /api/chat/sessions/:id/messages     - Get messages
PUT    /api/chat/sessions/:id/messages/read - Mark as read
```

## 🛡️ Security Features

### Authentication & Authorization
- **JWT Bearer tokens** for all requests
- **Role validation** (Patient can only create sessions, Doctor can only start sessions)
- **Session ownership** validation
- **Message sender** verification

### Data Protection
- **Input validation** with Joi schemas
- **SQL injection** prevention with Sequelize ORM
- **XSS protection** with content sanitization
- **File upload** validation and size limits
- **Rate limiting** support

### Message Integrity
- **Unique message IDs** (UUID)
- **Message status tracking** (Sent → Delivered → Read)
- **Delivery confirmation** for all messages
- **Message history** preservation
- **Soft delete** for messages

## 💰 Payment Integration

### Cost Tracking
- **Per-session pricing** based on doctor's rates
- **Duration-based billing** (minutes)
- **Message-based billing** (optional)
- **Real-time cost calculation**

### Payment Status
- **Payment pending** until session completion
- **Transaction tracking** with external payment IDs
- **Payment verification** and confirmation
- **Refund support** for cancelled sessions

## 🔄 Message Flow

### 1. Session Creation
```
Patient → POST /chat/sessions
↓
System creates session (PENDING)
↓
System sends initial message (if provided)
↓
System sends "Session created" message
```

### 2. Session Activation
```
Doctor → PUT /chat/sessions/:id/start
↓
System updates session (ACTIVE)
↓
System sends "Doctor joined" message
↓
Messages can now be exchanged
```

### 3. Message Exchange
```
User → POST /chat/sessions/:id/messages
↓
System validates session and sender
↓
System creates message (SENT)
↓
System marks message (DELIVERED)
↓
Recipient can mark as (READ)
```

### 4. Session Completion
```
User → PUT /chat/sessions/:id/end
↓
System calculates duration and cost
↓
System updates session (COMPLETED)
↓
System sends "Session ended" message
↓
Payment processing can begin
```

## 🧪 Testing

### Test Scripts
- `scripts/test-chat-system.js` - Comprehensive API testing
- `scripts/create-chat-tables.js` - Database migration

### Test Coverage
- ✅ Session creation and management
- ✅ Message sending and retrieval
- ✅ Message status tracking
- ✅ Session status management
- ✅ User session listing
- ✅ Session completion and cost calculation
- ✅ Authentication and authorization
- ✅ Error handling and validation

## 📱 Postman Collection

Import `Chat_APIs_Postman_Collection.json` for:
- **Pre-configured requests** for all endpoints
- **Authentication flow** with token management
- **Example payloads** for all message types
- **Environment variables** for easy testing

## 🚀 Setup Instructions

### 1. Database Setup
```bash
# Run the migration script
node scripts/create-chat-tables.js
```

### 2. Dependencies
```bash
# Install required packages
npm install uuid @types/uuid
```

### 3. Environment Variables
```env
# Add to your .env file
CHAT_SESSION_EXPIRY_HOURS=24
CHAT_MAX_FILE_SIZE=52428800  # 50MB
CHAT_MAX_MESSAGE_LENGTH=2000
```

### 4. Testing
```bash
# Run the test script
node scripts/test-chat-system.js
```

## 🔧 Configuration

### Session Settings
- **Default expiry**: 24 hours
- **Max file size**: 50MB
- **Max message length**: 2000 characters
- **Message types**: text, image, file, audio, video, system

### Security Settings
- **JWT token expiry**: 24 hours
- **Rate limiting**: 100 requests/minute
- **File validation**: MIME type and size checks
- **Input sanitization**: XSS protection

## 📈 Monitoring & Analytics

### Session Metrics
- Total sessions created
- Active sessions count
- Session completion rate
- Average session duration
- Revenue per session

### Message Metrics
- Messages sent per session
- Message delivery rate
- Average response time
- File sharing statistics

### User Engagement
- Patient activity patterns
- Doctor response times
- Session frequency
- User satisfaction ratings

## 🔮 Future Enhancements

### Planned Features
- **Real-time notifications** (WebSocket/Socket.io)
- **Message encryption** (end-to-end)
- **Voice messages** support
- **Video call integration**
- **AI-powered responses**
- **Message translation**
- **Advanced analytics dashboard**

### Integration Points
- **Payment gateways** (Stripe, PayPal)
- **Push notifications** (Firebase, OneSignal)
- **File storage** (AWS S3, Google Cloud)
- **Analytics** (Google Analytics, Mixpanel)

## 🆘 Support

### Common Issues
1. **Session not found**: Check session ID and user authorization
2. **Message not sent**: Verify session is active and not expired
3. **File upload failed**: Check file size and type restrictions
4. **Authentication error**: Verify JWT token and user role

### Debug Mode
Enable debug logging in `src/config/env.ts`:
```typescript
LOG_LEVEL: 'debug'
```

## 📄 License

This chat system is part of the Panchakarma Healthcare platform and follows the same licensing terms.

---

**Built with ❤️ for secure healthcare communication**
