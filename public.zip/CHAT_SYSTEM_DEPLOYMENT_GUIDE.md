# Chat System Deployment Guide

## 🚀 Quick Setup for Production Server

### 1. Database Setup
Run the complete setup script on your server:

```bash
# Navigate to your backend directory
cd /path/to/your/backend

# Run the complete chat system setup
node setup-chat-system-complete.js
```

This script will:
- ✅ Fix users table (add all missing columns)
- ✅ Create chats table with proper structure
- ✅ Create chat_sessions table with proper structure  
- ✅ Create chat_messages table with proper structure
- ✅ Add all missing columns to existing tables
- ✅ Verify all tables have correct structure

### 2. Environment Configuration
Make sure your `.env` file has these settings:

```env
# Database
DB_HOST=localhost
DB_USER=your_db_user
DB_PASSWORD=your_db_password
DB_NAME=panchakarma

# JWT Secret (change this!)
JWT_SECRET=your-super-secret-jwt-key-change-this-in-production

# Server
PORT=3000
NODE_ENV=production

# Socket.IO (optional)
SOCKET_CORS_ORIGIN=*
```

### 3. Install Dependencies
```bash
npm install
```

### 4. Start the Server
```bash
# Development
npm run dev

# Production
npm start
```

## 🔧 What This Fixes

The setup script addresses all the database issues we encountered:

1. **Users Table Issues**
   - Missing columns like `about_yourself`, `degrees`, `specializations`, etc.
   - Foreign key constraint errors

2. **Chat Tables Issues**
   - Missing `chats` table
   - Missing `chat_sessions` table  
   - Missing `chat_messages` table
   - Missing columns like `is_edited`, `is_deleted`, `is_active`

3. **Foreign Key Issues**
   - Proper relationships between tables
   - Cascade delete rules

## 🧪 Testing the System

### 1. Test Socket.IO Connection
```bash
node test-socket-auth.js
```

### 2. Test Message Sending
```bash
node test-socket-message.js
```

### 3. Test Appointment Booking
Create an appointment via API - it should automatically create:
- A chat entry for the doctor-patient pair
- A chat session for the appointment

### 4. Test Chat Session Retrieval
```bash
# Get chat session for an appointment
GET /api/appointments/{appointmentId}/chat-session
```

## 📋 API Endpoints

### Chat Endpoints
- `GET /api/chat/verify-session` - Check for active sessions
- `POST /api/chat/sessions/:sessionId/join` - Join a session
- `GET /api/chat/history/:doctorId/:patientId` - Get chat history

### Appointment Endpoints  
- `POST /api/appointments` - Create appointment (auto-creates chat)
- `GET /api/appointments/:id/chat-session` - Get chat session for appointment

## 🔌 Socket.IO Events

### Client to Server
- `join-session` - Join a chat session
- `send-message` - Send a message
- `typing-start` - Start typing indicator
- `typing-stop` - Stop typing indicator
- `mark-read` - Mark message as read
- `end-session` - End the session

### Server to Client
- `session-joined` - Confirmation of joining session
- `new-message` - New message received
- `typing-indicator` - Someone is typing
- `message-read` - Message read confirmation
- `session-ended` - Session ended notification

## 🛠️ Troubleshooting

### Common Issues

1. **"Unknown column" errors**
   - Run the setup script again
   - Check if all tables were created properly

2. **Foreign key constraint errors**
   - Ensure users exist before creating chats
   - Check that all referenced tables exist

3. **Socket.IO connection issues**
   - Verify JWT token is valid
   - Check CORS settings
   - Ensure server is running on correct port

4. **Message not saving**
   - Check database connection
   - Verify chat and session exist
   - Check for missing columns in chat_messages table

### Debug Commands

```bash
# Check table structures
mysql -u root -p panchakarma -e "DESCRIBE users;"
mysql -u root -p panchakarma -e "DESCRIBE chats;"
mysql -u root -p panchakarma -e "DESCRIBE chat_sessions;"
mysql -u root -p panchakarma -e "DESCRIBE chat_messages;"

# Check for missing columns
mysql -u root -p panchakarma -e "SHOW COLUMNS FROM users LIKE 'about_yourself';"
```

## 📝 Production Checklist

- [ ] Run `setup-chat-system-complete.js`
- [ ] Update `.env` with production values
- [ ] Change JWT_SECRET to a secure value
- [ ] Test Socket.IO connection
- [ ] Test appointment booking
- [ ] Test real-time messaging
- [ ] Verify all API endpoints work
- [ ] Check database performance
- [ ] Set up proper logging
- [ ] Configure CORS for production domains

## 🎉 Success Indicators

When everything is working correctly, you should see:
- ✅ Socket.IO connections established
- ✅ Messages saved to database
- ✅ Real-time message delivery
- ✅ Appointment booking creates chat sessions
- ✅ Chat history retrieval works
- ✅ No database errors in logs

---

**Need help?** Check the logs for specific error messages and refer to the troubleshooting section above.
