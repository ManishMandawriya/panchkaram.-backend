# WebSocket Chat Client Integration Guide

## Overview

This guide shows how to integrate the frontend with the WebSocket-based real-time chat system. The WebSocket approach provides instant messaging, typing indicators, read receipts, and real-time session management.

## Frontend Integration

### 1. Socket Connection Setup

```javascript
import io from 'socket.io-client';

class ChatSocketService {
  constructor() {
    this.socket = null;
    this.isConnected = false;
    this.sessionId = null;
    this.messageHandlers = new Map();
    this.typingTimeout = null;
  }

  // Connect to WebSocket server
  connect(token) {
    this.socket = io('http://localhost:3000', {
      auth: { token },
      transports: ['websocket', 'polling']
    });

    this.setupEventListeners();
  }

  // Setup all event listeners
  setupEventListeners() {
    this.socket.on('connect', () => {
      console.log('Connected to chat server');
      this.isConnected = true;
    });

    this.socket.on('disconnect', () => {
      console.log('Disconnected from chat server');
      this.isConnected = false;
    });

    this.socket.on('error', (error) => {
      console.error('Socket error:', error);
    });

    // Session events
    this.socket.on('session-joined', this.handleSessionJoined.bind(this));
    this.socket.on('user-joined', this.handleUserJoined.bind(this));
    this.socket.on('user-left', this.handleUserLeft.bind(this));
    this.socket.on('session-ended', this.handleSessionEnded.bind(this));

    // Message events
    this.socket.on('new-message', this.handleNewMessage.bind(this));
    this.socket.on('messages-read', this.handleMessagesRead.bind(this));

    // Typing events
    this.socket.on('user-typing', this.handleUserTyping.bind(this));
  }

  // Join a chat session
  joinSession(sessionId) {
    if (!this.isConnected) {
      throw new Error('Socket not connected');
    }

    this.sessionId = sessionId;
    this.socket.emit('join-session', sessionId);
  }

  // Send a message
  sendMessage(content, messageType = 'text', replyToMessageId = null, fileData = null) {
    if (!this.sessionId) {
      throw new Error('Not in a session');
    }

    const messageData = {
      sessionId: this.sessionId,
      content,
      messageType,
      replyToMessageId
    };

    if (fileData) {
      Object.assign(messageData, {
        fileUrl: fileData.url,
        fileName: fileData.name,
        fileType: fileData.type,
        fileSize: fileData.size
      });
    }

    this.socket.emit('send-message', messageData);
  }

  // Start typing indicator
  startTyping() {
    if (!this.sessionId) return;

    this.socket.emit('typing-start', this.sessionId);
  }

  // Stop typing indicator
  stopTyping() {
    if (!this.sessionId) return;

    this.socket.emit('typing-stop', this.sessionId);
  }

  // Mark messages as read
  markMessagesAsRead(messageIds) {
    if (!this.sessionId) return;

    this.socket.emit('mark-read', messageIds);
  }

  // End session
  endSession() {
    if (!this.sessionId) return;

    this.socket.emit('end-session');
  }

  // Event handlers
  handleSessionJoined(data) {
    console.log('Joined session:', data);
    this.triggerEvent('session-joined', data);
  }

  handleUserJoined(data) {
    console.log('User joined:', data);
    this.triggerEvent('user-joined', data);
  }

  handleUserLeft(data) {
    console.log('User left:', data);
    this.triggerEvent('user-left', data);
  }

  handleSessionEnded(data) {
    console.log('Session ended:', data);
    this.triggerEvent('session-ended', data);
  }

  handleNewMessage(data) {
    console.log('New message:', data);
    this.triggerEvent('new-message', data);
  }

  handleMessagesRead(data) {
    console.log('Messages read:', data);
    this.triggerEvent('messages-read', data);
  }

  handleUserTyping(data) {
    console.log('User typing:', data);
    this.triggerEvent('user-typing', data);
  }

  // Event system
  on(event, handler) {
    if (!this.messageHandlers.has(event)) {
      this.messageHandlers.set(event, []);
    }
    this.messageHandlers.get(event).push(handler);
  }

  off(event, handler) {
    if (this.messageHandlers.has(event)) {
      const handlers = this.messageHandlers.get(event);
      const index = handlers.indexOf(handler);
      if (index > -1) {
        handlers.splice(index, 1);
      }
    }
  }

  triggerEvent(event, data) {
    if (this.messageHandlers.has(event)) {
      this.messageHandlers.get(event).forEach(handler => {
        handler(data);
      });
    }
  }

  disconnect() {
    if (this.socket) {
      this.socket.disconnect();
      this.socket = null;
      this.isConnected = false;
      this.sessionId = null;
    }
  }
}

export default ChatSocketService;
```

### 2. React Component Example

```jsx
import React, { useState, useEffect, useRef } from 'react';
import ChatSocketService from './ChatSocketService';

const ChatComponent = ({ sessionId, userToken }) => {
  const [messages, setMessages] = useState([]);
  const [typingUsers, setTypingUsers] = useState(new Set());
  const [sessionInfo, setSessionInfo] = useState(null);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  
  const socketService = useRef(new ChatSocketService());
  const typingTimeoutRef = useRef(null);

  useEffect(() => {
    // Connect to WebSocket
    socketService.current.connect(userToken);

    // Join session
    socketService.current.joinSession(sessionId);

    // Setup event listeners
    socketService.current.on('session-joined', handleSessionJoined);
    socketService.current.on('new-message', handleNewMessage);
    socketService.current.on('user-typing', handleUserTyping);
    socketService.current.on('user-joined', handleUserJoined);
    socketService.current.on('user-left', handleUserLeft);
    socketService.current.on('session-ended', handleSessionEnded);
    socketService.current.on('messages-read', handleMessagesRead);

    return () => {
      socketService.current.disconnect();
    };
  }, [sessionId, userToken]);

  const handleSessionJoined = (data) => {
    setSessionInfo(data);
    console.log('Session joined:', data);
  };

  const handleNewMessage = (message) => {
    setMessages(prev => [...prev, message]);
    
    // Mark message as read if it's from another user
    if (message.senderId !== currentUserId) {
      socketService.current.markMessagesAsRead([message.id]);
    }
  };

  const handleUserTyping = (data) => {
    if (data.isTyping) {
      setTypingUsers(prev => new Set(prev).add(data.userName));
    } else {
      setTypingUsers(prev => {
        const newSet = new Set(prev);
        newSet.delete(data.userName);
        return newSet;
      });
    }
  };

  const handleUserJoined = (data) => {
    console.log(`${data.userName} joined the session`);
  };

  const handleUserLeft = (data) => {
    console.log(`${data.userName} left the session`);
  };

  const handleSessionEnded = (data) => {
    console.log('Session ended by:', data.endedByRole);
    // Handle session end (show summary, redirect, etc.)
  };

  const handleMessagesRead = (data) => {
    // Update message read status in UI
    setMessages(prev => prev.map(msg => 
      data.messageIds.includes(msg.id) 
        ? { ...msg, status: 'read' }
        : msg
    ));
  };

  const handleInputChange = (e) => {
    const value = e.target.value;
    setInputValue(value);

    // Handle typing indicators
    if (!isTyping) {
      setIsTyping(true);
      socketService.current.startTyping();
    }

    // Clear existing timeout
    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
    }

    // Set new timeout to stop typing indicator
    typingTimeoutRef.current = setTimeout(() => {
      setIsTyping(false);
      socketService.current.stopTyping();
    }, 1000);
  };

  const handleSendMessage = () => {
    if (!inputValue.trim()) return;

    socketService.current.sendMessage(inputValue.trim());
    setInputValue('');
    
    // Stop typing indicator
    setIsTyping(false);
    socketService.current.stopTyping();
  };

  const handleEndSession = () => {
    if (confirm('Are you sure you want to end this session?')) {
      socketService.current.endSession();
    }
  };

  return (
    <div className="chat-container">
      {/* Session Header */}
      {sessionInfo && (
        <div className="chat-header">
          <h3>Chat Session</h3>
          <div className="session-info">
            <span>Status: {sessionInfo.status}</span>
            <span>Type: {sessionInfo.sessionType}</span>
          </div>
          <button onClick={handleEndSession}>End Session</button>
        </div>
      )}

      {/* Messages Area */}
      <div className="messages-container">
        {messages.map((message) => (
          <div 
            key={message.id} 
            className={`message ${message.senderId === currentUserId ? 'own' : 'other'}`}
          >
            <div className="message-header">
              <span className="sender">{message.senderName}</span>
              <span className="time">{new Date(message.sentAt).toLocaleTimeString()}</span>
            </div>
            <div className="message-content">
              {message.content}
            </div>
            {message.fileUrl && (
              <div className="message-attachment">
                <a href={message.fileUrl} target="_blank" rel="noopener noreferrer">
                  {message.fileName}
                </a>
              </div>
            )}
            <div className="message-status">
              {message.status === 'read' && '✓✓'}
              {message.status === 'delivered' && '✓'}
            </div>
          </div>
        ))}
        
        {/* Typing Indicators */}
        {typingUsers.size > 0 && (
          <div className="typing-indicator">
            {Array.from(typingUsers).join(', ')} {typingUsers.size === 1 ? 'is' : 'are'} typing...
          </div>
        )}
      </div>

      {/* Input Area */}
      <div className="input-container">
        <input
          type="text"
          value={inputValue}
          onChange={handleInputChange}
          onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
          placeholder="Type your message..."
        />
        <button onClick={handleSendMessage}>Send</button>
      </div>
    </div>
  );
};

export default ChatComponent;
```

### 3. Complete Chat Flow

```javascript
// 1. User accesses chat page
const ChatPage = () => {
  const [activeSession, setActiveSession] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    checkForActiveSession();
  }, []);

  const checkForActiveSession = async () => {
    try {
      // First, check if user has an active session
      const response = await fetch('/api/chat/verify-session?userRole=patient', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      if (response.ok) {
        const data = await response.json();
        if (data.success) {
          setActiveSession(data.data.session);
        }
      }
    } catch (error) {
      console.error('Error checking session:', error);
    } finally {
      setLoading(false);
    }
  };

  const createNewSession = async (doctorId) => {
    try {
      const response = await fetch('/api/chat/sessions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          doctorId,
          sessionType: 'chat'
        })
      });

      const data = await response.json();
      if (data.success) {
        setActiveSession(data.data.session);
      }
    } catch (error) {
      console.error('Error creating session:', error);
    }
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  if (activeSession) {
    return (
      <ChatComponent 
        sessionId={activeSession.sessionId}
        userToken={token}
      />
    );
  }

  return (
    <div>
      <h2>No Active Session</h2>
      <button onClick={() => createNewSession(doctorId)}>
        Start New Chat
      </button>
    </div>
  );
};
```

## Key WebSocket Events

### Client to Server Events:
- `join-session`: Join a specific chat session
- `send-message`: Send a new message
- `typing-start`: Start typing indicator
- `typing-stop`: Stop typing indicator
- `mark-read`: Mark messages as read
- `end-session`: End the current session

### Server to Client Events:
- `session-joined`: Confirmation of joining session
- `user-joined`: Another user joined the session
- `user-left`: Another user left the session
- `new-message`: New message received
- `user-typing`: User typing indicator
- `messages-read`: Messages marked as read
- `session-ended`: Session ended
- `error`: Error occurred

## Benefits of WebSocket Approach:

1. **Real-time Communication**: Instant message delivery
2. **Typing Indicators**: Show when someone is typing
3. **Read Receipts**: Know when messages are read
4. **Session Management**: Real-time session status updates
5. **Better UX**: No polling, no delays
6. **Efficient**: Lower server load compared to polling
7. **Scalable**: Handles multiple concurrent sessions

## Security Considerations:

1. **JWT Authentication**: All socket connections require valid JWT
2. **Session Validation**: Users can only access their own sessions
3. **Input Validation**: All messages validated before processing
4. **Rate Limiting**: Implement rate limiting for message sending
5. **Error Handling**: Proper error handling and logging

This WebSocket-based approach provides a much better user experience compared to API-only chat systems, with real-time features that users expect from modern chat applications.
