# ⚡ WebSocket Chat System - Fast & Furious

A blazing-fast real-time chat system for patient-doctor communication with WebSocket support, built for your Panchakarma application.

## 🚀 Features

### Real-Time Communication
- **Instant Messaging**: Messages delivered in milliseconds
- **Typing Indicators**: See when someone is typing
- **Read Receipts**: Know when messages are read
- **Online Status**: Real-time user presence
- **Session Management**: Join/leave chat sessions seamlessly

### Robust Data Tracking
- **Message Persistence**: All messages stored in database
- **Session History**: Complete conversation logs
- **Payment Ready**: Track message counts and session duration
- **Audit Trail**: Full compliance and tracking

### Advanced Features
- **File Sharing**: Send images, documents, and media
- **Message Types**: Text, image, file, audio, video support
- **Session Types**: Chat, audio call, video call
- **Role-Based Access**: Patient and doctor permissions
- **Auto-Reconnection**: Handles network interruptions

## 🏗️ Architecture

### Hybrid Approach
- **REST APIs**: Session management, history, authentication
- **WebSocket**: Real-time messaging and events
- **Database**: Persistent storage with Sequelize ORM
- **JWT Authentication**: Secure token-based auth

### Performance Optimizations
- **WebSocket Transport**: Low-latency bidirectional communication
- **Connection Pooling**: Efficient resource management
- **Message Batching**: Optimized for high throughput
- **Memory Management**: Automatic cleanup and garbage collection

## 📁 File Structure

```
backend/
├── src/
│   ├── services/
│   │   ├── socketService.ts          # WebSocket server logic
│   │   └── chatService.ts            # REST API chat logic
│   ├── models/
│   │   ├── ChatSession.ts            # Chat session model
│   │   └── ChatMessage.ts            # Message model
│   ├── types/
│   │   └── chat.ts                   # TypeScript interfaces
│   └── routes/api/
│       └── chat.ts                   # REST API routes
├── public/
│   └── chat-test.html                # WebSocket test client
├── scripts/
│   ├── test-websocket-chat.js        # Full test script
│   └── test-websocket-quick.js       # Quick connectivity test
└── WebSocket_Chat_Postman_Collection.json
```

## 🚀 Quick Start

### 1. Install Dependencies
```bash
npm install socket.io socket.io-client @types/socket.io
```

### 2. Start the Server
```bash
npm run dev
```

### 3. Test the System
```bash
# Quick connectivity test
node scripts/test-websocket-quick.js

# Full functionality test
node scripts/test-websocket-chat.js
```

### 4. Web Interface
Visit: `http://localhost:3000/chat-test.html`

## 📡 WebSocket Events

### Client to Server Events

#### `join-session`
Join a specific chat session
```javascript
socket.emit('join-session', sessionId);
```

#### `send-message`
Send a real-time message
```javascript
socket.emit('send-message', {
  sessionId: 'session-id',
  content: 'Hello Doctor!',
  messageType: 'text'
});
```

#### `typing-start` / `typing-stop`
Show typing indicators
```javascript
socket.emit('typing-start', sessionId);
socket.emit('typing-stop', sessionId);
```

#### `mark-read`
Mark messages as read
```javascript
socket.emit('mark-read', ['message-id-1', 'message-id-2']);
```

#### `update-session-status`
Update session status (doctor only)
```javascript
socket.emit('update-session-status', {
  sessionId: 'session-id',
  status: 'completed'
});
```

### Server to Client Events

#### `session-joined`
Confirmation of joining a session
```javascript
socket.on('session-joined', (data) => {
  console.log('Joined session:', data.sessionId);
  console.log('Participants:', data.participants);
});
```

#### `new-message`
Real-time message received
```javascript
socket.on('new-message', (data) => {
  console.log(`${data.senderName}: ${data.content}`);
});
```

#### `user-typing`
Typing indicator
```javascript
socket.on('user-typing', (data) => {
  if (data.isTyping) {
    console.log(`${data.userName} is typing...`);
  }
});
```

#### `user-joined` / `user-left`
User presence updates
```javascript
socket.on('user-joined', (data) => {
  console.log(`${data.userName} joined the session`);
});
```

## 🔌 REST API Endpoints

### Chat Sessions
- `POST /api/chat/sessions` - Create new session
- `GET /api/chat/sessions` - Get user sessions
- `GET /api/chat/sessions/:id` - Get session details
- `PUT /api/chat/sessions/:id/start` - Start session (doctor)
- `PUT /api/chat/sessions/:id/end` - End session

### Messages
- `POST /api/chat/sessions/:id/messages` - Send message
- `GET /api/chat/sessions/:id/messages` - Get messages
- `PUT /api/chat/sessions/:id/messages/read` - Mark as read

## 🧪 Testing

### 1. Postman Collection
Import `WebSocket_Chat_Postman_Collection.json` for comprehensive API testing.

### 2. WebSocket Test Client
Open `http://localhost:3000/chat-test.html` for real-time testing.

### 3. Node.js Test Scripts
```bash
# Test basic connectivity
node scripts/test-websocket-quick.js

# Test full functionality
node scripts/test-websocket-chat.js
```

## 🔐 Authentication

### JWT Token Required
All WebSocket connections require a valid JWT token:

```javascript
const socket = io('http://localhost:3000', {
  auth: { token: 'your-jwt-token' },
  transports: ['websocket']
});
```

### Role-Based Access
- **Patients**: Can create sessions, send messages, view their sessions
- **Doctors**: Can start sessions, update status, view their sessions

## 💾 Database Schema

### ChatSession Table
```sql
CREATE TABLE chat_sessions (
  id VARCHAR(36) PRIMARY KEY,
  patient_id INT NOT NULL,
  doctor_id INT NOT NULL,
  session_type ENUM('chat', 'audio_call', 'video_call'),
  status ENUM('pending', 'active', 'completed', 'cancelled', 'expired'),
  total_cost DECIMAL(10,2) DEFAULT 0,
  cost_per_unit DECIMAL(10,2) DEFAULT 0,
  total_duration INT DEFAULT 0,
  total_messages INT DEFAULT 0,
  started_at TIMESTAMP NULL,
  ended_at TIMESTAMP NULL,
  expires_at TIMESTAMP NULL,
  notes TEXT,
  is_paid BOOLEAN DEFAULT FALSE,
  payment_transaction_id VARCHAR(255),
  paid_at TIMESTAMP NULL,
  is_rated BOOLEAN DEFAULT FALSE,
  rating INT NULL,
  review TEXT,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

### ChatMessage Table
```sql
CREATE TABLE chat_messages (
  id VARCHAR(36) PRIMARY KEY,
  session_id VARCHAR(36) NOT NULL,
  sender_id INT NOT NULL,
  message_type ENUM('text', 'image', 'file', 'audio', 'video', 'system'),
  direction ENUM('inbound', 'outbound', 'system'),
  content TEXT NOT NULL,
  file_url VARCHAR(500),
  file_name VARCHAR(255),
  file_type VARCHAR(100),
  file_size INT,
  status ENUM('pending', 'sent', 'delivered', 'read', 'failed'),
  sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  delivered_at TIMESTAMP NULL,
  read_at TIMESTAMP NULL,
  message_id VARCHAR(36) UNIQUE NOT NULL,
  reply_to_message_id VARCHAR(36),
  is_edited BOOLEAN DEFAULT FALSE,
  edited_at TIMESTAMP NULL,
  is_deleted BOOLEAN DEFAULT FALSE,
  deleted_at TIMESTAMP NULL,
  metadata JSON,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

## 🚀 Performance Features

### Optimizations
- **WebSocket Transport**: Minimal latency
- **Connection Pooling**: Efficient resource usage
- **Message Batching**: High throughput support
- **Memory Management**: Automatic cleanup
- **Error Handling**: Graceful degradation

### Scalability
- **Horizontal Scaling**: Multiple server instances
- **Load Balancing**: Distribute connections
- **Database Indexing**: Fast queries
- **Caching**: Redis integration ready

## 🔧 Configuration

### Environment Variables
```env
# WebSocket Configuration
SOCKET_PING_TIMEOUT=60000
SOCKET_PING_INTERVAL=25000
SOCKET_MAX_BUFFER_SIZE=100000000

# Chat Configuration
CHAT_SESSION_EXPIRY_HOURS=24
CHAT_MAX_MESSAGE_LENGTH=1000
CHAT_MAX_FILE_SIZE=10485760
```

### Server Configuration
```javascript
const io = new SocketIOServer(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  },
  transports: ['websocket', 'polling'],
  pingTimeout: 60000,
  pingInterval: 25000,
  maxHttpBufferSize: 1e8, // 100MB for file uploads
  allowEIO3: true
});
```

## 🛠️ Development

### Adding New Message Types
1. Update `MessageType` enum in `types/chat.ts`
2. Add validation in `validations/chatValidation.ts`
3. Update message handling in `socketService.ts`

### Adding New Events
1. Define event in `socketService.ts`
2. Add TypeScript interface in `types/chat.ts`
3. Update client-side handlers

### Database Migrations
```bash
# Create new migration
node scripts/create-chat-tables.js

# Run migrations
npm run migrate
```

## 🐛 Troubleshooting

### Common Issues

#### WebSocket Connection Failed
- Check if server is running
- Verify JWT token is valid
- Check CORS configuration

#### Messages Not Delivered
- Verify session is active
- Check user permissions
- Review database connection

#### Performance Issues
- Monitor memory usage
- Check database indexes
- Review connection pooling

### Debug Mode
```javascript
// Enable debug logging
const socket = io('http://localhost:3000', {
  debug: true,
  auth: { token: 'your-token' }
});
```

## 📈 Monitoring

### Key Metrics
- **Connection Count**: Active WebSocket connections
- **Message Throughput**: Messages per second
- **Response Time**: Message delivery latency
- **Error Rate**: Failed connections/messages

### Logging
```javascript
// Server logs
logger.info('User connected:', userId);
logger.error('WebSocket error:', error);

// Client logs
socket.on('connect_error', (error) => {
  console.error('Connection failed:', error);
});
```

## 🔮 Future Enhancements

### Planned Features
- **Voice/Video Calls**: WebRTC integration
- **Message Encryption**: End-to-end encryption
- **Push Notifications**: Mobile app support
- **Analytics Dashboard**: Usage insights
- **AI Chatbot**: Automated responses

### Scalability Improvements
- **Redis Adapter**: Multi-server support
- **Message Queues**: High-volume handling
- **CDN Integration**: File delivery optimization
- **Microservices**: Service decomposition

## 📞 Support

For questions or issues:
1. Check the troubleshooting section
2. Review the test scripts
3. Examine the Postman collection
4. Check server logs for errors

---

**⚡ Built for speed, designed for reliability, ready for production!**
