# Mock API Documentation

This document describes all the mock APIs for the Panchakarma mobile application, covering categories, doctors, appointments, services, and reviews.

## Table of Contents

1. [Categories API](#categories-api)
2. [Doctors API](#doctors-api)
3. [Appointments API](#appointments-api)
4. [Services API](#services-api)
5. [Reviews API](#reviews-api)
6. [Authentication](#authentication)
7. [Usage Examples](#usage-examples)

## Categories API

### Get All Categories
**GET** `/api/categories`

Returns all active categories for the mobile app.

**Response:**
```json
{
  "success": true,
  "message": "Categories retrieved successfully",
  "data": {
    "categories": [
      {
        "id": 1,
        "name": "Cardiology",
        "icon": "heart-icon.png",
        "isActive": true
      },
      {
        "id": 2,
        "name": "Psychology",
        "icon": "brain-icon.png",
        "isActive": true
      },
      {
        "id": 3,
        "name": "Dentist",
        "icon": "tooth-icon.png",
        "isActive": true
      },
      {
        "id": 4,
        "name": "Lungs",
        "icon": "lung-icon.png",
        "isActive": true
      },
      {
        "id": 5,
        "name": "Neurology",
        "icon": "nerve-icon.png",
        "isActive": true
      },
      {
        "id": 6,
        "name": "Blood Test",
        "icon": "blood-icon.png",
        "isActive": true
      }
    ]
  }
}
```

## Doctors API

### Get All Doctors
**GET** `/api/doctors`

Get all approved doctors with optional filtering.

**Query Parameters:**
- `categoryId` (optional): Filter by category ID
- `specialty` (optional): Filter by specialty
- `search` (optional): Search by name or specialty
- `rating` (optional): Filter by minimum rating
- `experience` (optional): Filter by experience
- `page` (optional): Page number (default: 1)
- `limit` (optional): Items per page (default: 10)
- `sortBy` (optional): Sort field ('rating', 'experience', 'reviewsCount', 'createdAt')
- `sortOrder` (optional): Sort order ('ASC', 'DESC')

**Response:**
```json
{
  "success": true,
  "message": "Doctors retrieved successfully",
  "data": {
    "doctors": [
      {
        "id": 1,
        "fullName": "Dr. Leslie R. Bean",
        "doctorId": "DOC001",
        "specialty": "Heart Surgeon",
        "department": "Cardiology",
        "experience": "7 Year Experience",
        "rating": 4.5,
        "reviewsCount": 348,
        "patientsCount": 2500,
        "profileImage": "doctor1.jpg"
      },
      {
        "id": 2,
        "fullName": "Dr. Shirley D. Howard",
        "doctorId": "DOC002",
        "specialty": "Cardiology",
        "department": "Cardiology",
        "experience": "5 Year Experience",
        "rating": 4.0,
        "reviewsCount": 178,
        "patientsCount": 1800,
        "profileImage": "doctor2.jpg"
      }
    ],
    "pagination": {
      "currentPage": 1,
      "totalPages": 5,
      "totalItems": 50,
      "itemsPerPage": 10
    }
  }
}
```

### Get Top Doctors
**GET** `/api/doctors/top`

Get top-rated doctors for the home screen.

**Query Parameters:**
- `limit` (optional): Number of doctors to return (default: 3)

**Response:**
```json
{
  "success": true,
  "message": "Top doctors retrieved successfully",
  "data": {
    "doctors": [
      {
        "id": 1,
        "fullName": "Dr. Leslie R. Bean",
        "doctorId": "DOC001",
        "specialty": "Heart Surgeon",
        "department": "Cardiology",
        "experience": "7 Year Experience",
        "rating": 4.5,
        "reviewsCount": 348,
        "profileImage": "doctor1.jpg"
      },
      {
        "id": 2,
        "fullName": "Dr. Shirley D. Howard",
        "doctorId": "DOC002",
        "specialty": "Cardiology",
        "department": "Cardiology",
        "experience": "5 Year Experience",
        "rating": 4.0,
        "reviewsCount": 178,
        "profileImage": "doctor2.jpg"
      },
      {
        "id": 3,
        "fullName": "Dr. John V. Robinson",
        "doctorId": "DOC003",
        "specialty": "Psychology",
        "department": "Psychology",
        "experience": "8 Year Experience",
        "rating": 3.5,
        "reviewsCount": 244,
        "profileImage": "doctor3.jpg"
      }
    ]
  }
}
```

### Search Doctors
**POST** `/api/doctors/search`

Search doctors by various criteria.

**Request Body:**
```json
{
  "search": "cardiology",
  "categoryIds": [1, 2],
  "specialty": "Cardiology",
  "page": 1,
  "limit": 10
}
```

### Get Doctor by ID
**GET** `/api/doctors/:id`

Get detailed information about a specific doctor.

**Response:**
```json
{
  "success": true,
  "message": "Doctor retrieved successfully",
  "data": {
    "doctor": {
      "id": 1,
      "fullName": "Dr. Jaime M. Mercado",
      "doctorId": "DOC001",
      "specialty": "Dermatologist",
      "department": "Dermatology",
      "experience": "5+ Year Experience",
      "rating": 4.2,
      "reviewsCount": 426,
      "patientsCount": 5000,
      "profileImage": "doctor1.jpg",
      "biography": "Experienced dermatologist with excellent patient care.",
      "workingHours": [
        {
          "id": 1,
          "day": "Mon - Sat",
          "startTime": "09:30AM",
          "endTime": "09:00PM",
          "isActive": true
        }
      ]
    }
  }
}
```

## Appointments API

### Create Appointment
**POST** `/api/appointments`

Create a new appointment with a doctor.

**Request Body:**
```json
{
  "doctorId": 1,
  "appointmentDate": "2024-01-24",
  "appointmentTime": "10:00AM",
  "serviceType": "Voice Call",
  "patientName": "John Doe",
  "patientAge": "25 - 30",
  "patientGender": "male",
  "problemDescription": "I have been experiencing chest pain for the past week."
}
```

**Response:**
```json
{
  "success": true,
  "message": "Appointment created successfully",
  "data": {
    "appointment": {
      "id": 1,
      "patientId": 123,
      "doctorId": 1,
      "appointmentDate": "2024-01-24T00:00:00.000Z",
      "appointmentTime": "10:00AM",
      "serviceType": "Voice Call",
      "patientName": "John Doe",
      "patientAge": "25 - 30",
      "patientGender": "male",
      "problemDescription": "I have been experiencing chest pain for the past week.",
      "status": "pending",
      "totalAmount": 10.00,
      "isActive": true,
      "createdAt": "2024-01-20T10:30:00.000Z",
      "updatedAt": "2024-01-20T10:30:00.000Z"
    }
  }
}
```

### Get Available Slots
**GET** `/api/doctors/:doctorId/available-slots`

Get available time slots for a doctor on a specific date.

**Query Parameters:**
- `date`: Date in YYYY-MM-DD format
- `timeOfDay`: 'morning' or 'evening'

**Response:**
```json
{
  "success": true,
  "message": "Available slots retrieved successfully",
  "data": {
    "slots": [
      {
        "time": "09:00AM",
        "isAvailable": true
      },
      {
        "time": "09:30AM",
        "isAvailable": false
      },
      {
        "time": "10:00AM",
        "isAvailable": true
      },
      {
        "time": "10:30AM",
        "isAvailable": true
      },
      {
        "time": "11:00AM",
        "isAvailable": true
      },
      {
        "time": "11:30AM",
        "isAvailable": true
      }
    ],
    "date": "2024-01-24",
    "timeOfDay": "morning"
  }
}
```

### Get My Appointments
**GET** `/api/appointments/my`

Get current user's appointments.

**Query Parameters:**
- `page` (optional): Page number (default: 1)
- `limit` (optional): Items per page (default: 10)

**Response:**
```json
{
  "success": true,
  "message": "Appointments retrieved successfully",
  "data": {
    "appointments": [
      {
        "id": 1,
        "patientId": 123,
        "doctorId": 1,
        "appointmentDate": "2024-01-24T00:00:00.000Z",
        "appointmentTime": "10:00AM",
        "serviceType": "Voice Call",
        "patientName": "John Doe",
        "patientAge": "25 - 30",
        "patientGender": "male",
        "problemDescription": "Chest pain consultation",
        "status": "confirmed",
        "totalAmount": 10.00,
        "doctor": {
          "id": 1,
          "fullName": "Dr. Jaime M. Mercado",
          "doctorId": "DOC001",
          "department": "Cardiology",
          "specialization": "Cardiology"
        }
      }
    ],
    "pagination": {
      "currentPage": 1,
      "totalPages": 1,
      "totalItems": 1,
      "itemsPerPage": 10
    }
  }
}
```

### Cancel Appointment
**DELETE** `/api/appointments/:id`

Cancel an appointment (only by the appointment owner).

**Response:**
```json
{
  "success": true,
  "message": "Appointment cancelled successfully"
}
```

## Services API

### Get Service Prices
**GET** `/api/services/prices`

Get all service prices for the booking screen.

**Response:**
```json
{
  "success": true,
  "message": "Service prices retrieved successfully",
  "data": {
    "prices": [
      {
        "type": "Voice Call",
        "price": 10.00,
        "description": "Can Make a Voice Call with Doctor"
      },
      {
        "type": "Messaging",
        "price": 6.00,
        "description": "Can Messaging with Doctor"
      },
      {
        "type": "Video Call",
        "price": 14.00,
        "description": "Can Make a Video Call with Doctor"
      }
    ]
  }
}
```

### Get All Services
**GET** `/api/services`

Get all active services.

**Response:**
```json
{
  "success": true,
  "message": "Services retrieved successfully",
  "data": {
    "services": [
      {
        "id": 1,
        "name": "Voice Call",
        "description": "Can Make a Voice Call with Doctor",
        "price": 10.00,
        "type": "Voice Call",
        "isActive": true
      },
      {
        "id": 2,
        "name": "Messaging",
        "description": "Can Messaging with Doctor",
        "price": 6.00,
        "type": "Messaging",
        "isActive": true
      },
      {
        "id": 3,
        "name": "Video Call",
        "description": "Can Make a Video Call with Doctor",
        "price": 14.00,
        "type": "Video Call",
        "isActive": true
      }
    ]
  }
}
```

## Reviews API

### Get Review Statistics
**GET** `/api/reviews/statistics`

Get review statistics for the dashboard.

**Response:**
```json
{
  "success": true,
  "message": "Review statistics retrieved successfully",
  "data": {
    "statistics": {
      "totalReviews": 348,
      "positiveReviews": 280,
      "negativeReviews": 67,
      "averageRating": 4.2,
      "positivePercentage": 80.5,
      "negativePercentage": 19.3,
      "positiveChange": 14.0,
      "negativeChange": -3.0
    }
  }
}
```

### Get Reviews by Doctor
**GET** `/api/reviews/doctor/:doctorId`

Get all reviews for a specific doctor.

**Response:**
```json
{
  "success": true,
  "message": "Reviews retrieved successfully",
  "data": {
    "reviews": [
      {
        "id": 1,
        "patientId": 456,
        "doctorId": 1,
        "rating": 5,
        "comment": "Excellent doctor with great bedside manner",
        "isRecommended": true,
        "createdAt": "2024-01-15T10:30:00.000Z",
        "patient": {
          "id": 456,
          "fullName": "Alicia J. Aldridge"
        }
      }
    ],
    "pagination": {
      "currentPage": 1,
      "totalPages": 5,
      "totalItems": 50,
      "itemsPerPage": 10
    }
  }
}
```

## Authentication

All protected endpoints require a JWT token in the Authorization header:

```
Authorization: Bearer <your-jwt-token>
```

## Usage Examples

### 1. Home Screen Flow

```bash
# Get categories for the home screen
curl -X GET "http://localhost:3000/api/categories"

# Get top doctors for the home screen
curl -X GET "http://localhost:3000/api/doctors/top?limit=3"
```

### 2. Category Selection Flow

```bash
# Search doctors by category
curl -X POST "http://localhost:3000/api/doctors/search" \
  -H "Content-Type: application/json" \
  -d '{
    "categoryIds": [1, 2],
    "page": 1,
    "limit": 10
  }'
```

### 3. Doctor Details Flow

```bash
# Get doctor details
curl -X GET "http://localhost:3000/api/doctors/1"

# Get doctor reviews
curl -X GET "http://localhost:3000/api/reviews/doctor/1"
```

### 4. Appointment Booking Flow

```bash
# Get available slots
curl -X GET "http://localhost:3000/api/doctors/1/available-slots?date=2024-01-24&timeOfDay=morning"

# Get service prices
curl -X GET "http://localhost:3000/api/services/prices"

# Create appointment
curl -X POST "http://localhost:3000/api/appointments" \
  -H "Authorization: Bearer <your-token>" \
  -H "Content-Type: application/json" \
  -d '{
    "doctorId": 1,
    "appointmentDate": "2024-01-24",
    "appointmentTime": "10:00AM",
    "serviceType": "Voice Call",
    "patientName": "John Doe",
    "patientAge": "25 - 30",
    "patientGender": "male",
    "problemDescription": "Chest pain consultation"
  }'
```

### 5. Review System Flow

```bash
# Create a review
curl -X POST "http://localhost:3000/api/reviews" \
  -H "Authorization: Bearer <your-token>" \
  -H "Content-Type: application/json" \
  -d '{
    "doctorId": 1,
    "rating": 5,
    "comment": "Excellent doctor with great bedside manner",
    "isRecommended": true
  }'

# Get review statistics
curl -X GET "http://localhost:3000/api/reviews/statistics"
```

## Database Schema

The mock APIs work with the following database tables:

1. **users** - Contains doctors and patients
2. **categories** - Medical categories
3. **reviews** - Patient reviews for doctors
4. **appointments** - Doctor appointments
5. **services** - Consultation services

## Error Responses

All APIs return consistent error responses:

```json
{
  "success": false,
  "message": "Error description"
}
```

Common HTTP status codes:
- `200` - Success
- `201` - Created
- `400` - Bad Request
- `401` - Unauthorized
- `404` - Not Found
- `500` - Internal Server Error

## Testing

You can test all endpoints using the provided Postman collections or curl commands. The APIs are designed to work seamlessly with the mobile app UI screens shown in your requirements. 