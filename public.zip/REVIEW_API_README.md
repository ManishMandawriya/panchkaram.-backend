# Review API Documentation

This document describes the Review API endpoints for the Panchakarma application, which allows patients to review doctors and view review statistics.

## Overview

The Review API provides functionality for:
- Creating reviews for doctors
- Retrieving reviews with filtering and pagination
- Updating and deleting reviews
- Getting review statistics
- Managing review data with proper validation

## Database Schema

### Reviews Table

```sql
CREATE TABLE reviews (
  id INT PRIMARY KEY AUTO_INCREMENT,
  patient_id INT NOT NULL,
  doctor_id INT NOT NULL,
  rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
  comment TEXT,
  is_recommended BOOLEAN NOT NULL DEFAULT TRUE,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  
  FOREIGN KEY (patient_id) REFERENCES users(id),
  FOREIGN KEY (doctor_id) REFERENCES users(id),
  INDEX idx_doctor_active (doctor_id, is_active),
  INDEX idx_patient_active (patient_id, is_active),
  INDEX idx_rating (rating),
  INDEX idx_created_at (created_at)
);
```

## API Endpoints

### Authentication
All review endpoints require authentication. Include the JWT token in the Authorization header:
```
Authorization: Bearer <your-jwt-token>
```

### 1. Create Review
**POST** `/api/reviews`

Create a new review for a doctor.

**Request Body:**
```json
{
  "doctorId": 123,
  "rating": 5,
  "comment": "Excellent doctor with great bedside manner",
  "isRecommended": true
}
```

**Response:**
```json
{
  "success": true,
  "message": "Review created successfully",
  "data": {
    "review": {
      "id": 1,
      "patientId": 456,
      "doctorId": 123,
      "rating": 5,
      "comment": "Excellent doctor with great bedside manner",
      "isRecommended": true,
      "isActive": true,
      "createdAt": "2024-01-15T10:30:00.000Z",
      "updatedAt": "2024-01-15T10:30:00.000Z"
    }
  }
}
```

### 2. Get Reviews
**GET** `/api/reviews`

Get all reviews with optional filtering and pagination.

**Query Parameters:**
- `doctorId` (optional): Filter by doctor ID
- `patientId` (optional): Filter by patient ID
- `rating` (optional): Filter by rating (1-5)
- `isRecommended` (optional): Filter by recommendation status
- `startDate` (optional): Filter by start date (ISO format)
- `endDate` (optional): Filter by end date (ISO format)
- `page` (optional): Page number (default: 1)
- `limit` (optional): Items per page (default: 10, max: 100)
- `sortBy` (optional): Sort field ('createdAt' or 'rating', default: 'createdAt')
- `sortOrder` (optional): Sort order ('ASC' or 'DESC', default: 'DESC')

**Response:**
```json
{
  "success": true,
  "message": "Reviews retrieved successfully",
  "data": {
    "reviews": [
      {
        "id": 1,
        "patientId": 456,
        "doctorId": 123,
        "rating": 5,
        "comment": "Excellent doctor",
        "isRecommended": true,
        "isActive": true,
        "createdAt": "2024-01-15T10:30:00.000Z",
        "updatedAt": "2024-01-15T10:30:00.000Z",
        "patient": {
          "id": 456,
          "fullName": "John Doe"
        },
        "doctor": {
          "id": 123,
          "fullName": "Dr. Jane Smith",
          "doctorId": "DOC001",
          "department": "Cardiology",
          "specialization": "Interventional Cardiology"
        }
      }
    ],
    "pagination": {
      "currentPage": 1,
      "totalPages": 5,
      "totalItems": 50,
      "itemsPerPage": 10
    }
  }
}
```

### 3. Get Review Statistics
**GET** `/api/reviews/statistics`

Get review statistics for the last 7 days with comparison to previous period.

**Query Parameters:**
- `doctorId` (optional): Get statistics for specific doctor

**Response:**
```json
{
  "success": true,
  "message": "Review statistics retrieved successfully",
  "data": {
    "statistics": {
      "totalReviews": 348,
      "positiveReviews": 280,
      "negativeReviews": 67,
      "averageRating": 4.2,
      "positivePercentage": 80.5,
      "negativePercentage": 19.3,
      "positiveChange": 14.0,
      "negativeChange": -3.0
    }
  }
}
```

### 4. Get Reviews by Doctor
**GET** `/api/reviews/doctor/:doctorId`

Get all reviews for a specific doctor.

**Path Parameters:**
- `doctorId`: Doctor's ID

**Query Parameters:**
- `page` (optional): Page number (default: 1)
- `limit` (optional): Items per page (default: 10)

### 5. Get My Reviews
**GET** `/api/reviews/patient/me`

Get current user's reviews.

**Query Parameters:**
- `page` (optional): Page number (default: 1)
- `limit` (optional): Items per page (default: 10)

### 6. Get Review by ID
**GET** `/api/reviews/:id`

Get a specific review by ID.

**Path Parameters:**
- `id`: Review ID

### 7. Update Review
**PUT** `/api/reviews/:id`

Update an existing review (only by the review author).

**Path Parameters:**
- `id`: Review ID

**Request Body:**
```json
{
  "rating": 4,
  "comment": "Updated comment",
  "isRecommended": false
}
```

### 8. Delete Review
**DELETE** `/api/reviews/:id`

Delete a review (soft delete, only by the review author).

**Path Parameters:**
- `id`: Review ID

## Validation Rules

### Create Review
- `doctorId`: Required, positive integer
- `rating`: Required, integer between 1-5
- `comment`: Optional, max 250 characters
- `isRecommended`: Required, boolean

### Update Review
- `rating`: Optional, integer between 1-5
- `comment`: Optional, max 250 characters
- `isRecommended`: Optional, boolean

### Query Parameters
- `doctorId`: Optional, positive integer
- `patientId`: Optional, positive integer
- `rating`: Optional, integer between 1-5
- `isRecommended`: Optional, boolean
- `startDate`: Optional, valid date
- `endDate`: Optional, valid date (must be after startDate)
- `page`: Optional, positive integer (default: 1)
- `limit`: Optional, integer between 1-100 (default: 10)
- `sortBy`: Optional, 'createdAt' or 'rating' (default: 'createdAt')
- `sortOrder`: Optional, 'ASC' or 'DESC' (default: 'DESC')

## Business Rules

1. **One Review Per Patient-Doctor Pair**: A patient can only review a doctor once
2. **Doctor Validation**: Reviews can only be created for approved and active doctors
3. **Patient Validation**: Reviews can only be created by active patients
4. **Ownership**: Users can only update/delete their own reviews
5. **Soft Delete**: Reviews are soft deleted (isActive = false) rather than hard deleted
6. **Rating Validation**: Ratings must be between 1-5 stars
7. **Comment Length**: Comments are limited to 250 characters

## Statistics Calculation

The statistics endpoint calculates:
- **Positive Reviews**: Reviews with rating >= 4
- **Negative Reviews**: Reviews with rating <= 2
- **Average Rating**: Mean of all ratings
- **Percentages**: Percentage of positive/negative reviews
- **Change**: Percentage change from previous 7-day period

## Error Responses

### 400 Bad Request
```json
{
  "success": false,
  "message": "Validation error message"
}
```

### 401 Unauthorized
```json
{
  "success": false,
  "message": "Authentication required"
}
```

### 404 Not Found
```json
{
  "success": false,
  "message": "Review not found"
}
```

### 500 Internal Server Error
```json
{
  "success": false,
  "message": "Failed to process request. Please try again."
}
```

## Usage Examples

### Creating a Review
```bash
curl -X POST http://localhost:3000/api/reviews \
  -H "Authorization: Bearer <your-token>" \
  -H "Content-Type: application/json" \
  -d '{
    "doctorId": 123,
    "rating": 5,
    "comment": "Excellent doctor with great bedside manner",
    "isRecommended": true
  }'
```

### Getting Reviews with Filters
```bash
curl -X GET "http://localhost:3000/api/reviews?doctorId=123&rating=5&page=1&limit=10" \
  -H "Authorization: Bearer <your-token>"
```

### Getting Statistics
```bash
curl -X GET "http://localhost:3000/api/reviews/statistics?doctorId=123" \
  -H "Authorization: Bearer <your-token>"
```

## Database Indexes

The following indexes are created for optimal performance:
- `idx_doctor_active`: For filtering reviews by doctor and active status
- `idx_patient_active`: For filtering reviews by patient and active status
- `idx_rating`: For filtering and sorting by rating
- `idx_created_at`: For sorting by creation date

## Security Considerations

1. **Authentication**: All endpoints require valid JWT tokens
2. **Authorization**: Users can only modify their own reviews
3. **Input Validation**: All inputs are validated using Joi schemas
4. **SQL Injection**: Protected through Sequelize ORM
5. **Rate Limiting**: Applied through existing middleware
6. **Data Sanitization**: Comments are validated for length and content 