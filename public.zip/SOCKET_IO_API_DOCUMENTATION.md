# Socket.IO API Documentation for Frontend

## 🔌 Connection Details

### Base URL
```
http://localhost:3000
```

### Connection Options
```javascript
const socket = io('http://localhost:3000', {
  auth: {
    token: 'your-jwt-token-here'
  },
  transports: ['websocket', 'polling']
});
```

## 🔑 Authentication

### JWT Token Required
All Socket.IO connections require a valid JWT token in the auth object.

**Token Format:**
```javascript
// Get token from your login API response
const token = loginResponse.data.token;

// Use in Socket.IO connection
const socket = io('http://localhost:3000', {
  auth: { token }
});
```

## 📡 Socket Events

### 1. Join Session
**Event:** `join-session`  
**Direction:** Client → Server  
**Description:** Join a specific chat session

**Payload:**
```javascript
{
  sessionId: "1-5-1703123456789" // String - Session ID from API
}
```

**Response Event:** `session-joined`  
**Response Payload:**
```javascript
{
  success: true,
  sessionId: "1-5-1703123456789",
  sessionType: "chat", // "chat" | "audioCall" | "videoCall"
  status: "scheduled", // "scheduled" | "ongoing" | "ended" | "canceled"
  participants: {
    doctor: { id: 1, name: "Dr. Smith" },
    patient: { id: 5, name: "John Doe" }
  }
}
```

**Error Response:**
```javascript
{
  success: false,
  error: "Session not found" | "Unauthorized" | "Session already ended"
}
```

---

### 2. Send Message
**Event:** `send-message`  
**Direction:** Client → Server  
**Description:** Send a message in the current session

**Payload:**
```javascript
{
  sessionId: "1-5-1703123456789", // String - Session ID
  content: "Hello doctor!", // String - Message content
  messageType: "text", // "text" | "image" | "file" | "audio" | "video"
  replyToMessageId: "msg-123" // Optional - Reply to specific message
}
```

**Response Event:** `new-message` (sent to all participants)  
**Response Payload:**
```javascript
{
  messageId: "msg-1703123456789",
  sessionId: "1-5-1703123456789",
  senderId: 5,
  senderName: "John Doe",
  content: "Hello doctor!",
  messageType: "text",
  direction: "inbound", // "inbound" | "outbound" | "system"
  status: "sent",
  sentAt: "2024-01-20T10:30:00.000Z",
  replyToMessageId: null
}
```

**Error Response:**
```javascript
{
  success: false,
  error: "Session not found" | "Message too long" | "Invalid message type"
}
```

---

### 3. Typing Indicators
**Event:** `typing-start`  
**Direction:** Client → Server  
**Description:** Indicate that user is typing

**Payload:**
```javascript
{
  sessionId: "1-5-1703123456789"
}
```

**Response Event:** `typing-indicator` (sent to other participants)  
**Response Payload:**
```javascript
{
  sessionId: "1-5-1703123456789",
  userId: 5,
  userName: "John Doe",
  isTyping: true
}
```

---

**Event:** `typing-stop`  
**Direction:** Client → Server  
**Description:** Stop typing indicator

**Payload:**
```javascript
{
  sessionId: "1-5-1703123456789"
}
```

**Response Event:** `typing-indicator` (sent to other participants)  
**Response Payload:**
```javascript
{
  sessionId: "1-5-1703123456789",
  userId: 5,
  userName: "John Doe",
  isTyping: false
}
```

---

### 4. Mark Message as Read
**Event:** `mark-read`  
**Direction:** Client → Server  
**Description:** Mark a message as read

**Payload:**
```javascript
{
  sessionId: "1-5-1703123456789",
  messageId: "msg-1703123456789"
}
```

**Response Event:** `message-read` (sent to message sender)  
**Response Payload:**
```javascript
{
  sessionId: "1-5-1703123456789",
  messageId: "msg-1703123456789",
  readBy: {
    userId: 5,
    userName: "John Doe",
    readAt: "2024-01-20T10:35:00.000Z"
  }
}
```

---

### 5. End Session
**Event:** `end-session`  
**Direction:** Client → Server  
**Description:** End the current chat session

**Payload:**
```javascript
{
  sessionId: "1-5-1703123456789"
}
```

**Response Event:** `session-ended` (sent to all participants)  
**Response Payload:**
```javascript
{
  sessionId: "1-5-1703123456789",
  endedBy: {
    userId: 1,
    userName: "Dr. Smith"
  },
  endedAt: "2024-01-20T11:00:00.000Z",
  duration: 1800 // Duration in seconds
}
```

---

### 6. Disconnect
**Event:** `disconnect`  
**Direction:** Client → Server  
**Description:** Automatically triggered when client disconnects

**No payload required**

**Response Event:** `user-disconnected` (sent to other participants)  
**Response Payload:**
```javascript
{
  sessionId: "1-5-1703123456789",
  userId: 5,
  userName: "John Doe",
  disconnectedAt: "2024-01-20T11:05:00.000Z"
}
```

## 📋 System Events

### Connection Events
```javascript
// Connection established
socket.on('connect', () => {
  console.log('Connected to Socket.IO');
  console.log('Socket ID:', socket.id);
});

// Connection error
socket.on('connect_error', (error) => {
  console.error('Connection error:', error.message);
});

// Disconnected
socket.on('disconnect', (reason) => {
  console.log('Disconnected:', reason);
});
```

### Error Events
```javascript
// General error
socket.on('error', (data) => {
  console.error('Socket error:', data);
});
```

## 🔄 Complete Frontend Implementation Example

```javascript
class ChatSocketService {
  constructor(token) {
    this.socket = io('http://localhost:3000', {
      auth: { token },
      transports: ['websocket', 'polling']
    });
    
    this.setupEventListeners();
  }

  setupEventListeners() {
    // Connection events
    this.socket.on('connect', () => {
      console.log('✅ Connected to chat server');
    });

    this.socket.on('connect_error', (error) => {
      console.error('❌ Connection error:', error.message);
    });

    // Chat events
    this.socket.on('session-joined', (data) => {
      console.log('✅ Joined session:', data);
      // Handle session joined
    });

    this.socket.on('new-message', (message) => {
      console.log('📨 New message:', message);
      // Handle new message
    });

    this.socket.on('typing-indicator', (data) => {
      console.log('⌨️ Typing indicator:', data);
      // Handle typing indicator
    });

    this.socket.on('message-read', (data) => {
      console.log('👁️ Message read:', data);
      // Handle message read
    });

    this.socket.on('session-ended', (data) => {
      console.log('🔚 Session ended:', data);
      // Handle session ended
    });

    this.socket.on('user-disconnected', (data) => {
      console.log('👋 User disconnected:', data);
      // Handle user disconnected
    });

    this.socket.on('error', (data) => {
      console.error('❌ Socket error:', data);
    });
  }

  // Join a chat session
  joinSession(sessionId) {
    this.socket.emit('join-session', sessionId);
  }

  // Send a message
  sendMessage(sessionId, content, messageType = 'text', replyToMessageId = null) {
    this.socket.emit('send-message', {
      sessionId,
      content,
      messageType,
      replyToMessageId
    });
  }

  // Start typing indicator
  startTyping(sessionId) {
    this.socket.emit('typing-start', { sessionId });
  }

  // Stop typing indicator
  stopTyping(sessionId) {
    this.socket.emit('typing-stop', { sessionId });
  }

  // Mark message as read
  markMessageAsRead(sessionId, messageId) {
    this.socket.emit('mark-read', { sessionId, messageId });
  }

  // End session
  endSession(sessionId) {
    this.socket.emit('end-session', { sessionId });
  }

  // Disconnect
  disconnect() {
    this.socket.disconnect();
  }
}

// Usage example
const chatService = new ChatSocketService('your-jwt-token');

// Join a session
chatService.joinSession('1-5-1703123456789');

// Send a message
chatService.sendMessage('1-5-1703123456789', 'Hello doctor!');

// Start typing
chatService.startTyping('1-5-1703123456789');

// Stop typing after 2 seconds
setTimeout(() => {
  chatService.stopTyping('1-5-1703123456789');
}, 2000);
```

## 🧪 Testing with Postman

### 1. Get JWT Token
```http
POST http://localhost:3000/api/auth/login
Content-Type: application/json

{
  "phoneNumber": "1234567890",
  "password": "your-password"
}
```

### 2. Test Socket.IO Connection
Use the HTML test file: `socketio-test.html`

Or use Postman's Socket.IO feature with these settings:
- **URL:** `http://localhost:3000`
- **Auth:** Add token in auth object
- **Events:** Use the events listed above

## 📝 Important Notes

1. **Session ID Format:** `{doctorId}-{patientId}-{timestamp}`
2. **Message Types:** `text`, `image`, `file`, `audio`, `video`
3. **Session Types:** `chat`, `audioCall`, `videoCall`
4. **Session Status:** `scheduled`, `ongoing`, `ended`, `canceled`
5. **Message Direction:** `inbound` (patient→doctor), `outbound` (doctor→patient), `system`
6. **Message Status:** `sent`, `delivered`, `read`, `failed`, `pending`

## 🚨 Error Handling

Always handle these error scenarios:
- Connection failures
- Authentication errors
- Session not found
- Invalid message format
- Network disconnections

## 📱 React Component Example

```jsx
import React, { useEffect, useState } from 'react';
import { io } from 'socket.io-client';

const ChatComponent = ({ sessionId, token }) => {
  const [socket, setSocket] = useState(null);
  const [messages, setMessages] = useState([]);
  const [isTyping, setIsTyping] = useState(false);

  useEffect(() => {
    const newSocket = io('http://localhost:3000', {
      auth: { token }
    });

    newSocket.on('connect', () => {
      console.log('Connected to chat');
      newSocket.emit('join-session', sessionId);
    });

    newSocket.on('new-message', (message) => {
      setMessages(prev => [...prev, message]);
    });

    newSocket.on('typing-indicator', (data) => {
      setIsTyping(data.isTyping);
    });

    setSocket(newSocket);

    return () => newSocket.close();
  }, [sessionId, token]);

  const sendMessage = (content) => {
    socket.emit('send-message', {
      sessionId,
      content,
      messageType: 'text'
    });
  };

  return (
    <div>
      {/* Chat UI */}
    </div>
  );
};
```

---

**Need help?** Check the server logs for detailed error messages and refer to the troubleshooting section in the deployment guide.
