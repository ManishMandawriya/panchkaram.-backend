const { Sequelize } = require('sequelize');

// Database connection
const sequelize = new Sequelize('panchakarma', 'root', '', {
  host: 'localhost',
  dialect: 'mysql',
  logging: false
});

async function testMessageInsert() {
  try {
    await sequelize.authenticate();
    console.log('✅ Database connection established.');

    // Get or create a chat
    let [chats] = await sequelize.query(`
      SELECT * FROM chats WHERE doctor_id = 1 AND patient_id = 1
    `);
    
    let chatId;
    if (chats.length === 0) {
      const [newChat] = await sequelize.query(`
        INSERT INTO chats (doctor_id, patient_id, is_active, created_at, updated_at) 
        VALUES (1, 1, 1, NOW(), NOW())
      `);
      chatId = newChat.insertId;
      console.log('✅ Created new chat with ID:', chatId);
    } else {
      chatId = chats[0].id;
      console.log('✅ Using existing chat with ID:', chatId);
    }

    // Get or create a session
    let [sessions] = await sequelize.query(`
      SELECT * FROM chat_sessions WHERE chat_id = ${chatId}
    `);
    
    let sessionId;
    if (sessions.length === 0) {
      const sessionIdStr = `1-1-${Date.now()}`;
      const [newSession] = await sequelize.query(`
        INSERT INTO chat_sessions (
          chat_id, session_id, doctor_id, patient_id, 
          session_type, session_token, status, start_time, is_active, created_at, updated_at
        ) VALUES (
          ${chatId}, '${sessionIdStr}', 1, 1, 
          'chat', 'test-token-123', 'scheduled', NOW(), 1, NOW(), NOW()
        )
      `);
      sessionId = newSession.insertId;
      console.log('✅ Created new session with ID:', sessionId);
    } else {
      sessionId = sessions[0].id;
      console.log('✅ Using existing session with ID:', sessionId);
    }

    // Test inserting a message
    console.log('\n🔧 Testing message insertion...');
    
    const messageId = `msg-${Date.now()}`;
    const [newMessage] = await sequelize.query(`
      INSERT INTO chat_messages (
        chat_id, session_id, sender_id, message_id, message_type, direction, content, 
        status, sent_at, is_edited, is_deleted, is_active, created_at, updated_at
      ) VALUES (
        ${chatId}, ${sessionId}, 1, '${messageId}', 'text', 'inbound', 'Hello from test!', 
        'sent', NOW(), 0, 0, 1, NOW(), NOW()
      )
    `);
    
    console.log('✅ Message inserted successfully!');
    console.log('Message ID:', newMessage.insertId);

    // Verify the message was inserted
    const [messages] = await sequelize.query(`
      SELECT * FROM chat_messages WHERE id = ${newMessage.insertId}
    `);
    
    if (messages.length > 0) {
      console.log('✅ Message verified in database:', messages[0]);
    } else {
      console.log('❌ Message not found in database');
    }

    console.log('\n🎉 Message insertion test completed successfully!');

  } catch (error) {
    console.error('❌ Error testing message insertion:', error.message);
    throw error;
  } finally {
    await sequelize.close();
  }
}

// Run the test
testMessageInsert()
  .then(() => {
    console.log('\n🎉 All tests passed!');
    process.exit(0);
  })
  .catch((error) => {
    console.error('❌ Test failed:', error);
    process.exit(1);
  });
