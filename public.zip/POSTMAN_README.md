# 🧪 Panchakarma API - Postman Collection

This directory contains the complete Postman collection and environment for testing the Panchakarma API.

## 📁 Files

- **`Panchakarma_API.postman_collection.json`** - Complete API collection
- **`Panchakarma_Environment.postman_environment.json`** - Environment variables
- **`POSTMAN_README.md`** - This documentation

## 🚀 Quick Start

### 1. Import Collection & Environment

1. **Open Postman**
2. **Import Collection:**
   - Click "Import" → "Upload Files"
   - Select `Panchakarma_API.postman_collection.json`
3. **Import Environment:**
   - Click "Import" → "Upload Files"
   - Select `Panchakarma_Environment.postman_environment.json`
4. **Select Environment:**
   - In the top-right dropdown, select "Panchakarma Environment"

### 2. Start the API Server

```bash
# Install dependencies (if not done)
npm install

# Start the development server
npm run dev
```

The API will be available at `http://localhost:3000`

### 3. Test the APIs

Follow this testing sequence:

## 🔄 Testing Sequence

### Step 1: Health Checks
1. **API Health Check** - Verify API is running
2. **Admin Health Check** - Verify admin API is running

### Step 2: User Registration & Authentication
1. **Register Patient** - Create a new patient account
2. **Register Doctor** - Create a new doctor account (requires approval)
3. **Register Clinic** - Create a new clinic account (requires approval)
4. **Verify Email** - Verify email with verification code
5. **Resend Email Verification** - Resend email verification if needed
6. **Login** - Login with registered credentials
7. **Get Profile** - Get user profile (requires auth token)

### Step 3: Password Management
1. **Forgot Password** - Request password reset
2. **Verify Code** - Verify SMS code
3. **Reset Password** - Reset password with verified code
4. **Resend OTP** - Resend OTP if needed
5. **Change Password** - Change password (requires auth)

### Step 4: Admin Operations
1. **Admin Login** - Login as admin
2. **Get Dashboard** - View admin dashboard
3. **Get All Users** - List all users with pagination
4. **Get User by ID** - Get specific user details
5. **Approve User** - Approve/reject healthcare providers
6. **Update User Status** - Activate/deactivate users
7. **Delete User** - Delete user account

### Step 5: File Upload
1. **Upload Single File** - Upload documents/images
2. **Upload Multiple Files** - Upload multiple files

## 🔧 Environment Variables

The environment includes these variables:

| Variable | Description | Default Value |
|----------|-------------|---------------|
| `base_url` | API base URL | `http://localhost:3000` |
| `environment` | Environment name | `development` |
| `access_token` | User access token | (auto-filled) |
| `refresh_token` | User refresh token | (auto-filled) |
| `admin_token` | Admin access token | (auto-filled) |
| `admin_refresh_token` | Admin refresh token | (auto-filled) |
| `user_id` | Current user ID | (auto-filled) |
| `admin_id` | Admin user ID | (auto-filled) |
| `test_email` | Test email address | `test@example.com` |
| `test_phone` | Test phone number | `+1234567890` |
| `test_password` | Test password | `password123` |
| `verification_code` | SMS verification code | `123456` |

## 📋 API Endpoints Overview

### 🔓 Public APIs (No Authentication)
- `GET /api/health` - Health check
- `POST /api/auth/register` - User registration
- `POST /api/auth/login` - User login
- `POST /api/auth/forgot-password` - Password reset request
- `POST /api/auth/verify-code` - Verify SMS code
- `POST /api/auth/reset-password` - Reset password
- `POST /api/auth/refresh-token` - Refresh access token
- `POST /api/auth/verify-email` - Verify email with code
- `POST /api/auth/resend-email-verification` - Resend email verification
- `POST /api/auth/resend-otp` - Resend OTP for forgot password

### 🔐 Protected APIs (Require Authentication)
- `GET /api/auth/profile` - Get user profile
- `POST /api/auth/change-password` - Change password
- `POST /api/auth/logout` - Logout

### 👨‍💼 Admin APIs
- `POST /admin/auth/login` - Admin login
- `GET /admin/auth/dashboard` - Admin dashboard
- `GET /admin/auth/users` - List all users
- `GET /admin/auth/users/:id` - Get user by ID
- `PUT /admin/auth/users/:id/approve` - Approve user
- `PUT /admin/auth/users/:id/status` - Update user status
- `DELETE /admin/auth/users/:id` - Delete user
- `POST /admin/auth/logout` - Admin logout

### 📁 File Upload APIs
- `POST /api/upload/single` - Upload single file
- `POST /api/upload/multiple` - Upload multiple files

## 🎯 Test Scenarios

### Scenario 1: Patient Registration & Login
1. Register a new patient
2. Login with patient credentials
3. Get patient profile
4. Change password
5. Logout

### Scenario 2: Doctor Registration & Approval
1. Register a new doctor
2. Login as admin
3. View pending approvals
4. Approve the doctor
5. Doctor can now login

### Scenario 3: Password Reset Flow
1. Request password reset
2. Verify SMS code
3. Reset password
4. Login with new password

### Scenario 4: Admin User Management
1. Login as admin
2. View all users
3. Filter by role/status
4. Approve/reject healthcare providers
5. Activate/deactivate users
6. Delete users

## 🔄 Auto-Token Management

The collection includes automatic token management:

- **Login Success**: Tokens are automatically saved to environment variables
- **Token Refresh**: Use refresh token to get new access token
- **Secure Storage**: Tokens are stored as environment secrets

## 📊 Response Validation

Each request includes automatic response validation:

- Status code validation
- Response structure validation
- Success property check
- Automatic token extraction

## 🛠️ Customization

### Adding New Endpoints
1. Create new request in appropriate folder
2. Set proper headers and authentication
3. Add request body if needed
4. Add response validation tests

### Modifying Environment
1. Edit environment variables in Postman
2. Update base URL for different environments
3. Add new variables as needed

### Adding Test Data
1. Update test email/phone in environment
2. Modify request bodies with new test data
3. Update verification codes as needed

## 🐛 Troubleshooting

### Common Issues

**1. Connection Refused**
- Ensure API server is running (`npm run dev`)
- Check if port 3000 is available
- Verify base_url in environment

**2. Authentication Errors**
- Check if tokens are properly set
- Verify token format (Bearer prefix)
- Ensure tokens haven't expired

**3. Validation Errors**
- Check request body format
- Verify required fields are present
- Ensure data types are correct

**4. File Upload Issues**
- Check file size limits
- Verify file types are allowed
- Ensure proper multipart form data

### Debug Steps

1. **Check API Status**
   ```
   GET {{base_url}}/api/health
   ```

2. **Verify Environment**
   - Check environment is selected
   - Verify base_url is correct
   - Ensure tokens are set

3. **Test Authentication**
   ```
   POST {{base_url}}/api/auth/login
   ```

4. **Check Server Logs**
   - Monitor console output
   - Check for error messages
   - Verify database connection

## 📝 Notes

- **Development Mode**: Collection is configured for development environment
- **Auto-Save**: Tokens are automatically saved on successful login
- **Test Data**: Use provided test data or modify as needed
- **Rate Limiting**: Be aware of rate limits in production
- **Security**: Tokens are stored as secrets in environment

## 🚀 Production Setup

For production testing:

1. **Update Environment Variables:**
   - Change `base_url` to production URL
   - Update `environment` to "production"

2. **Security Considerations:**
   - Use HTTPS URLs
   - Implement proper token management
   - Add additional validation tests

3. **Performance Testing:**
   - Add load testing scenarios
   - Monitor response times
   - Test rate limiting

---

## 📞 Support

For issues with the API or collection:
- Check the main README.md for API documentation
- Review server logs for error details
- Verify environment configuration
- Test with curl commands for comparison

Happy Testing! 🎉 