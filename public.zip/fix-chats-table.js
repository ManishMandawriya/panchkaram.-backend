const { Sequelize } = require('sequelize');

// Database connection
const sequelize = new Sequelize('panchakarma', 'root', '', {
  host: 'localhost',
  dialect: 'mysql',
  logging: false
});

async function fixChatsTable() {
  try {
    await sequelize.authenticate();
    console.log('✅ Database connection established.');

    // Check current chats table structure
    const [columns] = await sequelize.query('DESCRIBE chats');
    console.log('\n📋 Current chats table structure:');
    columns.forEach(row => {
      console.log(`  ${row.Field} - ${row.Type}`);
    });

    // Check if is_active column exists
    const hasIsActive = columns.some(col => col.Field === 'is_active');
    
    if (!hasIsActive) {
      console.log('\n🔧 Adding missing is_active column to chats table...');
      
      // Add is_active column
      await sequelize.query('ALTER TABLE chats ADD COLUMN is_active BOOLEAN DEFAULT TRUE');
      console.log('✅ Added is_active column');
      
    } else {
      console.log('✅ is_active column already exists');
    }

    // Show updated structure
    const [updatedColumns] = await sequelize.query('DESCRIBE chats');
    console.log('\n📋 Updated chats table structure:');
    updatedColumns.forEach(row => {
      console.log(`  ${row.Field} - ${row.Type}`);
    });

    console.log('\n🎉 Chats table fixed successfully!');

  } catch (error) {
    console.error('❌ Error fixing chats table:', error.message);
    throw error;
  } finally {
    await sequelize.close();
  }
}

// Run the script
fixChatsTable()
  .then(() => {
    console.log('\n🎉 Chats table fixed successfully!');
    process.exit(0);
  })
  .catch((error) => {
    console.error('❌ Failed to fix chats table:', error);
    process.exit(1);
  });
