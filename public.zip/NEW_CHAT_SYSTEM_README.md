# New Chat System Documentation

## Overview

The new chat system has been restructured with a three-table architecture to better manage chat relationships, sessions, and messages. This provides better scalability and supports multiple session types (chat, audio, video) within the same doctor-patient relationship.

## Database Structure

### 1. `chats` Table
Single entry per doctor-patient pair. This table maintains the relationship between doctors and patients.

```sql
CREATE TABLE chats (
  id INT AUTO_INCREMENT PRIMARY KEY,
  doctor_id INT NOT NULL,
  patient_id INT NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  
  UNIQUE KEY unique_doctor_patient (doctor_id, patient_id),
  FOREIGN KEY (doctor_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (patient_id) REFERENCES users(id) ON DELETE CASCADE
);
```

### 2. `chat_sessions` Table
Multiple sessions per chat. Each session represents a specific communication instance.

```sql
CREATE TABLE chat_sessions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  chat_id INT NOT NULL,
  session_id VARCHAR(255) NOT NULL UNIQUE,
  doctor_id INT NOT NULL,
  patient_id INT NOT NULL,
  session_type ENUM('chat', 'audioCall', 'videoCall') NOT NULL DEFAULT 'chat',
  session_token VARCHAR(500) NULL,
  status ENUM('scheduled', 'ongoing', 'ended', 'canceled') NOT NULL DEFAULT 'scheduled',
  start_time DATETIME NULL,
  end_time DATETIME NULL,
  patient_joined_at DATETIME NULL,
  doctor_joined_at DATETIME NULL,
  duration INT NOT NULL DEFAULT 0 COMMENT 'Duration in seconds',
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  
  FOREIGN KEY (chat_id) REFERENCES chats(id) ON DELETE CASCADE,
  FOREIGN KEY (doctor_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (patient_id) REFERENCES users(id) ON DELETE CASCADE
);
```

### 3. `chat_messages` Table
Messages within sessions. Each message belongs to both a chat and a specific session.

```sql
CREATE TABLE chat_messages (
  id INT AUTO_INCREMENT PRIMARY KEY,
  chat_id INT NOT NULL,
  session_id INT NOT NULL,
  sender_id INT NOT NULL,
  message_type ENUM('text', 'image', 'file', 'audio', 'video', 'system') NOT NULL DEFAULT 'text',
  direction ENUM('inbound', 'outbound', 'system') NOT NULL DEFAULT 'inbound',
  content TEXT NOT NULL,
  file_url VARCHAR(500) NULL,
  file_name VARCHAR(255) NULL,
  file_type VARCHAR(100) NULL,
  file_size INT NULL,
  status ENUM('sent', 'delivered', 'read', 'failed', 'pending') NOT NULL DEFAULT 'pending',
  sent_at DATETIME NULL,
  delivered_at DATETIME NULL,
  read_at DATETIME NULL,
  message_id VARCHAR(36) NULL,
  reply_to_message_id VARCHAR(36) NULL,
  is_edited BOOLEAN NOT NULL DEFAULT FALSE,
  edited_at DATETIME NULL,
  is_deleted BOOLEAN NOT NULL DEFAULT FALSE,
  deleted_at DATETIME NULL,
  metadata JSON NULL,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  
  FOREIGN KEY (chat_id) REFERENCES chats(id) ON DELETE CASCADE,
  FOREIGN KEY (session_id) REFERENCES chat_sessions(id) ON DELETE CASCADE,
  FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE
);
```

## API Endpoints

### Session Verification
**GET** `/api/chat/verify-session`
- **Purpose**: Check if user has an active session
- **Query Parameters**: `userRole` (patient|doctor)
- **Response**: Returns active session details if found

### Session Management

**POST** `/api/chat/sessions`
- **Purpose**: Create a new chat session
- **Body**: `{ doctorId, sessionType, sessionToken? }`
- **Response**: Session creation result

**GET** `/api/chat/sessions`
- **Purpose**: Get user's chat sessions
- **Query Parameters**: `page`, `limit`, `status`, `sessionType`
- **Response**: Paginated list of sessions

**GET** `/api/chat/sessions/:id`
- **Purpose**: Get session details
- **Response**: Session details with participants

**POST** `/api/chat/sessions/:sessionId/join`
- **Purpose**: Join a session
- **Body**: `{ userRole }`
- **Response**: Join result

**PUT** `/api/chat/sessions/:id/end`
- **Purpose**: End a session
- **Response**: Session end result

### Message Management

**POST** `/api/chat/sessions/:id/messages`
- **Purpose**: Send a message
- **Body**: `{ content, messageType?, fileUrl?, fileName?, fileType?, fileSize?, replyToMessageId? }`
- **Response**: Message creation result

**GET** `/api/chat/sessions/:id/messages`
- **Purpose**: Get messages for a session
- **Query Parameters**: `page`, `limit`, `status`, `messageType`, `beforeDate`, `afterDate`
- **Response**: Paginated list of messages

**PUT** `/api/chat/sessions/:id/messages/read`
- **Purpose**: Mark messages as read
- **Body**: `{ messageIds? }`
- **Response**: Read status update result

### Chat History

**GET** `/api/chat/history/:doctorId/:patientId`
- **Purpose**: Get chat history between doctor and patient
- **Response**: Complete chat history with all sessions and messages

## Flow Description

### 1. User Accessing Chat Page
When a patient or doctor accesses the chat page:

1. **Verify Session**: Call `GET /api/chat/verify-session?userRole=patient|doctor`
2. **If Active Session Found**: Connect to WebSocket and join session room
3. **If No Active Session**: User can create a new session via API, then connect to WebSocket

### 2. Creating a New Session
1. **Patient Creates Session**: `POST /api/chat/sessions` with doctor ID and session type
2. **System Creates Chat**: If no chat exists between doctor-patient pair, create one
3. **System Creates Session**: Create a new session with unique session ID
4. **System Sends Initial Message**: Send system message indicating session created

### 3. Joining a Session
1. **User Joins**: `POST /api/chat/sessions/:sessionId/join` with user role
2. **System Marks User Joined**: Update `patient_joined_at` or `doctor_joined_at`
3. **If Both Joined**: Automatically change status to 'ongoing'
4. **System Sends Join Message**: Send system message indicating user joined

### 4. Sending Messages (WebSocket)
1. **User Sends Message**: Emit `send-message` event via WebSocket
2. **System Validates**: Check if session is active and user is authorized
3. **System Creates Message**: Store message in database with chat_id and session_id
4. **System Broadcasts**: Emit `new-message` event to all participants in session room
5. **Real-time Delivery**: Messages appear instantly for all participants

### 5. Session Management
- **Session Status Flow**: `scheduled` → `ongoing` → `ended`
- **Duration Tracking**: Automatically calculated when session ends
- **System Messages**: Sent for important events (join, leave, end)

## WebSocket Integration

### Connection
- **Room Name**: Use `sessionId` from the session
- **Authentication**: JWT token verification required
- **User Identification**: Include user ID and role in socket data

### Client to Server Events
- **join-session**: Join a specific chat session
- **send-message**: Send a new message
- **typing-start**: Start typing indicator
- **typing-stop**: Stop typing indicator
- **mark-read**: Mark messages as read
- **end-session**: End the current session

### Server to Client Events
- **session-joined**: Confirmation of joining session
- **user-joined**: Another user joined the session
- **user-left**: Another user left the session
- **new-message**: New message received
- **user-typing**: User typing indicator
- **messages-read**: Messages marked as read
- **session-ended**: Session ended
- **error**: Error occurred

### Message Format
```javascript
{
  sessionId: "session_1_2_abc123",
  senderId: 1,
  content: "Hello!",
  messageType: "text",
  timestamp: "2024-01-01T12:00:00Z"
}
```

## Key Features

### 1. No Duplicate Chats
- Unique constraint on `(doctor_id, patient_id)` in chats table
- `Chat.findOrCreateChat()` method ensures single chat per doctor-patient pair

### 2. Multiple Session Types
- Support for chat, audio call, and video call sessions
- Each session can have different type and token

### 3. Session Lifecycle
- **Scheduled**: Session created, waiting for participants
- **Ongoing**: Both participants joined, active communication
- **Ended**: Session completed
- **Canceled**: Session canceled

### 4. Message Tracking
- Full message lifecycle: sent → delivered → read
- Support for file attachments
- Reply functionality
- Message editing and deletion

### 5. Performance Optimized
- Proper indexing on all frequently queried columns
- Composite indexes for common query patterns
- Efficient pagination support

## Migration

To migrate from the old chat system:

1. **Run Migration Script**: `node scripts/create-new-chat-tables.js`
2. **Test New System**: `node scripts/test-new-chat-system.js`
3. **Update Frontend**: Modify frontend to use WebSocket-based chat (see `WEBSOCKET_CHAT_CLIENT_EXAMPLE.md`)
4. **Update Socket Logic**: Use the updated `socketService.ts` with new three-table structure

## Why WebSockets for Chat?

**You're absolutely right!** Chat functionality should use WebSockets for real-time communication. The API-only approach is not suitable for a proper chat system because:

1. **Real-time Communication**: Messages should appear instantly without polling
2. **Typing Indicators**: Show when someone is typing
3. **Online/Offline Status**: Real-time presence updates
4. **Message Delivery Status**: Instant read receipts
5. **Better User Experience**: No need to constantly refresh or poll for new messages

The WebSocket approach provides:
- **Instant message delivery**
- **Real-time typing indicators**
- **Live read receipts**
- **Session status updates**
- **Better performance** (no polling)
- **Lower server load**
- **Modern chat experience** that users expect

## Testing

The system includes comprehensive test scripts:

- **Database Tests**: `test-new-chat-system.js`
- **API Tests**: Use Postman collection for endpoint testing
- **Socket Tests**: Test WebSocket functionality

## Security Considerations

1. **Authentication**: All endpoints require valid JWT token
2. **Authorization**: Users can only access their own sessions
3. **Input Validation**: All inputs validated using Joi schemas
4. **SQL Injection**: Protected using parameterized queries
5. **Rate Limiting**: Implement rate limiting for message sending

## Error Handling

The system provides comprehensive error handling:

- **400**: Bad request (invalid input)
- **401**: Unauthorized (missing/invalid token)
- **403**: Forbidden (not authorized for session)
- **404**: Not found (session/message not found)
- **500**: Internal server error

All errors include descriptive messages and appropriate HTTP status codes.
