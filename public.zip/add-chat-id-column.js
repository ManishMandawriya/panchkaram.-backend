const { Sequelize } = require('sequelize');

// Database connection
const sequelize = new Sequelize('panchakarma', 'root', '', {
  host: 'localhost',
  dialect: 'mysql',
  logging: false
});

async function addChatIdColumn() {
  try {
    await sequelize.authenticate();
    console.log('✅ Database connection established.');

    // Check if chat_id column exists in chat_sessions
    const [columns] = await sequelize.query('DESCRIBE chat_sessions');
    const hasChatId = columns.some(col => col.Field === 'chat_id');
    
    if (!hasChatId) {
      console.log('🔧 Adding chat_id column to chat_sessions table...');
      
      // Add chat_id column without foreign key constraint first
      await sequelize.query('ALTER TABLE chat_sessions ADD COLUMN chat_id INT AFTER id');
      console.log('✅ Added chat_id column');
      
      // Set a default value for existing rows (we'll use 1 for now)
      await sequelize.query('UPDATE chat_sessions SET chat_id = 1 WHERE chat_id IS NULL');
      console.log('✅ Set default chat_id values');
      
      // Make the column NOT NULL
      await sequelize.query('ALTER TABLE chat_sessions MODIFY COLUMN chat_id INT NOT NULL');
      console.log('✅ Made chat_id NOT NULL');
      
      // Add index
      await sequelize.query('ALTER TABLE chat_sessions ADD INDEX idx_chat_id (chat_id)');
      console.log('✅ Added index for chat_id');
      
    } else {
      console.log('✅ chat_id column already exists');
    }

    // Show current structure
    const [updatedColumns] = await sequelize.query('DESCRIBE chat_sessions');
    console.log('\n📋 Current chat_sessions table structure:');
    updatedColumns.forEach(row => {
      console.log(`  ${row.Field} - ${row.Type}`);
    });

    console.log('\n🎉 chat_sessions table updated successfully!');

  } catch (error) {
    console.error('❌ Error adding chat_id column:', error.message);
    throw error;
  } finally {
    await sequelize.close();
  }
}

// Run the script
addChatIdColumn()
  .then(() => {
    console.log('\n🎉 chat_id column added successfully!');
    process.exit(0);
  })
  .catch((error) => {
    console.error('❌ Failed to add chat_id column:', error);
    process.exit(1);
  });
