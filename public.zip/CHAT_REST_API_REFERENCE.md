# Chat REST API Reference

## 🔑 Authentication

All API endpoints require a valid JWT token in the Authorization header:

```http
Authorization: Bearer your-jwt-token-here
```

## 📋 Chat Endpoints

### 1. Verify Session
**GET** `/api/chat/verify-session`

**Description:** Check if user has an active session

**Query Parameters:**
- `userId` (required): User ID
- `role` (required): "doctor" or "patient"

**Response:**
```json
{
  "success": true,
  "message": "Active session found",
  "data": {
    "sessionId": "1-5-1703123456789",
    "sessionType": "chat",
    "status": "scheduled",
    "startTime": "2024-01-20T10:00:00.000Z",
    "participants": {
      "doctor": { "id": 1, "name": "Dr. Smith" },
      "patient": { "id": 5, "name": "John Doe" }
    }
  }
}
```

**Error Response:**
```json
{
  "success": false,
  "message": "No active session found"
}
```

---

### 2. Join Session
**POST** `/api/chat/sessions/:sessionId/join`

**Description:** Join a specific chat session

**Path Parameters:**
- `sessionId` (required): Session ID

**Response:**
```json
{
  "success": true,
  "message": "Successfully joined session",
  "data": {
    "sessionId": "1-5-1703123456789",
    "sessionType": "chat",
    "status": "ongoing",
    "participants": {
      "doctor": { "id": 1, "name": "Dr. Smith" },
      "patient": { "id": 5, "name": "John Doe" }
    }
  }
}
```

---

### 3. Get Chat History
**GET** `/api/chat/history/:doctorId/:patientId`

**Description:** Get chat history between doctor and patient

**Path Parameters:**
- `doctorId` (required): Doctor's user ID
- `patientId` (required): Patient's user ID

**Query Parameters:**
- `limit` (optional): Number of messages to return (default: 50)
- `offset` (optional): Number of messages to skip (default: 0)

**Response:**
```json
{
  "success": true,
  "message": "Chat history retrieved",
  "data": {
    "messages": [
      {
        "id": 1,
        "messageId": "msg-1703123456789",
        "content": "Hello doctor!",
        "messageType": "text",
        "direction": "inbound",
        "status": "read",
        "sentAt": "2024-01-20T10:30:00.000Z",
        "sender": {
          "id": 5,
          "name": "John Doe"
        }
      }
    ],
    "total": 25,
    "hasMore": true
  }
}
```

---

### 4. End Session
**POST** `/api/chat/sessions/:sessionId/end`

**Description:** End a chat session

**Path Parameters:**
- `sessionId` (required): Session ID

**Response:**
```json
{
  "success": true,
  "message": "Session ended successfully",
  "data": {
    "sessionId": "1-5-1703123456789",
    "endedAt": "2024-01-20T11:00:00.000Z",
    "duration": 1800
  }
}
```

---

### 5. Get User Sessions
**GET** `/api/chat/sessions`

**Description:** Get all sessions for the authenticated user

**Query Parameters:**
- `status` (optional): Filter by status ("scheduled", "ongoing", "ended", "canceled")
- `limit` (optional): Number of sessions to return (default: 20)
- `offset` (optional): Number of sessions to skip (default: 0)

**Response:**
```json
{
  "success": true,
  "message": "Sessions retrieved",
  "data": {
    "sessions": [
      {
        "id": 1,
        "sessionId": "1-5-1703123456789",
        "sessionType": "chat",
        "status": "scheduled",
        "startTime": "2024-01-20T10:00:00.000Z",
        "participants": {
          "doctor": { "id": 1, "name": "Dr. Smith" },
          "patient": { "id": 5, "name": "John Doe" }
        }
      }
    ],
    "total": 5,
    "hasMore": false
  }
}
```

## 📋 Appointment Endpoints

### 1. Create Appointment (Auto-creates Chat)
**POST** `/api/appointments`

**Description:** Create a new appointment (automatically creates chat and chat session)

**Request Body:**
```json
{
  "doctorId": 1,
  "appointmentDate": "2024-01-20",
  "appointmentTime": "10:00 AM",
  "serviceType": "CHAT",
  "patientName": "John Doe",
  "patientAge": 25,
  "patientGender": "male",
  "problemDescription": "Need consultation"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Appointment created successfully",
  "data": {
    "appointment": {
      "id": 1,
      "doctorId": 1,
      "patientId": 5,
      "appointmentDate": "2024-01-20",
      "appointmentTime": "10:00:00",
      "serviceType": "CHAT",
      "status": "scheduled"
    }
  }
}
```

---

### 2. Get Chat Session for Appointment
**GET** `/api/appointments/:id/chat-session`

**Description:** Get the chat session associated with an appointment

**Path Parameters:**
- `id` (required): Appointment ID

**Response:**
```json
{
  "success": true,
  "message": "Chat session found",
  "data": {
    "sessionId": "1-5-1703123456789",
    "sessionType": "chat",
    "status": "scheduled",
    "startTime": "2024-01-20T10:00:00.000Z",
    "doctor": {
      "id": 1,
      "name": "Dr. Smith",
      "specialization": "Cardiology"
    },
    "patient": {
      "id": 5,
      "name": "John Doe"
    }
  }
}
```

## 🔄 Complete Flow Example

### Step 1: Login and Get Token
```http
POST /api/auth/login
Content-Type: application/json

{
  "phoneNumber": "1234567890",
  "password": "password123"
}
```

### Step 2: Check for Active Session
```http
GET /api/chat/verify-session?userId=5&role=patient
Authorization: Bearer your-jwt-token
```

### Step 3: Join Session via Socket.IO
```javascript
const socket = io('http://localhost:3000', {
  auth: { token: 'your-jwt-token' }
});

socket.emit('join-session', '1-5-1703123456789');
```

### Step 4: Send Messages
```javascript
socket.emit('send-message', {
  sessionId: '1-5-1703123456789',
  content: 'Hello doctor!',
  messageType: 'text'
});
```

### Step 5: Get Chat History
```http
GET /api/chat/history/1/5
Authorization: Bearer your-jwt-token
```

## 📝 Error Responses

All endpoints return consistent error formats:

```json
{
  "success": false,
  "message": "Error description",
  "error": "Detailed error message"
}
```

Common HTTP Status Codes:
- `200` - Success
- `400` - Bad Request
- `401` - Unauthorized
- `404` - Not Found
- `500` - Internal Server Error

## 🧪 Testing with cURL

### Test Session Verification
```bash
curl -X GET "http://localhost:3000/api/chat/verify-session?userId=5&role=patient" \
  -H "Authorization: Bearer your-jwt-token"
```

### Test Chat History
```bash
curl -X GET "http://localhost:3000/api/chat/history/1/5" \
  -H "Authorization: Bearer your-jwt-token"
```

### Test Appointment Chat Session
```bash
curl -X GET "http://localhost:3000/api/appointments/1/chat-session" \
  -H "Authorization: Bearer your-jwt-token"
```

## 📱 Frontend Integration Example

```javascript
class ChatAPI {
  constructor(token) {
    this.token = token;
    this.baseURL = 'http://localhost:3000/api';
  }

  async verifySession(userId, role) {
    const response = await fetch(
      `${this.baseURL}/chat/verify-session?userId=${userId}&role=${role}`,
      {
        headers: { 'Authorization': `Bearer ${this.token}` }
      }
    );
    return response.json();
  }

  async getChatHistory(doctorId, patientId, limit = 50) {
    const response = await fetch(
      `${this.baseURL}/chat/history/${doctorId}/${patientId}?limit=${limit}`,
      {
        headers: { 'Authorization': `Bearer ${this.token}` }
      }
    );
    return response.json();
  }

  async getAppointmentChatSession(appointmentId) {
    const response = await fetch(
      `${this.baseURL}/appointments/${appointmentId}/chat-session`,
      {
        headers: { 'Authorization': `Bearer ${this.token}` }
      }
    );
    return response.json();
  }

  async createAppointment(appointmentData) {
    const response = await fetch(`${this.baseURL}/appointments`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${this.token}`
      },
      body: JSON.stringify(appointmentData)
    });
    return response.json();
  }
}

// Usage
const chatAPI = new ChatAPI('your-jwt-token');

// Check for active session
const session = await chatAPI.verifySession(5, 'patient');
if (session.success) {
  console.log('Active session:', session.data.sessionId);
}

// Get chat history
const history = await chatAPI.getChatHistory(1, 5);
console.log('Chat history:', history.data.messages);
```

---

**Note:** All timestamps are in ISO 8601 format (UTC). Session IDs follow the format: `{doctorId}-{patientId}-{timestamp}`.
