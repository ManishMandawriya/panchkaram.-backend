const jwt = require('jsonwebtoken');

// Test JWT token generation
const testUser = {
  userId: 1,
  email: 'test@example.com',
  role: 'patient',
  fullName: 'Test User'
};

// Use the same secret as your server
const JWT_SECRET = 'your-super-secret-jwt-key-change-this-in-production';

const token = jwt.sign(testUser, JWT_SECRET, { expiresIn: '7d' });

console.log('🔑 Test JWT Token:');
console.log(token);
console.log('\n📋 Copy this token and use it in your Socket.IO test page');
console.log('\n🔍 To decode and verify the token:');
console.log('https://jwt.io/');
